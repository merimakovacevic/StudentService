function provjeri(){
	var mojDiv=document.getElementById("poruka");
	var inputIme=document.getElementsByTagName("input")[0];
	var validacija = new Validacija(mojDiv);
	validacija.ime(inputIme);
}

document.getElementsByTagName("input")[2].addEventListener("click", provjeri);
