// Napisani svi regexi, nisu povezane funkcije sa HTMLovima(osim addZadatak.html) i nije ispisivano u funkcijama sve kako treba
var Validacija=(function(){
	//lokalne variable idu ovdje
	var greske; // koristit cemo da u svakoj funkciji saznamo sta tacno ispisati (stvarno se nisam sjetio boljeg nacina)
	// na kraju svake funkcije bismo provjerili niz gresaka i na osnovu toga bismo ispisivali u div sta nije tacno validirano
	// u prvoj funkciji za ime je dat primjer bez provjere niza gresaka kako se postavljaju vrijednosti div taga
	var konstruktor=function(divElementPoruke){
		var i = 0;
		greske = new Array(7);
		for(i = 0; i < 7; i++){
			greske[i] = false;
		}
		return{
			ime:function(inputElement){
				var uzorak = /^([A-Z]([a-z]+'?)+[a-z]+(\s|-)){0,3}[A-Z]([a-z]+'?)+[a-z]+$/;
				if(!uzorak.test(inputElement.value)) {
						greske[0] = true;
						var tekst = "Sljedeća polja nisu validna: ime!";
						divElementPoruke.innerHTML = tekst;
						divElementPoruke.style.backgroundColor = "orangered";
						inputElement.style.backgroundColor = "orangered";
				}
				else {
					greske[0] = false;
					var tekst = "";
					divElementPoruke.innerHTML = tekst;
					divElementPoruke.style.backgroundColor = "white";
					inputElement.style.backgroundColor = "white";
				}
			},

			godina:function(inputElement){
				var uzorak = /^20\d\d\/20\d\d$/; // provjerava samo da li je format 20AB/20CD, ne i razliku u jednoj godini
				if(inputElement.value.match(regex)){
					greske[1] = false;
				}
				else {
					greske[1] = true;
				}
			},

			repozitorij:function(inputElement,regex){
				if(inputElement.value.match(regex)){
					greske[2] = false;
				}
				else {
					greske[2] = true;
				}
			},

			index:function(inputElement){
				var uzorak = /^1[4-9][0-9]{3}|20[0-9]{3}$/
				if(!uzorak.test(inputElement.value)){
					greske[3] = true;
				}
				else{
					greske[3] = false;
				}
			},

			naziv:function(inputElement){
				var uzorak = /^[A-Za-z][A-Za-z0-9\\\/\-\"\'\!\?\:\;\,]+[a-z0-9]$/;
				if(!uzorak.test(inputElement.value)){
					greske[4] = true;
				}
				else{
					greske[4] = false;
				}
			},

			password:function(inputElement){
				var uzorak = /^(?=.*\d)(?=.*[A-Z])([A-Za-z0-9]){8}|(?=.*[a-z])(?=.*[A-Z])([A-Za-z0-9]){8}|(?=.*\d)(?=.*[a-z])([A-Za-z0-9]){8}$/;
				if(!uzorak.test(inputElement.value)){
					greske[5] = true;
				}
				else{
					greske[5] = false;
				}
			},

			url:function(inputElement){
				var uzorak = /^(http|https|ftp|ssh)\:\/\/[a-z0-9][a-z0-9\-]*(\.[a-z0-9][a-z0-9\-]*)*(\/[a-z0-9][a-z0-9\-]*)*(\?[a-z0-9][a-z0-9\-]*\=[a-z0-9][a-z0-9\-]*(\&[a-z0-9][a-z0-9\-]*\=[a-z0-9][a-z0-9\-]*)*)?$/;
				if(!uzorak.test(inputElement.value)){
					greske[6] = true;
				}
				else{
					greske[6] = false;
				}
			}
		}
	}
	return konstruktor;
}());
