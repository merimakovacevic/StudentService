var tabela;
function createTable(){
	var mojDiv=document.getElementById("tabela");
	var brZadataka = document.getElementById("brZadataka").value;
	tabela= new CommitTabela(mojDiv,brZadataka);
}

function addCommit(){
	var brZadatka = document.getElementById("addCommitbrZad").value;
	var url = document.getElementById("addCommitUrl").value;
	tabela.dodajCommit(parseInt(brZadatka), url);
}

function editCommit(){
	var brZadatka = document.getElementById("editCommitbrZad").value;
	var brCommita = document.getElementById("editCommitbrCommit").value;
	var url = document.getElementById("editCommitUrl").value;
	tabela.editujCommit(parseInt(brZadatka), parseInt(brCommita), url);
}

function deleteCommit(){
	var brZadatka = document.getElementById("deleteCommitbrZad").value;
	var brCommita = document.getElementById("deleteCommitbrCommit").value;
	tabela.obrisiCommit(parseInt(brZadatka), parseInt(brCommita));
}

document.getElementById("brZadatakaSub").addEventListener("click", createTable);
document.getElementById("addCommitSub").addEventListener("click", addCommit);
document.getElementById("editCommitSub").addEventListener("click", editCommit);
document.getElementById("deleteCommitSub").addEventListener("click", deleteCommit);
