var CommitTabela=(function(){
	//lokalne variable idu ovdje
	var brojCommita;
	var konstruktor=function(divElement,brojZadataka){
		divElement.innerHTML = "";
		var i = 0;
		var tabela = document.createElement("TABLE");
		var zaglavlje = tabela.createTHead();
		// Kolona za zadatke
		var red = zaglavlje.insertRow(0);
		var cell = document.createElement("TH");
		cell.innerHTML = "Zadaci";
		red.appendChild(cell);

		// Kolona za commite
		cell = document.createElement("TH");
		cell.innerHTML = "Commiti";
		cell.colSpan = 1;
		red.appendChild(cell);

		// Tijelo tabele (svi zadaci i commiti)
		var body = document.createElement("TBODY");
		for(i = 0; i < brojZadataka; i++){
			red = body.insertRow(i);
			cell = red.insertCell(0);
			cell.innerHTML = "Zadatak " + (i + 1);
			cell = red.insertCell(1);
		}
		tabela.appendChild(body);
		divElement.appendChild(tabela);
		// Pravimo niz koliko ima commita za svaki zadatak
		brojCommita = new Array(brojZadataka);
		for(i = 0; i < brojZadataka; i++){
			brojCommita[i] = 0;
		}
		return{
			dodajCommit:function(rbZadatka,url){
				brojCommita[rbZadatka]++;
				var zaglavlje = document.getElementsByTagName("tr")[0].getElementsByTagName("th")[1];
				var red = document.getElementsByTagName("tr")[rbZadatka + 1];
				var celije = red.getElementsByTagName("td");
				var i = 0;
				if(zaglavlje.colSpan > celije.length - 1){
					// Sta se desava ukoliko imamo praznog prostora u redu
					red.insertCell(celije.length - 1);
					celije[celije.length - 2].colSpan = 1;
					var link = document.createElement("a");
					link.href = url;
					link.innerHTML = brojCommita[rbZadatka];
					celije[celije.length - 2].appendChild(link);
					celije[celije.length - 1].colSpan = celije[celije.length - 1].colSpan - 1;
				}
				else if (zaglavlje.colSpan == celije.length - 1){
					// Sta se desava ako je pun red ili ima samo jedno prazno mjesto (kolona sirine 1)
						if(celije[celije.length - 1].innerHTML == ""){
							// Sta ako je samo jedno prazno mjesto
							var link = document.createElement("a");
							link.href = url;
							link.innerHTML = brojCommita[rbZadatka];
							celije[celije.length - 1].appendChild(link);
						}
						else{
							// Sta ako nema mjesta, tj. moramo prosirivati cijelu tabelu
							zaglavlje.colSpan = zaglavlje.colSpan + 1;
							for(i = 1; i <= brojZadataka; i++){
								var privRed = document.getElementsByTagName("tr")[i];
								var privCelije = privRed.getElementsByTagName("td");
								if(privCelije[privCelije.length - 1].innerHTML == ""){
									privCelije[privCelije.length - 1].colSpan = privCelije[privCelije.length - 1].colSpan + 1;
								}
								else{
									privRed.insertCell(privCelije.length);
								}
							}
							zaglavlje = document.getElementsByTagName("tr")[0].getElementsByTagName("th")[1];
							red = document.getElementsByTagName("tr")[rbZadatka + 1];
							celije = red.getElementsByTagName("td");
							var link = document.createElement("a");
							link.href = url;
							link.innerHTML = brojCommita[rbZadatka];
							celije[celije.length - 1].appendChild(link);
						}
				}
			},

			editujCommit:function(rbZadatka,rbCommita,url){
				// Provjere na validne argumente
				if(rbZadatka < 0 || rbZadatka >= brojZadataka){
					return -1;
				}
				var red = document.getElementsByTagName("tr")[rbZadatka + 1];
				var provjeraBrCommita = red.getElementsByTagName("td");
				var brojCommita = provjeraBrCommita.length - 1;
				if(provjeraBrCommita[brojCommita].innerHTML == "")
					brojCommita -= provjeraBrCommita[brojCommita].colSpan - 1;
				if(rbCommita < 0 || rbCommita >= brojCommita){
					return -1;
				}
				// Nalazimo trazeni red, pa celiju, i u njoj anchor tag kojem mijenjamo href atribut
				var celija = red.getElementsByTagName("td")[rbCommita + 1];
				var link = celija.getElementsByTagName("a")[0];
				link.href = url;
			},

			obrisiCommit:function(rbZadatka,rbCommita){
				var i = 0;
				// Provjere na validne argumente
				if(rbZadatka < 0 || rbZadatka >= brojZadataka){
					return -1;
				}
				var red = document.getElementsByTagName("tr")[rbZadatka + 1];
				var provjeraBrCommita = red.getElementsByTagName("td");
				var brojCommita = provjeraBrCommita.length - 1;
				if(provjeraBrCommita[brojCommita].innerHTML == "")
					brojCommita -= 1;
				if(rbCommita < 0 || rbCommita >= brojCommita){
					return -1;
				}
				// Sad brisemo elemente
				for(i = rbCommita; i < brojCommita - 1; i++){
					var celija1 = red.getElementsByTagName("td")[i + 1];
					var celija2 = red.getElementsByTagName("td")[i + 2];
					celija1.innerHTML = celija2.innerHTML;
				}
				red.getElementsByTagName("td")[i + 1].innerHTML = "";
				red.getElementsByTagName("td")[i + 1].colSpan = 1;
				for(i = 1; i < red.getElementsByTagName("td").length - 1; i++)
				{
					var celija1 = red.getElementsByTagName("td")[i];
					var celija2 = red.getElementsByTagName("td")[i + 1];
					if(celija1.innerHTML == "" && celija2.innerHTML == ""){
						celija1.parentNode.removeChild(celija1);
						celija2.colSpan = celija2.colSpan + 1;
					}
				}

				// Jos provjera da li je sve prazno sa desne strane tabele
				var redovi = document.getElementsByTagName("tr");
				var trebaSkupiti = true;
				for(i = 1; i <= brojZadataka; i++){
					var celije = redovi[i].getElementsByTagName("td");
					if(celije[celije.length - 1].innerHTML != ""){
						trebaSkupiti = false;
						break;
					}
				}
				// Ako jeste, skupljamo tabelu (tj. smanjujemo u sirinu)
				if(trebaSkupiti && redovi[0].getElementsByTagName("th")[1].colSpan != 1){
					redovi[0].getElementsByTagName("th")[1].colSpan -= 1;
					for(i = 1; i <= brojZadataka; i++){
						var celije = redovi[i].getElementsByTagName("td");
						if(celije[celije.length - 1].colSpan > 1){
							celije[celije.length - 1].colSpan -= 1;
						}
						else{
							celije[celije.length - 1].parentNode.removeChild(celije[celije.length - 1]);
						}
					}
				}
			}
		}
	}
	return konstruktor;
}());
