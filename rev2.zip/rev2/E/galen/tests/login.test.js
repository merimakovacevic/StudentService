// add devices and browsers that you need with sizes

var devices = {
  tablet: {
    deviceName: "mobile",
    size: "600x600"
  },
  desktop: {
    deviceName: "desktop",
    size: "1920x1080"
  }
};

var browsers = {
  
  chrome: {
    browserName: "chrome"
  },
  firefox: {
    browserName: "firefox"
  }
};


// run test for all devices and browsers
forAll(devices, function () {
  forAll(browsers, function () {
    test("${browserName}(${deviceName})", function (device, browser) {
		var driver = createDriver("file:///D:/Downloads/Opera/Spirala%201-20181031T222711Z-001/Spirala%201/login.html", device.size, browser.browserName);
		
		// Checking layout on the page
		checkLayout(driver, "specs/login.gspec", device.deviceName);

		// Quiting the browser
		driver.quit();
		
		var driver = createDriver("file:///D:/Downloads/Opera/Spirala%201-20181031T222711Z-001/Spirala%201/studenti.html", device.size, browser.browserName);
		
		// Checking layout on the page
		checkLayout(driver, "specs/template.gspec", device.deviceName);
		checkLayout(driver, "specs/studenti.gspec", device.deviceName);
		
		// Quiting the browser
		driver.quit();
		
		driver = createDriver("file:///D:/Downloads/Opera/Spirala%201-20181031T222711Z-001/Spirala%201/zadaci.html", device.size, browser.browserName);
		
		// Checking layout on the page
		checkLayout(driver, "specs/template.gspec", device.deviceName);
		checkLayout(driver, "specs/zadaci.gspec", device.deviceName);
		
		// Quiting the browser
		driver.quit();
		
		driver = createDriver("file:///D:/Downloads/Opera/Spirala%201-20181031T222711Z-001/Spirala%201/commiti.html", device.size, browser.browserName);
		
		// Checking layout on the page
		checkLayout(driver, "specs/template.gspec", device.deviceName);
		
		// Quiting the browser
		driver.quit();
		
		driver = createDriver("file:///D:/Downloads/Opera/Spirala%201-20181031T222711Z-001/Spirala%201/addZadatak.html", device.size, browser.browserName);
		
		// Checking layout on the page
		checkLayout(driver, "specs/template.gspec", device.deviceName);
		checkLayout(driver, "specs/addZadatak.gspec", device.deviceName);
		
		// Quiting the browser
		driver.quit();
		
		driver = createDriver("file:///D:/Downloads/Opera/Spirala%201-20181031T222711Z-001/Spirala%201/addVjezba.html", device.size, browser.browserName);
		
		// Checking layout on the page
		checkLayout(driver, "specs/template.gspec", device.deviceName);
		checkLayout(driver, "specs/addVjezba.gspec", device.deviceName);
		
		// Quiting the browser
		driver.quit();
		
		driver = createDriver("file:///D:/Downloads/Opera/Spirala%201-20181031T222711Z-001/Spirala%201/addStudent.html", device.size, browser.browserName);
		
		// Checking layout on the page
		checkLayout(driver, "specs/template.gspec", device.deviceName);
		checkLayout(driver, "specs/addStudent.gspec", device.deviceName);
		
		// Quiting the browser
		driver.quit();
		
		driver = createDriver("file:///D:/Downloads/Opera/Spirala%201-20181031T222711Z-001/Spirala%201/addGodina.html", device.size, browser.browserName);
		
		// Checking layout on the page
		checkLayout(driver, "specs/template.gspec", device.deviceName);
		checkLayout(driver, "specs/addGodina.gspec", device.deviceName);
		
		// Quiting the browser
		driver.quit();
    });
  }); 
});