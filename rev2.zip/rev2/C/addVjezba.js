function provjeraForme() {
    var divPoruke = document.getElementById("porukaValidacije");
    var naziv = document.getElementById("nazVjezbe");
    var validacija = new Validacija(divPoruke);
    validacija.naziv(naziv);
    validacija.ispisPoruke();
}