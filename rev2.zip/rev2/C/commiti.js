var mojDiv = document.getElementById("tabela");
var tabelica = new CommitTabela(mojDiv, 4);

function addCommit() {
    var brojReda = parseInt(document.getElementById("brojReda").value);
    var url = document.getElementById("inputUrl").value;
    tabelica.dodajCommit(brojReda, url); 
    document.getElementById("brojReda").value = "";
    document.getElementById("brojKolone").value = "";
    document.getElementById("inputUrl").value = "";
}

function editCommit() {
    var brojReda = parseInt(document.getElementById("brojReda").value);
    var brojKolone = parseInt(document.getElementById("brojKolone").value);
    var url = document.getElementById("inputUrl").value;
    tabelica.editujCommit(brojReda, brojKolone, url);
    document.getElementById("brojReda").value = "";
    document.getElementById("brojKolone").value = "";
    document.getElementById("inputUrl").value = "";
}

function removeCommit() {
    var brojReda = parseInt(document.getElementById("brojReda").value);
    var brojKolone = parseInt(document.getElementById("brojKolone").value);
    tabelica.obrisiCommit(brojReda, brojKolone);
    document.getElementById("brojReda").value = "";
    document.getElementById("brojKolone").value = "";
    document.getElementById("inputUrl").value = "";
}