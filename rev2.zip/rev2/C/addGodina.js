function provjeraForme() {
    var divPoruke = document.getElementById("porukaValidacije");
    var godina = document.getElementById("inputNaziv");
    var repoSpirala = document.getElementById("inputRspiral");
    var repoVjezbe = document.getElementById("inputRvjezbe");
    var regexRepo = /^[a-z0-9]{3,}$/;
    var validacija = new Validacija(divPoruke);
    validacija.godina(godina);
    validacija.repozitorij(repoSpirala, regexRepo);
    validacija.repozitorij(repoVjezbe, regexRepo);
    validacija.ispisPoruke();
}