var CommitTabela = (function(){
    var tabela;

    var konstruktor = function(divElement, brojZadataka) {
        tabela = document.createElement("table");
        tabela.style.height = "100%";
        tabela.style.width = "100%";
        tabela.style.border = "1px solid black";
        tabela.style.backgroundColor = "white";
        tabela.style.textAlign = "center";
        var nizCommita = new Array(brojZadataka).fill(0);

        for(var i=0; i<=brojZadataka; i++) {
            var tr = tabela.insertRow();
            tr.style.border = "1px solid black";
            for(var j=0; j<2; j++) {
                var td = tr.insertCell();
                td.style.border = "1px solid black";
                if(i == 0) {
                    td.style.backgroundColor = "rgb(76, 124, 167)";
                    if(j == 0) 
                        td.appendChild(document.createTextNode("Zadaci"));
                    else
                        td.appendChild(document.createTextNode("Commiti"));     
                }
                else if(j == 0) {
                    var a = document.createElement("a");
                    a.innerHTML = "Zadatak " + i;
                    a.href = "https://docs.google.com/document/d/1ZjkBwWG_gsRokjp7oGwDpFm40qXM1tB9AwcV5_Qv8W8/edit";
                    td.appendChild(a);
                }
                else {
                    var a = document.createElement("a");
                    a.innerHTML = "";
                    td.appendChild(a);
                }
            }
        }
        divElement.appendChild(tabela);

        return {
            dodajCommit:function(rbZadatka, url) {
                rbZadatka+=1;
                if(rbZadatka < 1 || rbZadatka >= tabela.rows.length) return -1;
                nizCommita[rbZadatka-1] += 1; 
                var brojKolona = tabela.rows[rbZadatka].cells.length;
                var postoji = false;
                var i;
                for(i=0; i<brojKolona; i++) {
                    if(tabela.rows[rbZadatka].cells[i].innerHTML === "<a></a>") {
                        postoji = true;
                        break;
                    }
                }
                if(postoji) {
                    tabela.rows[rbZadatka].cells[i].innerHTML = "<a href='" + url + "'>" + nizCommita[rbZadatka-1] + "</a>";
                }
                else {
                    var brojRedova = tabela.rows.length;
                    for(var i=1; i<brojRedova; i++) {
                        var tr = tabela.rows[i];
                        var td = tr.insertCell();
                        td.style.border = "1px solid black";
                        var a = document.createElement("a");
                        a.innerHTML = "";
                        td.appendChild(a);
                    }
                    tabela.rows[rbZadatka].cells[brojKolona].innerHTML = "<a href='" + url + "'>" + nizCommita[rbZadatka-1] + "</a>";
                    tabela.rows[0].cells[1].colSpan = brojKolona;
                }    
            },
            editujCommit:function(rbZadatka, rbCommita, url) {
                rbZadatka+=1; rbCommita+=1;
                if(rbZadatka < 1 || rbCommita < 1 || rbZadatka >= tabela.rows.length || rbCommita > tabela.rows[0].cells[1].colSpan) return -1;
                if(tabela.rows[rbZadatka].cells[rbCommita].innerHTML === "<a></a>") return -1;
                var brojCommita = tabela.rows[rbZadatka].cells[rbCommita].textContent;
                tabela.rows[rbZadatka].cells[rbCommita].innerHTML = "<a href='" + url + "'>" + brojCommita + "</a>";
            },
            obrisiCommit:function(rbZadatka, rbCommita) {
                rbZadatka+=1; rbCommita+=1;
                if(rbZadatka < 1 || rbCommita < 1 || rbZadatka >= tabela.rows.length || rbCommita > tabela.rows[0].cells[1].colSpan) return -1;
                var brojKolona = tabela.rows[rbZadatka].cells.length;
                var brojRedova = tabela.rows.length;
                if(brojKolona-1 == rbCommita) {
                    var postoji = false;
                    for(var i=1; i<brojRedova; i++) {
                        if(i != rbZadatka) {
                            if(tabela.rows[i].cells[rbCommita].innerHTML != "<a></a>") {
                                postoji = true;
                                break;
                            }
                        }
                    }
                    if(!postoji) {
                        for(var i=1; i<brojRedova; i++)
                            tabela.rows[i].children[rbCommita].remove();
                        tabela.rows[0].cells[1].colSpan = brojKolona-2; 
                    }
                    else {
                        tabela.rows[rbZadatka].children[rbCommita].remove();
                        var tr = tabela.rows[rbZadatka];
                        var td = tr.insertCell();
                        td.style.border = "1px solid black";
                        var a = document.createElement("a");
                        a.innerHTML = "";
                        td.appendChild(a);
                    }
                }
                else {
                    tabela.rows[rbZadatka].children[rbCommita].remove();
                    var tr = tabela.rows[rbZadatka];
                    var td = tr.insertCell();
                    td.style.border = "1px solid black";
                    var a = document.createElement("a");
                    a.innerHTML = "";
                    td.appendChild(a);
                    
                    var postoji = false;
                    for(var i=1; i<brojRedova; i++) {
                        if(tabela.rows[i].cells[brojKolona-1].innerHTML != "<a></a>") {
                            postoji = true;
                            break;
                        }
                    }
                    if(!postoji) {
                        for(var i=1; i<brojRedova; i++)
                            tabela.rows[i].children[brojKolona-1].remove();
                        tabela.rows[0].cells[1].colSpan = brojKolona-2;
                    }
                }
            }
        }
    }
    return konstruktor;
}());