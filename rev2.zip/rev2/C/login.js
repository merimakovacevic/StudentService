function provjeraForme() {
    var divPoruke = document.getElementById("porukaValidacije");
    var password = document.getElementById("inputPassword");
    var validacija = new Validacija(divPoruke);
    validacija.password(password);
    validacija.ispisPoruke();
}