var Validacija = (function(){

    var konstruktor = function(divElementPoruke) {
        var nizRijeci = new Array();

        return {
            ime:function(inputElement) {
                var imeRegex = /^([A-Z](\'?|[a-z]+)+)$|^([A-Z](\'?|[a-z]+)+)[ \-]([A-Z](\'?|[a-z]+)+)$|^([A-Z](\'?|[a-z]+)+)[ \-]([A-Z](\'?|[a-z]+)+)[ \-]([A-Z](\'?|[a-z]+)+)$|^([A-Z](\'?|[a-z]+)+)[ \-]([A-Z](\'?|[a-z]+)+)[ \-]([A-Z](\'?|[a-z]+)+)[ \-]([A-Z](\'?|[a-z]+)+)$/;
                var provjeraApostrofa = /.+\'{2,}.*/;
                if(!provjeraApostrofa.test(inputElement.value)) {
                    if(!imeRegex.test(inputElement.value)) {
                        inputElement.style.backgroundColor = "orangered";
                        nizRijeci.push("ime");
                    }
                    else 
                        inputElement.style.backgroundColor = "white";
                }
                else {
                    inputElement.style.backgroundColor = "orangered";
                    nizRijeci.push("ime");
                }
            },
            godina:function(inputElement) {
                var godinaRegex = /^20[0-9]{2}\/20[0-9]{2}$/;
                if(godinaRegex.test(inputElement.value)) {
                    var godinaStr = inputElement.value.match(godinaRegex).toString();
                    var godineObje = godinaStr.split("/");
                    var godina1 = parseInt(godineObje[0]);
                    var godina2 = parseInt(godineObje[1]);
                    if(godina2 != godina1 + 1) {
                        inputElement.style.backgroundColor = "orangered";
                        nizRijeci.push("godina");
                    }
                    else
                        inputElement.style.backgroundColor = "white";    
                }
                else {
                    inputElement.style.backgroundColor = "orangered";
                    nizRijeci.push("godina");
                }
            },
            repozitorij:function(inputElement, regex) {
                if(!regex.test(inputElement.value)) {
                    inputElement.style.backgroundColor = "orangered";
                    var postoji = false;
                    for(var i=0; i<nizRijeci.length; i++)
                        if(nizRijeci[i] === "repozitorij") {
                            postoji = true;
                            break;    
                        }
                    if(!postoji)    
                        nizRijeci.push("repozitorij");
                }
                else
                    inputElement.style.backgroundColor = "white";
            },
            index:function(inputElement) {
                var indexRegex = /^((1[4-9])|20)[0-9]{3}$/;
                if(!indexRegex.test(inputElement.value)) {
                    inputElement.style.backgroundColor = "orangered";
                    nizRijeci.push("index");
                }
                else    
                    inputElement.style.backgroundColor = "white";
            },
            naziv:function(inputElement) {
                var nazivRegex = /^[A-Za-z][A-Za-z0-9\\\/\-\"\'\!\?\:\;\,]+[0-9a-z]$/;
                if(!nazivRegex.test(inputElement.value)) {
                    inputElement.style.backgroundColor = "orangered";
                    nizRijeci.push("naziv");
                }
                else 
                    inputElement.style.backgroundColor = "white";  
            },
            password:function(inputElement) {
                var pwRegex1 = /^(?=.*[a-z])(?=.*[A-Z])[A-Za-z0-9]{8,}/;
                var pwRegex2 = /^(?=.*[A-Z])(?=.*[0-9])[A-Za-z0-9]{8,}/;
                var pwRegex3 = /^(?=.*[a-z])(?=.*[0-9])[A-Za-z0-9]{8,}/;
                if(!pwRegex1.test(inputElement.value)) {
                    if(!pwRegex2.test(inputElement.value)) {
                        if(!pwRegex3.test(inputElement.value)) {
                            inputElement.style.backgroundColor = "orangered";
                            nizRijeci.push("password");
                        }
                        else
                            inputElement.style.backgroundColor = "white";
                    }
                    else
                        inputElement.style.backgroundColor = "white";
                }
                else
                    inputElement.style.backgroundColor = "white";
            },
            url:function(inputElement) {
                var urlRegex = /^(http|https|ftp|ssh):\/\/\w+(\.\w+)*(\/\w+)*(\?\w+=\w+)*(&\w+=\w+)*$/;
                if(!urlRegex.test(inputElement.value)) {
                    inputElement.style.backgroundColor = "orangered";
                    nizRijeci.push("url");
                }
                else
                    inputElement.style.backgroundColor = "white";  
            },
            ispisPoruke:function() {
                if(nizRijeci.length != 0) {
                    divElementPoruke.innerHTML = "Sljedeća polja nisu validna:";
                    for(var i=0; i<nizRijeci.length; i++) {
                        divElementPoruke.innerHTML += nizRijeci[i];
                        if(i != nizRijeci.length-1) 
                        divElementPoruke.innerHTML += ",";
                    }
                    divElementPoruke.innerHTML += "!";
                }
                else
                    divElementPoruke.innerHTML = "";
            }
        }
    }
    return konstruktor;
}());