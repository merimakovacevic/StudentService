function provjeraForme() {
    var divPoruke = document.getElementById("porukaValidacije");
    var ime = document.getElementById("inputIme");
    var index = document.getElementById("inputIndex");
    var validacija = new Validacija(divPoruke);
    validacija.ime(ime);
    validacija.index(index);
    validacija.ispisPoruke();
}