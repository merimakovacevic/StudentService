function provjeraForme() {
    var divPoruke = document.getElementById("porukaValidacije");
    var naziv = document.getElementById("nazivZadatka");
    var validacija = new Validacija(divPoruke);
    validacija.naziv(naziv);
    validacija.ispisPoruke();
}