var Validacija=(function(){

    var konstruktor=function(divElementPoruke)
    {
        var poruka = document.createElement('p');
        divElementPoruke.appendChild(poruka);

        function regul(str, regex)
        {
                if(str==undefined) return false;
                var valid = regex.test(str);
                return valid;
        }

        function pporuka(item)
        {
            var pork = divElementPoruke.getElementsByTagName("p")[0].innerHTML;
            var px = /Sljedeca polja nisu validna:/;
            if (!px.test(pork)) pork= "Sljedeća polja nisu validna:";
            if (pork.substr(pork.length-1)=="!") pork=pork.slice(0, pork.length-1) + ", ";
            pork = pork + item + "!";
            divElementPoruke.getElementsByTagName("p")[0].innerHTML = pork
        }

        return {
            ime:function(inputElement)
            {
                var valid = regul(String(inputElement.value), /^[A-Z]'?[A-Za-z]+('?[A-Za-z])'?([\s-][A-Z]'?[A-Za-z]+('?[A-Za-z])'?){0,3}$/);
                if (!valid)
                {
                    pporuka("ime");
                    inputElement.style.backgroundColor="orangered";
                }
                else inputElement.style.backgroundColor="white";
                var px = /Sljedeca polja nisu validna:$/;
                if (px.test(divElementPoruke.getElementsByTagName("p")[0].innerHTML))
                {
                    divElementPoruke.getElementsByTagName("p")[0].innerHTML="";
                }
                return valid;
            },
            godina:function(inputElement)
            {
                var valid = regul(String(inputElement.value), /^20[0-9][0-9]\/20[0-9][0-9]$/);
                if((Number(inputElement.slice(7))-Number(inputElement.slice(2,4)))!=1) valid=false;
                if (!valid)
                {
                    pporuka("godina");
                    inputElement.style.backgroundColor="orangered";
                }
                else inputElement.style.backgroundColor="white";
                var px = /Sljedeca polja nisu validna:$/;
                if (px.test(divElementPoruke.getElementsByTagName("p")[0].innerHTML))
                {
                    divElementPoruke.getElementsByTagName("p")[0].innerHTML="";
                }
                return valid;
            },
            repozitorij:function(inputElement, regex)
            {
                var valid = regul(String(inputElement.value), regex);
                if (!valid)
                {
                    pporuka("repozitorij");
                    inputElement.style.backgroundColor="orangered";
                }
                else inputElement.style.backgroundColor="white";
                var px = /Sljedeca polja nisu validna:$/;
                if (px.test(divElementPoruke.getElementsByTagName("p")[0].innerHTML))
                {
                    divElementPoruke.getElementsByTagName("p")[0].innerHTML="";
                }
                return valid;
            },
            index:function(inputElement)
            {
                var valid = regul(String(inputElement.value), /^(14|15|16|17|18|19|20)\d{3}$/);
                if (!valid)
                {
                    pporuka("index");
                    inputElement.style.backgroundColor="orangered";
                }
                else inputElement.style.backgroundColor="white";
                var px = /Sljedeca polja nisu validna:$/;
                if (px.test(divElementPoruke.getElementsByTagName("p")[0].innerHTML))
                {
                    divElementPoruke.getElementsByTagName("p")[0].innerHTML="";
                }
                return valid;
            },
            naziv:function(inputElement)
            {
                var valid = regul(String(inputElement.value), /^[A-Za-z][,;:?!'"\-/\\0-9A-Za-z]+[a-z0-9]$/);
                if (!valid)
                {
                    pporuka("naziv");
                    inputElement.style.backgroundColor="orangered";
                }
                else inputElement.style.backgroundColor="white";
                var px = /Sljedeca polja nisu validna:$/;
                if (px.test(divElementPoruke.getElementsByTagName("p")[0].innerHTML))
                {
                    divElementPoruke.getElementsByTagName("p")[0].innerHTML="";
                }
                return valid;
            },
            password:function(inputElement)
            {
                var valid;
                var rx1 = /[0-9]/;
                var rx2 = /[a-z]/;
                var rx3 = /[A-Z]/;
                var v1 = rx1.test(String(inputElement.value));
                var v2 = rx2.test(String(inputElement.value));
                var v3 = rx3.test(String(inputElement.value));
                if(String(inputElement.value).length<8 || !(v1 && v2 || v1 && v3 || v2 && v3)) valid=false;
                if (!valid)
                {
                    pporuka("password");
                    inputElement.style.backgroundColor="orangered";
                }
                else inputElement.style.backgroundColor="white";
                var px = /Sljedeca polja nisu validna:$/;
                if (px.test(divElementPoruke.getElementsByTagName("p")[0].innerHTML))
                {
                    divElementPoruke.getElementsByTagName("p")[0].innerHTML="";
                }
                return valid;
            },
            url:function(inputElement)
            {
                var valid = regul(String(inputElement.value), /^(http|https|ftp|ssh):\/\/[a-z0-9][a-z0-9]*\-[a-z0-9]*[a-z0-9](\.[a-z0-9][a-z0-9]*\-[a-z0-9]*[a-z0-9])*\/[a-z0-9][a-z0-9]*\-[a-z0-9]*[a-z0-9](\/[a-z0-9][a-z0-9]*\-[a-z0-9]*[a-z0-9])*((\?[a-z0-9][a-z0-9]*\-[a-z0-9]*[a-z0-9]\=[a-z0-9][a-z0-9]*\-[a-z0-9]*[a-z0-9])(\&[a-z0-9][a-z0-9]*\-[a-z0-9]*[a-z0-9]\=[a-z0-9][a-z0-9]*\-[a-z0-9]*[a-z0-9])*)?$/);
                if (!valid)
                {
                    pporuka("url");
                    inputElement.style.backgroundColor="orangered";
                }
                else inputElement.style.backgroundColor="white";
                var px = /Sljedeca polja nisu validna:$/;
                if (px.test(divElementPoruke.getElementsByTagName("p")[0].innerHTML))
                {
                    divElementPoruke.getElementsByTagName("p")[0].innerHTML="";
                }
                return valid;
            }
        }
    }
    return konstruktor;
}());