var CommitTabela = (function() {

    var tabela;
    var brojc=[];
    var prazna;

    var konstruktor = function(divElement, brojZadataka)
    {
        tabela = document.createElement("table");

        var red = document.createElement("tr");
        var thzad = document.createElement("th");
        var thcom = document.createElement("th");

        thzad.innerHTML = "Zadaci";
        thcom.innerHTML = "Commiti";
        red.appendChild(thzad);
        red.appendChild(thcom);
        tabela.appendChild(red);
        brojc.push(0);
        prazna = true;

        for(var i=0;i<brojZadataka;i++)
        {
            red = document.createElement("tr");
            var data = document.createElement("th");
            var a = document.createElement("a");

            a.setAttribute("href", "https://bitbucket.org/");
            a.innerHTML = "Zadatak " + (i + 1);
            brojc.push(0);
            data.appendChild(a);
            red.appendChild(data);
            tabela.appendChild(red);
        }

        divElement.appendChild(tabela);

        return {
            editujCommit:function(izad, icom, url)
            {
                var redovi = tabela.getElementsByTagName("tr");
                if(izad+1>redovi.length-1) return -1;
                var celije = redovi[izad+1].getElementsByTagName("td");
                if(icom+1>celije.length-1) return -1;
                var link = celije[icom+1].getElementsByTagName("a");
                link[0].href = url;
            },
            dodajCommit:function(izad, url)
            {
                var redovi = tabela.getElementsByTagName("tr");
                var data = document.createElement("td");
                var a = document.createElement("a");
                a.setAttribute("href", url);
                brojc[izad+1]++;
                a.innerHTML = brojc[izad+1];

                var valja = false;

                if(redovi[izad+1].getElementsByTagName("td").length != 0)
                {
                    icelije = redovi[izad+1].getElementsByTagName("td");
                    var ia = icelije[icelije.length-1].getElementsByTagName("a");
                    if(ia[0].textContent!="") valja=true;
                }

                if(redovi[izad+1].getElementsByTagName("td").length == 0) valja = true;

                if(valja)
                {
                    data.appendChild(a);
                    redovi[izad+1].appendChild(data);
                }
                else
                {
                    icelije = redovi[izad+1].getElementsByTagName("td");
                    var ia = icelije[icelije.length-1].getElementsByTagName("a");
                    ia[0].setAttribute("href", url);
                    ia[0].innerHTML = brojc[izad+1];
                    icelije[icelije.length-1].colSpan = 1;
                    var maxcol = 0
                    for(var cc=1;cc<redovi.length;cc++)
                    {
                        ccelije = redovi[cc].getElementsByTagName("td");
                        var colm = ccelije.length + ccelije[ccelije.length-1].colSpan-1;
                        if(colm>maxcol) maxcol=colm;
                    }
                    var raz = maxcol - icelije.length + icelije[icelije.length-1].colSpan-1;
                    if(raz>0)
                    {
                        empt = document.createElement("td");
                        empt.innerHTML = "";
                        var aa = document.createElement("a");
                        aa.innerHTML = "";
                        empt.appendChild(aa);
                        redovi[izad+1].appendChild(empt);
                        if(raz>1) 
                        {
                            icelije = redovi[izad+1].getElementsByTagName("td");
                            icelije[icelije.length-1].colSpan = raz;
                        }
                    }
                }
                
                var head = redovi[0].getElementsByTagName("th");
                head[1].colSpan++;

                if (prazna)
                {
                    prazna=false;
                    for(var k=1;k<redovi.length;k++)
                    {
                        empt = document.createElement("td");
                        empt.innerHTML = "";
                        var aa = document.createElement("a");
                        aa.innerHTML = "";
                        empt.appendChild(aa);
                        if(k!=izad+1)
                        {
                            redovi[k].appendChild(empt);
                        }
                    }
                }
                else
                {
                    icelije = redovi[izad+1].getElementsByTagName("td");
                    for(var k=1;k<redovi.length;k++)
                    {
                        kcelije = redovi[k].getElementsByTagName("td");

                        if(k!=izad+1 && icelije.length + icelije[icelije.length-1].colSpan-1 > kcelije.length + kcelije[kcelije.length-1].colSpan-1)
                        {
                            var aa = kcelije[kcelije.length-1].getElementsByTagName("a");
                            if (aa[0].textContent=="")
                            {
                                kcelije[kcelije.length-1].colSpan++;
                            }
                            else
                            {
                                empt = document.createElement("td");
                                empt.innerHTML = "";
                                var aaa = document.createElement("a");
                                aaa.innerHTML = "";
                                empt.appendChild(aaa);
                                redovi[k].appendChild(empt);
                            }
                        }
                    }
                }
            },
            obrisiCommit:function(izad, icom)
            {
                izad++;
                var redovi = tabela.getElementsByTagName("tr");
                if(izad+1>redovi.length-1) return -1;
                var icelije = redovi[izad].getElementsByTagName("td");
                if(icom>icelije.length-1) return -1;
                icelije[icom].remove();
                var icelije = redovi[izad].getElementsByTagName("td");
                var maxcol = 0
                var kraj=false;
                for(var cc=1;cc<redovi.length;cc++)
                {
                    ccelije = redovi[cc].getElementsByTagName("td");
                    var colm = ccelije.length + ccelije[ccelije.length-1].colSpan-1;
                    var ca = ccelije[ccelije.length-1].getElementsByTagName("a");
                    if(ca[0].textContent=="") colm--;
                    if(colm>maxcol) maxcol=colm;
                    if(colm==0) kraj=true;
                }
                var raz = maxcol - icelije.length + icelije[icelije.length-1].colSpan-1;

                if(kraj && raz==0)
                {
                    for(var cc=1;cc<redovi.length;cc++)
                    {
                        if(cc!=izad)
                        {
                            ccelije = redovi[cc].getElementsByTagName("td");
                            ccelije[0].remove();
                        }
                    }
                    prazna=true;
                }
                else if(raz==0)
                {
                    for(var cc=1;cc<redovi.length;cc++)
                        {
                            if(cc!=izad)
                            {
                                ccelije = redovi[cc].getElementsByTagName("td");
                                if(ccelije[ccelije.length-1].colSpan>1) ccelije[ccelije.length-1].colSpan--;
                                else ccelije[ccelije.length-1].remove();
                            }
                        }
                }
                else
                {
                    empt = document.createElement("td");
                    empt.innerHTML = "";
                    var aa = document.createElement("a");
                    aa.innerHTML = "";
                    empt.appendChild(aa);
                    redovi[izad].appendChild(empt);
                    if(raz>1) 
                    {
                        iicelije = redovi[izad].getElementsByTagName("td");
                        iicelije[icelije.length-1].colSpan = raz;
                    }
                }
            }
        }
    }

    return konstruktor;
}());