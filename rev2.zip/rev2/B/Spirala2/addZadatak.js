var div = document.getElementById("glavniSadrzaj");
var v = new Validacija(div);

function validiraj() {
    var naziv = document.getElementById("nazivZadatka");
    v.naziv(naziv);
}