var commiti, div;

function kreirajTabelicu() {
    if(document.getElementById("commiti")!=null) {
        var element = document.getElementById("commiti");
        element.parentNode.removeChild(element);
    }
    div=document.getElementById("glavniDio");
    var brZadataka = document.getElementById("tempBrojZadatakaInput");
    commiti = new CommitTabela(div, Number(brZadataka.value));
    brZadataka.value="";
}

function dodajCommit() {
    var brZadatka = document.getElementById("tempAddBrojZadatka");
    var url = document.getElementById("tempAddURL");
    commiti.dodajCommit(Number(brZadatka.value), url.value); 
}

function editujCommit() {
    var brZadatka = document.getElementById("tempEditBrojZadatka");
    var brCommita = document.getElementById("tempEditBrojCommita");
    var url = document.getElementById("tempEditURL");
    commiti.editujCommit(Number(brZadatka.value), Number(brCommita.value), url.value);
}

function obrisiCommit() {
    var brZadatka = document.getElementById("tempDeleteBrojZadatka");
    var brCommita = document.getElementById("tempDeleteBrojCommita");
    commiti.obrisiCommit(Number(brZadatka.value), Number(brCommita.value));  
}