div = document.getElementById("glavniSadrzaj");
var v = new Validacija(div);

function validiraj() {
    var ime = document.getElementById("imePrezime");
    var ind = document.getElementById("indeks");
    v.ime(ime);
    v.index(ind);
}

