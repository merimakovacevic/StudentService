var Validacija=(function(){
    //lokalne variable idu ovdje
    
    var konstruktor=function(divElementPoruke){
        p=document.createElement("p");
        p.id="paragraf";
        divElementPoruke.appendChild(p);
        p.textContent="";

        return {
            ime:function(inputElement){
                p.textContent="";
                var ime = inputElement.value;
                var reg = /^(([A-Z][a-zA-Z]*[\']?[A-Za-z]+)+[\s-]?){0,3}([A-Z][a-zA-Z]*[\']?[A-Za-z]+)+$/;
                var ispravno=reg.test(ime);
                if(ispravno) {
                    inputElement.style.backgroundColor = "white";
                    p.textContent=p.textContent.replace('ime', '');
                    if(p.textContent==="Sljedeća polja nisu validna:!")
                        p.textContent="";
                }
                else {
                    if(p.textContent==="") p.textContent="Sljedeća polja nisu validna:!";
                    inputElement.style.backgroundColor = "orangered";
                    p.textContent=p.textContent.replace('ime', '');
                    var niz = p.textContent.split("!");
                    if(p.textContent==="Sljedeća polja nisu validna:!") p.textContent = niz[0] + "ime!";
                    else p.textContent = niz[0] + ",ime!";
                }  
            },
            godina:function(inputElement){
                var god = inputElement.value;
                var ispravno;
                var reg = /20\d\d\/20\d\d$/;
                ispravno=reg.test(god);
                var godine=god.split("/");
                if((parseInt(godine[1])-parseInt(godine[0]))!=1) ispravno=false;
                if(ispravno) {
                    inputElement.style.backgroundColor = "white";
                    p.textContent=p.textContent.replace('godina', '');
                    if(p.textContent==="Sljedeća polja nisu validna:!")
                        p.textContent="";
                }
                else {
                    if(p.textContent==="") p.textContent="Sljedeća polja nisu validna:!";
                    inputElement.style.backgroundColor = "orangered";
                    p.textContent=p.textContent.replace('godina', '');
                    var niz = p.textContent.split("!");
                    if(p.textContent==="Sljedeća polja nisu validna:!") p.textContent = niz[0] + "godina!";
                    else p.textContent = niz[0] + ",godina!";
                }  
            },
            repozitorij:function(inputElement, regex) {
                var repo = inputelement.value;
                var ispravno = regex.test(repo);
                if(ispravno) {
                    inputElement.style.backgroundColor = "white";
                    p.textContent=p.textContent.replace('repozitorij', '');
                    if(p.textContent==="Sljedeća polja nisu validna:!")
                        p.textContent="";
                }
                else {
                    if(p.textContent==="") p.textContent="Sljedeća polja nisu validna:!";
                    inputElement.style.backgroundColor = "orangered";
                    p.textContent=p.textContent.replace('repozitorij', '');
                    var niz = p.textContent.split("!");
                    if(p.textContent==="Sljedeća polja nisu validna:!") p.textContent = niz[0] + "repozitorij!";
                    else p.textContent = niz[0] + ",repozitorij!";
                }
            },
            index:function(inputElement){ 
                var indeks = inputElement.value;
                var reg = /(14|15|16|17|18|19|20)\d{3}$/;
                var ispravno = reg.test(indeks);
                if(ispravno) {
                    inputElement.style.backgroundColor = "white";
                    p.textContent=p.textContent.replace('index', '');
                    if(p.textContent==="Sljedeća polja nisu validna:!")
                        p.textContent="";
                }
                else {
                    if(p.textContent==="") p.textContent="Sljedeća polja nisu validna:!";
                    inputElement.style.backgroundColor = "orangered";
                    p.textContent=p.textContent.replace('index', '');
                    var niz = p.textContent.split("!");
                    if(p.textContent==="Sljedeća polja nisu validna:!") p.textContent = niz[0] + "index!";
                    else p.textContent = niz[0] + ",index!";
                }
            },
            naziv:function(inputElement){
                var naziv = inputElement.value;
                var regex = /^([A-Za-z]+)([A-Za-z0-9\\\/\-\"\'\!\?\:\;\,]+)([0-9a-z]+)$/;
                var ispravno = regex.test(naziv);
                if(ispravno) {
                    inputElement.style.backgroundColor = "white";
                    p.textContent=p.textContent.replace('naziv', '');
                    if(p.textContent==="Sljedeća polja nisu validna:!")
                        p.textContent="";
                }
                else {
                    if(p.textContent==="") p.textContent="Sljedeća polja nisu validna:!";
                    inputElement.style.backgroundColor = "orangered";
                    p.textContent=p.textContent.replace('naziv', '');
                    var niz = p.textContent.split("!");
                    if(p.textContent==="Sljedeća polja nisu validna:!") p.textContent = niz[0] + "naziv!";
                    else p.textContent = niz[0] + ",naziv!";
                }  
            },
            password:function(inputElement){
                var pass = inputElement.value;
                var regex = /^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9])))[a-zA-Z0-9]{8,}$/;
                var ispravno = regex.test(pass);
                if(ispravno) {
                    inputElement.style.backgroundColor = "white";
                    p.textContent=p.textContent.replace('password', '');
                    if(p.textContent==="Sljedeća polja nisu validna:!")
                        p.textContent="";
                }
                else {
                    if(p.textContent==="") p.textContent="Sljedeća polja nisu validna:!";
                    inputElement.style.backgroundColor = "orangered";
                    p.textContent=p.textContent.replace('password', '');
                    var niz = p.textContent.split("!");
                    if(p.textContent==="Sljedeća polja nisu validna:!") p.textContent = niz[0] + "password!";
                    else p.textContent = niz[0] + ",password!";
                }  
            },
            url:function(inputElement){
                var regex = /^(http|https|ftp|ssh)\:\/\/([a-z0-9]+([-]*[a-z0-9]+)*(\.[a-z0-9]+([-]*[a-z0-9]+)*)*)+(\/[a-z0-9]+([-]*[a-z0-9]+)*)*(\?([a-z0-9]+([-]*[a-z0-9]+)*\=[a-z0-9]+([-]*[a-z0-9]+)(\&[a-z0-9]+([-]*[a-z0-9]+)*\=[a-z0-9]+([-]*[a-z0-9]+)*)*)+)*$/;
                var url = inputElement.value;
                var ispravno=regex.text(url);
                if(ispravno) {
                    inputElement.style.backgroundColor = "white";
                    p.textContent=p.textContent.replace('url', '');
                    if(p.textContent==="Sljedeća polja nisu validna:!")
                        p.textContent="";
                }
                else {
                    if(p.textContent==="") p.textContent="Sljedeća polja nisu validna:!";
                    inputElement.style.backgroundColor = "orangered";
                    p.textContent=p.textContent.replace('url', '');
                    var niz = p.textContent.split("!");
                    if(p.textContent==="Sljedeća polja nisu validna:!") p.textContent = niz[0] + "url!";
                    else p.textContent = niz[0] + ",url!";
                }
            }
        }
    }
    return konstruktor;
}());