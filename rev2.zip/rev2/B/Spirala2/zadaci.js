var div = document.getElementById("student_cetvrtina");
var v = new Validacija(div);

function validiraj() {
    var ime = document.getElementById("queryIme");
    v.ime(ime);  
}