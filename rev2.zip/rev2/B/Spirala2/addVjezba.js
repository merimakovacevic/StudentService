var div = document.getElementById("glavniSadrzaj");
var v = new Validacija(div);

function validiraj() {
    var naziv = document.getElementById("nazivNoveVjezbe");
    v.naziv(naziv);
}