div = document.getElementById("side");
var v = new Validacija(div);

function validiraj() {
    var god = document.getElementById("nazivGodine");
    var repV = document.getElementById("repoVjezbe");
    var repS = document.getElementById("repoSpirale");
    v.godina(god);
    v.repozitorij(repV);
    v.repoztorij(repS);
}