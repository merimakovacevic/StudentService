var CommitTabela = (function() { 
    
    var konstruktor=function(divElement, brojZadataka){ 
        var tabela="<table id="+"commiti"+">";
        tabela+="<tr><th>Zadaci</th><th>Commiti</th></tr>";
        for(var i=0; i<brojZadataka; i++)
            tabela+="<tr><td>Zadatak " + (i+1) + "</td><td></td></tr>";
        tabela+="</table>";
        divElement.innerHTML+=tabela;

        return {
            dodajCommit:function (rbZadatka, url) {
                var tabelica=document.getElementById("commiti");
                var posljednja=0, brojcelija=1;
                var elementiCelije = [];
                var red;
                for(var i=1; i<tabelica.rows[rbZadatka+1].cells.length; i++)
                    if(tabelica.rows[rbZadatka+1].cells[i].innerHTML!='') 
                        brojcelija++;
                for(var i=1; i<brojcelija; i++){
                    if(tabelica.rows[rbZadatka+1].cells[i].textContent!="") 
                        elementiCelije.push(tabelica.rows[rbZadatka+1].cells[i].textContent);
                }
                tabelica.deleteRow(rbZadatka+1);
                red = tabelica.insertRow(rbZadatka+1);
                var celija1 = red.insertCell(0);
                celija1.innerHTML = "Zadatak " + (rbZadatka+1);
                for(var i=0; i<elementiCelije.length; i++){
                    var celija = red.insertCell(i+1);
                    celija.innerHTML = "<a href="+url+">"+elementiCelije[i]+"</a>";
                }
                var celija = red.insertCell(elementiCelije.length+1);
                if(elementiCelije.length==0) 
                    celija.innerHTML = "<a href="+url+">"+1+"</a>";
                else 
                    celija.innerHTML = "<a href="+url+">"+(Number(elementiCelije[elementiCelije.length-1])+1)+"</a>";

                for(var i=1; i<tabelica.rows.length; i++)
                    if(tabelica.rows[i].cells.length>posljednja) 
                        posljednja=tabelica.rows[i].cells.length;
                tabelica.rows[0].cells[1].colSpan=posljednja;
                for(var i=1; i<tabelica.rows.length; i++){
                    var brojcelija1;
                    if(tabelica.rows[i].cells[1].innerHTML==='')
                        brojcelija1=1;
                    else 
                        brojcelija1=tabelica.rows[i].cells.length;
                    if(brojcelija1<posljednja) 
                        if(tabelica.rows[i].cells[1].innerHTML==='') 
                            tabelica.rows[i].cells[1].colSpan=posljednja-brojcelija1;
                        else 
                            if(tabelica.rows[i].cells[brojcelija1-1].innerHTML!=''){
                                var celija=tabelica.rows[i].insertCell(brojcelija1);
                                tabelica.rows[i].cells[brojcelija1].colSpan=posljednja-brojcelija1+1;
                            }
                            else
                                tabelica.rows[i].cells[brojcelija1-1].colSpan=posljednja-brojcelija1+1;   
                }
            }, 
            editujCommit:function(rbZadatka, rbCommita, url) {
                var tabelica=document.getElementById("commiti");
                if(rbZadatka<0 || rbZadatka>tabelica.rows.length-2 || rbCommita<0 || rbCommita>tabelica.rows[rbZadatka+1].cells.length-2) 
                    return -1;
                tabelica.rows[rbZadatka+1].cells[rbCommita+1].innerHTML="<a href="+String(url)+">"+(rbCommita+1)+"</a>";
            }, 
            obrisiCommit:function(rbZadatka, rbCommita) {
                var tabelica=document.getElementById("commiti");
                var max=0;
                var brCelija=1;
                var elementiReda = [];
                var red;
                if(rbZadatka<0 || rbZadatka>tabelica.rows.length-2 || rbCommita<0 || rbCommita>tabelica.rows[rbZadatka+1].cells.length-2) 
                    return -1;
                for(var i=rbCommita+1; i<tabelica.rows[rbZadatka+1].cells.length-1; i++) 
                    tabelica.rows[rbZadatka+1].cells[i].innerHTML=tabelica.rows[rbZadatka+1].cells[i+1].innerHTML;
                tabelica.rows[rbZadatka+1].cells[tabelica.rows[rbZadatka+1].cells.length-1].innerHTML="";
                for(var i=1; i<tabelica.rows[rbZadatka+1].cells.length; i++) if(tabelica.rows[rbZadatka+1].cells[i].innerHTML!='') 
                    brCelija++;
                for(var i=1;i<brCelija;i++){
                    if(tabelica.rows[rbZadatka+1].cells[i].textContent!="") 
                        elementiReda.push(tabelica.rows[rbZadatka+1].cells[i].textContent);
                }
                if(elementiReda.length===0) 
                    elementiReda.push("");
                tabelica.deleteRow(rbZadatka+1);
                red = tabelica.insertRow(rbZadatka+1);
                var nova = red.insertCell(0);
                nova.innerHTML = "Zadatak " + (rbZadatka+1);
                for(var i=0; i<elementiReda.length; i++){
                    var celija = red.insertCell(i+1);
                    if(elementiReda[0]==="") 
                        celija.innerHTML = "";
                    else 
                        celija.innerHTML = elementiReda[i];
                }
                for(var i=1; i<tabelica.rows.length; i++)
                    if(tabelica.rows[i].cells.length>max) 
                        max=tabelica.rows[i].cells.length;
                tabelica.rows[0].cells[1].colSpan=max;
                for(var i=1; i<tabelica.rows.length; i++){
                    var noviBr= tabelica.rows[i].cells.length;
                    if(noviBr===2) {
                        if(tabelica.rows[i].cells[1].innerHTML!="") {
                            var celija=tabelica.rows[i].insertCell(noviBr);
                            celija.innerHTML="";
                            tabelica.rows[i].cells[noviBr].colSpan=max-noviBr+1;
                        }
                        else 
                            tabelica.rows[i].cells[1].colSpan=max-1;
                    }
                    else 
                        if(noviBr<max){
                            if(tabelica.rows[i].cells[noviBr-1].innerHTML!=""){
                                var celija=tabelica.rows[i].insertCell(noviBr);
                                celija.innerHTML="";
                                tabelica.rows[i].cells[noviBr].colSpan=max-noviBr+1;
                            }
                            else
                                tabelica.rows[i].cells[noviBr-1].colSpan=max-noviBr+1;
                        }
                }
                for(var i=1; i<tabelica.rows.length; i++) 
                    if(tabelica.rows[i].cells.length>max) 
                        max=tabelica.rows[i].cells.length;
                var predzadnji=true;
                for(var i=1; i<tabelica.rows.length; i++) {
                    var noviBr= tabelica.rows[i].cells.length;
                    if(noviBr===max) 
                        for(var j=1; j<tabelica.rows.length; j++)
                            if(tabelica.rows[i].cells[noviBr-1].innerHTML!="" && noviBr===max) 
                            predzadnji=false;
                }          
                if(predzadnji) {
                    for(var i=1; i<tabelica.rows.length; i++){
                        var noviBr= tabelica.rows[i].cells.length;
                        if(noviBr===max){
                            tabelica.rows[i].deleteCell(noviBr-1);
                        }
                    }
                } 
                var prazna = true;
                for(var i=1; i<tabelica.rows.length; i++) {
                    var noviBr= tabelica.rows[i].cells.length;
                    if(noviBr!=1) 
                        prazna=false;
                }
                if(prazna) {
                    for(var i=1; i<tabelica.rows.length; i++){
                        var celija=tabelica.rows[i].insertCell(1);
                        celija.innerHTML="";
                        tabelica.rows[i].cells[noviBr].colSpan=1;
                    }
                }
            }
        } 
    }
    return konstruktor;
}());


