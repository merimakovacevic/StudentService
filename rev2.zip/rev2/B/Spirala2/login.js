var div = document.getElementById("login");
var v = new Validacija(div);

function validiraj() {
    var ime = document.getElementById("usname");
    var pass = document.getElementById("pass");
    v.ime(ime);
    v.password(pass);
}