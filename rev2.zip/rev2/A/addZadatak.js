function Validiraj()
{
    var div = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(div);
    var inputNaziv = document.getElementById("naziv");
    var poruka = "Sljedeća polja nisu validna: ";
    var greska = "";

    if(validacija.naziv(inputNaziv))
    {
        inputNaziv.style.backgroundColor = "white";
        poruka = "";
    }
    else
    {
        inputNaziv.style.backgroundColor = "orangered";
        greska = "naziv zadatka"
    }
    div.innerHTML = poruka + greska;
}