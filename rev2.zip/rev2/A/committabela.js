var CommitTabela=(function()
{
    var konstruktor=function(divElement,brojZadataka)
    {
        var body = document.body;
        tabela = document.createElement('table');
        tabela.id = "tabela";
        tabela.style.border = '1px solid black';
        for(var i = 0; i < brojZadataka+1; i++){
            var tr = tabela.insertRow();
            for(var j = 0; j < 2; j++){
                var td = tr.insertCell();
                if (j == 0 && i > 0) { td.appendChild(document.createTextNode('Zadatak '+i)); }
                if (i == 0 && j == 0) { td.appendChild(document.createTextNode('Zadaci')); }
                if (i == 0 && j == 1) { td.appendChild(document.createTextNode('Commiti')); }
                td.style.border = '1px solid black';
            }
            
        }
        body.appendChild(divElement);
        divElement.appendChild(tabela);

    return{
    dodajCommit:function(rbZadatka,url)
    {
        var red = document.getElementById("tabela").rows[rbZadatka];
        var celije = red.cells;
        var duzina = celije.length;
        var brRedova = document.getElementById("tabela").rows.length;
        var i;
        var a = document.createElement("a");
        var nova;
        var col = 0;
        var noviRed;
        var j = 0;
        for (i = 1; i < brRedova; i++)
        {
            if (i == rbZadatka && celije[duzina-1].textContent == '' && celije[duzina-1].colSpan == 1)
            {
                a.setAttribute('href', url);
                a.textContent = duzina-1;
                celije[duzina-1].appendChild(a);
                break;
            }            

            if (i == rbZadatka && celije[duzina-1].textContent != '')
            {
                a.setAttribute('href',url);
                a.textContent = duzina;
                nova = red.insertCell(-1);
                nova.appendChild(a);
                nova.colSpan = 1;
                nova.style.border = '1px solid black';
                for (j = 0; j < brRedova; j++)
                {
                    noviRed = document.getElementById("tabela").rows[j];
                    if (j == 0)
                    {
                        noviRed.cells[noviRed.cells.length-1].colSpan++;
                    }
                    if (j != rbZadatka && noviRed.cells[noviRed.cells.length-1].textContent == '' && j != 0)
                    {
                        noviRed.cells[noviRed.cells.length-1].colSpan++;
                    }
                    
                    if (j != rbZadatka && noviRed.cells[noviRed.cells.length-1].textContent != '' && j != 0)
                    {
                        nova = noviRed.insertCell(-1);
                        nova.colSpan = 1;
                        nova.style.border = '1px solid black';
                    }
                }
                break;
            }

            if (i == rbZadatka && celije[duzina-1].textContent == '' && celije[duzina-1].colSpan != 1)
            {
                a.setAttribute('href', url);
                a.textContent = duzina-1;
                celije[duzina-1].appendChild(a);
                col = celije[duzina-1].colSpan;
                celije[duzina-1].colSpan = 1;
                nova = red.insertCell(-1);
                nova.colSpan = col - 1;
                nova.style.border = '1px solid black';
                break;
            }
        }
    
                    
    },
    editujCommit:function(rbZadatka,rbCommita,url)
    {
        if(rbZadatka >= document.getElementById("tabela").rows.length || rbZadatka <= 0) return -1;
        if(rbCommita <= 0) return -1;

        var postoji = false;
        var i;
        var duzina = document.getElementById("tabela").rows[rbZadatka].cells.length;
        var celije = document.getElementById("tabela").rows[rbZadatka].cells;
        var celija;
        var a = document.createElement("a");
        
        for (i = 1; i < duzina; i++)
        {
            if (celije[i].textContent == String(rbCommita)) 
            {
                postoji = true;
                celije[i] = celije[i].removeChild(celije[i].firstChild);
                a.setAttribute('href', url);
                a.textContent = rbCommita;
                celije[i].appendChild(a);
            }
        }
        if (!(postoji)) return -1;

    },
    obrisiCommit:function(rbZadatka,rbCommita)
    {

        if(rbZadatka >= document.getElementById("tabela").rows.length || rbZadatka <= 0) return -1;
        if(rbCommita <= 0) return -1;
        
        
        var i;
        var jediniNajveci = true;
        var postoji = false;
        var brRedova = document.getElementById("tabela").rows.length;
        var duzina = document.getElementById("tabela").rows[rbZadatka].cells.length;
        var celije = document.getElementById("tabela").rows[rbZadatka].cells;
        var red = document.getElementById("tabela").rows[rbZadatka];
        var r;
        var nova;
        var col;
        var j;
        var maxDuzina = 0;
        var indeksNajveceg = 0;

        for (i = 1; i < duzina; i++)
        {
            if (celije[i].textContent == String(rbCommita)) postoji = true;
        }
        if (!(postoji)) return -1;

        for (i = 0; i < brRedova; i++)
        {
            r = document.getElementById("tabela").rows[i].cells;
            if (r.length >= duzina && i != rbZadatka) jediniNajveci = false;         
        }

        for (i = 1; i < duzina; i++)
        {
            if (celije[i].textContent == String(rbCommita))
            {
                red.deleteCell(i);
                break;
            }
        }
        duzina--;
        
        //trazimo trenutni najduzi red
        maxDuzina = document.getElementById("tabela").rows[0].cells.length;
        for (i = 1; i < brRedova; i++)
        {
            r = document.getElementById("tabela").rows[i].cells;
            if (r.length > maxDuzina)
            {
                maxDuzina = r.length;
                indeksNajveceg = i;
            }   
        }
        
        //red iz kojeg brisemo je najduzi
        if (jediniNajveci)
        {
            for (j = 0; j < brRedova; j++)
            {
                r = document.getElementById("tabela").rows[j];
                if (rbZadatka != j) 
                { 
                    r.cells[r.cells.length-1].colSpan--; 
                }
            }
        }
        //red iz kojeg brisemo je za 1 celiju manji od najduzeg
        else if (maxDuzina == duzina+1)
        {
            nova = red.insertCell(-1);
            nova.colSpan = 1;
            nova.style.border = '1px solid black';
        }
        //ostali slucajevi
        else
        {
            celije[duzina-1].colSpan++;
        }
    }
    }
    }
    return konstruktor;
}());
