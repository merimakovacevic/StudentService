function Funkcija()
{
    var mojDiv=document.getElementById("mojDiv");
    var tabela = new CommitTabela(mojDiv,8);
}