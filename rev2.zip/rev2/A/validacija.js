var Validacija=(function(){

var konstruktor=function(divElementPoruke)
{

return{
ime:function(inputElement)
{
    var imeRegex = /([A-Z]{1}'?[a-z]{1,})([- ]{1}[A-Z]{1}'?[a-z]{1,})?([- ]{1}[A-Z]{1}'?[a-z]{1,})?([- ]{1}[A-Z]{1}'?[a-z]{1,})?/;
    if (inputElement.value == '' || !(inputElement.value.match(imeRegex))) 
    { 
        return false;
    }
    return true;
},
godina:function(inputElement){
    var tekst = inputElement.value;
    if (tekst[0] != '2' || tekst[5] != '2' || tekst[1] != '0' || tekst[6] != '0' || tekst[4] != '/')
    {
        
        return false;
    }
    var broj1 = tekst[2];
    var broj2 = tekst[3];
    var b = Number(broj1+broj2);

    broj1 = tekst[7];
    broj2 = tekst[8];
    var c = Number(broj1+broj2)
    if (c-b != 1) 
    {
        return false;
    }
    return true;
},

repozitorij:function(inputElement,regex){
    if (!(inputElement.value.match(regex))) return false;
    return true;
},
index:function(inputElement){
    var indexRegex = /(1[4-9]\d{3})|(20\d{3})/;
    if (inputElement.value == '' || !(inputElement.value.match(indexRegex))) return false;
    return true;
},
naziv:function(inputElement){
    var dozvoljeni = ["\\", "/", "-", "\"", "'", "!", "?", ":", ";", ","];
    if (inputElement.value == '' || !(inputElement.value[0].match(/[A-Za-z]/))) 
    {
        return false;
    }
    if (!(inputElement.value[inputElement.value.length-1].match(/[a-z]/)) && !(inputElement.value[inputElement.value.length-1].match(/[0-9]/))) 
    {
        return false;
    }
    var i;
    var j;
    var slova = 0;
    var ok = false;
    for (i = 0; i < inputElement.value.length; i++)
    {
        if (inputElement.value[i].match(/[A-Za-z]/)) { slova++; }
    }
    if (slova < 3) return false;
    var znakovi = "";
    for (i = 0; i<inputElement.value.length; i++)
    {
        if (!(inputElement.value[i].match(/[A-Za-z\d]/))) { znakovi += inputElement.value[i]; }
    }
    for (i = 0; i < znakovi.length; i++)
    {
        ok = false;
        for (j = 0; j < dozvoljeni.length; j++)
        {
            if (znakovi[i] == dozvoljeni[j]) { ok = true; }
        }
        if (ok == false) return false;
    }
    return true;
},
password:function(inputElement){
    if (inputElement.value.length < 8) { return false; }
    
    var slovaM = 0;
    var brojevi = 0;
    var ostali = 0;
    var slovaV = 0;
    var i;
    for (i = 0; i < inputElement.value.length; i++)
    {
        if (inputElement.value[i].match(/[A-Z]/)) { slovaV++; }
        else if (inputElement.value[i].match(/[a-z]/)) { slovaM++; }
        else if (inputElement.value[i].match(/\d/)) { brojevi++; }
        else { ostali++; }
    }

    if (ostali != 0) { return false; }
    if (slovaV == 0 && slovaM == 0 && brojevi > 0) { return false; }
    if (slovaV == 0 && slovaM > 0 && brojevi == 0) { return false; }
    if (slovaV > 0 && slovaM == 0 && brojevi == 0) { return false; }
    return true;
},
url:function(inputElement){
    if (inputElement.value = '') return false;
    var protokol = ["http", "https", "ftp", "ssh"];
    var protokolT = "";
    var i = 0;
    while (inputElement.value[i] != ":")
    {
        protokolT += inputElement.value[i];
        i++;
        if (i == inputElement.value.length-1) { return false; }
    }
    var j = i;
    var ok = false;
    for (i = 0; i < protokol.length; i++)
    {
        if (protokolT == protokol[i]) { ok = true; }
    }
    if (ok == false) { return false; }
    if (inputElement.value[j] != ":") { return false; }
    if (inputElement.value[j+1] != "/") { return false; }
    if (inputElement.value[j+2] != "/") { return false; }
    j = j+3;
    var host = "";
    var hostRegex = /(([a-z\d]{1}[a-z\d\-]*[a-z\d]{1})|([a-z\d])){1,}(\.([a-z\d]{1}[a-z\d\-]*[a-z\d]{1})|([a-z\d]))*/;
    while (inputElement.value[j] != "/" && j < inputElement.value.length)
    {
        host = host + inputElement.value[j];
        j++;
    }
    if (!(host.match(hostRegex))) { return false; }
    var putanjaRegex = /(([a-z\d]{1}[a-z\d\-]*[a-z\d]{1})|([a-z\d])){1,}(\/([a-z\d]{1}[a-z\d\-]*[a-z\d]{1})|([a-z\d]))*/;
    var putanja = "";
    if (j != inputElement.value.length)
    {
        j++;
        while (inputElement.value[j] != "?" && j < inputElement.value.length)
        {
            putanja += inputElement.value[j];
            j++;
        }
        if (!(putanja.match(putanjaRegex))) { return false; }
        var parametri = "";
        var parametriRegex = /(([a-z\d]{1}[a-z\d\-]*[a-z\d]{1})|([a-z\d])){1,}\=(([a-z\d]{1}[a-z\d\-]*[a-z\d]{1})|([a-z\d])){1,}\&(([a-z\d]{1}[a-z\d\-]*[a-z\d]{1})|([a-z\d])){1,}\=(([a-z\d]{1}[a-z\d\-]*[a-z\d]{1})|([a-z\d])){1,}/
        if (j != inputElement.value.length)
        {
            j++;
            while (j < inputElement.value.length)
            {
                parametri += inputElement.value;
                j++;
            }
            if (!(parametri.match(parametriRegex))) { return false; }
        }
    }
    return true;
}
}
}
return konstruktor;
}());
