function Validiraj()
{
    var div = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(div);
    var inputNaziv = document.getElementById("naziv");
    var inputPassword = document.getElementById("pass");
    var poruka = "Sljedeća polja nisu validna:";

    var brojac1 = 0;
    var brojac2 = 0;
    var greska = ["", ""];

    if(validacija.naziv(inputNaziv))
    {
        inputNaziv.style.backgroundColor = "white";
        brojac1 = 0;
    }
    else
    {
        inputNaziv.style.backgroundColor = "orangered";
        greska[0] = " username"
        brojac1++;
    }
    if(validacija.password(inputPassword))
    {
        inputPassword.style.backgroundColor = "white";
        brojac2 = 0;
    }
    else
    {
        inputPassword.style.backgroundColor = "orangered";
        greska[1] = " password"
        brojac2++;
    }
    if (brojac1 == 0 && brojac2 == 0) div.innerHTML = "";
    else if (brojac2 != 0 && brojac1 == 0) div.innerHTML = poruka + greska[1];
    else if (brojac1 != 0 && brojac2 == 0) div.innerHTML = poruka + greska[0];
    else div.innerHTML = poruka + greska[0] + "," + greska[1];
}