function Validiraj()
{
    var div = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(div);
    var inputNaziv = document.getElementById("nazivVjezbe");
    var poruka = "Sljedeća polja nisu validna: ";

    //var brojac = 0;
    var greska = "";

    if(validacija.naziv(inputNaziv))
    {
        document.getElementById("nazivVjezbe").style.backgroundColor = "white";
        poruka = "";
    }
    else
    {
        document.getElementById("nazivVjezbe").style.backgroundColor = "orangered";
        greska += " naziv vježbe";
        //brojac++;
    }
    div.innerHTML = poruka + greska;
}