function Validiraj()
{
    var div = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(div);
    var inputIme = document.getElementById("ime");
    var inputIndex = document.getElementById("index");
    var poruka = "Sljedeća polja nisu validna:";

    var brojac1 = 0;
    var brojac2 = 0;
    var greska = ["", ""];

    if(validacija.ime(inputIme))
    {
        inputIme.style.backgroundColor = "white";

        brojac1 = 0;
    }
    else
    {
        inputIme.style.backgroundColor = "orangered";
        greska[0]= " ime i prezime";
        brojac1++;
    }
    if(validacija.index(inputIndex))
    {
        inputIndex.style.backgroundColor = "white";

        brojac2 = 0;
    }
    else
    {
        inputIndex.style.backgroundColor = "orangered";
        greska[1] = " index";
        brojac2++;
    }
    if (brojac1 == 0 && brojac2 == 0) div.innerHTML = "";
    else if (brojac2 != 0 && brojac1 == 0) div.innerHTML = poruka + greska[1];
    else if (brojac1 != 0 && brojac2 == 0) div.innerHTML = poruka + greska[0];
    else div.innerHTML = poruka + greska[0] + "," + greska[1];
    
}