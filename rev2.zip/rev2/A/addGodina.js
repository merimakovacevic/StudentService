function Validiraj()
{
    var div = document.getElementById("mojDivPoruke");
    var validacija = new Validacija(div);
    var inputGodina = document.getElementById("naziv");
    var inputVjezbe = document.getElementById("rvjezbe");
    var inputSpirale = document.getElementById("rspiral");
    var poruka = "Sljedeća polja nisu validna:";

    var brojac1 = 0;
    var brojac2 = 0;
    var brojac3 = 0;
    var greska = ["", "", ""];

    if(validacija.godina(inputGodina))
    {
        inputGodina.style.backgroundColor = "white";

        brojac1 = 0;
    }
    else
    {
        inputGodina.style.backgroundColor = "orangered";
        greska[0]= " godina";
        brojac1++;
    }
    if(validacija.naziv(inputVjezbe))
    {
        inputVjezbe.style.backgroundColor = "white";

        brojac2 = 0;
    }
    else
    {
        inputVjezbe.style.backgroundColor = "orangered";
        greska[1] = " naziv vježbi";
        brojac2++;
    }
    if(validacija.naziv(inputSpirale))
    {
        inputSpirale.style.backgroundColor = "white";

        brojac3 = 0;
    }
    else
    {
        inputSpirale.style.backgroundColor = "orangered";
        greska[2] = " naziv spirala";
        brojac3++;
    }
    if (brojac1 == 0 && brojac2 == 0 && brojac3 == 0) div.innerHTML = "";
    else if (brojac2 != 0 && brojac1 == 0 && brojac3 == 0) div.innerHTML = poruka + greska[1];
    else if (brojac1 != 0 && brojac2 == 0 && brojac3 == 0) div.innerHTML = poruka + greska[0];
    else if (brojac1 == 0 && brojac2 == 0 && brojac3 != 0) div.innerHTML = poruka + greska[2];
    else if (brojac1 != 0 && brojac2 != 0 && brojac3 == 0) div.innerHTML = poruka + greska[0] + "," + greska[1];
    else if (brojac1 != 0 && brojac2 == 0 && brojac3 != 0) div.innerHTML = poruka + greska[0] + "," + greska[2];
    else if (brojac1 == 0 && brojac2 != 0 && brojac3 != 0) div.innerHTML = poruka + greska[1] + "," + greska[2];
    else div.innerHTML = poruka + greska[0] + "," + greska[1] + "," + greska[2];
    
}