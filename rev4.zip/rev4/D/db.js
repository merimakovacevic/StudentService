//konekcija

const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const sequelize = new Sequelize("wt2018","root","root",{host:"localhost",dialect:"mysql",operatorsAliases:false});
const db={};

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

//import modela
db.student = sequelize.import(__dirname+'/public'+'/student.js');
db.vjezba = sequelize.import(__dirname+'/public'+'/vjezba.js');
db.zadatak = sequelize.import(__dirname+'/public'+'/zadatak.js');
db.godina = sequelize.import(__dirname+'/public'+'/godina.js');

//relacije
// veza 1-n, vise studenata pripada jednoj godini 
db.godina.hasMany(db.student,{foreignKey:'studentGod',as:'studenti'});
//veza n-m
db.godinaVjezba1 = db.godina.belongsToMany(db.vjezba,{foreignKey:'idgodina',as:'vjezbe', through:'godina_vjezba'});
db.godinaVjezba2 = db.vjezba.belongsToMany(db.godina,{foreignKey:'idvjezba',as:'godine', through:'godina_vjezba'})
db.vjezbaZadatak1 = db.vjezba.belongsToMany(db.zadatak,{foreignKey:'idzadatak', as:'zadaci', through:'vjezba_zadatak'});
db.vjezbaZadatak2 = db.zadatak.belongsToMany(db.vjezba,{foreignKey:'idvjezba', as:'vjezbe', through:'vjezba_zadatak'});

//console.log("poslije veza");
module.exports=db;

//console.log("sami kraj");
