var express = require('express');
var app = express();
var path = require('path');
const fs=require('fs');
const url=require('url');
const bodyParser=require('body-parser');
app.use(bodyParser.json());
const Folder = './public/zad/';
var format = require('xml-formatter');
var multer = require('multer');
const db = require('./db.js');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
//konekcija, kreiranje tabela i ubacivanje pocenih podataka

/// zadaci spirale 4 su na kraju!!!!!!
db.sequelize.sync().then(function(){
    inicializacija().then(function(){
        console.log("Gotovo kreiranje tabela!");
        
    });
}); 
function inicializacija(){
    var studentiLista =[];
    var godineLista = [];
    var vjezbeLista = [];
    var zadaciLista = [];

return new Promise(function(resolve,reject){
    //neke vrijednosti u bazi
   /* godina1 = godineLista.push(db.godina.create({nazivGod:"2018/2019",nazivRepSpi:"Spirala",nazivRepVje:"Vjezba"}));
    godina2 = godineLista.push(db.godina.create({nazivGod:"2017/2018",nazivRepSpi:"Spirala",nazivRepVje:"Vjezba"}));
    godina3 = godineLista.push(db.godina.create({nazivGod:"2016/2017",nazivRepSpi:"Spirala",nazivRepVje:"Vjezba"}));
    studentiLista.push(db.student.create({imePrezime:"Can Divit", index:17000, studentGod:1}));
    studentiLista.push(db.student.create({imePrezime:"Sanem Aydin", index:17100,studentGod:2}));
    studentiLista.push(db.student.create({imePrezime:"Cey Cey", index:17200,studentGod:2}));
    vjezbeLista.push(db.vjezba.create({naziv:"Vjezba1", spirala:false}));
    vjezbeLista.push(db.vjezba.create({naziv:"Vjezba2", spirala:true}));
    vjezbeLista.push(db.vjezba.create({naziv:"Vjezba3", spirala:false}));
    zadaciLista.push(db.zadatak.create({naziv:"Zadatak1", postavka:"http://localhost:8080/public/zad/Zadatak1.pdf"}));
    zadaciLista.push(db.zadatak.create({naziv:"Zadatak2", postavka:"http://localhost:8080/public/zad/Zadatak2.pdf"}));
    zadaciLista.push(db.zadatak.create({naziv:"Zadatak3", postavka:"http://localhost:8080/public/zad/Zadatak3.pdf"}));
    Promise.all(studentiLista).then(function(b){resolve(b);}).catch(function(err){console.log("studenti greska "+err);});
    Promise.all(zadaciLista).then(function(b){resolve(b);}).catch(function(err){console.log("zadaci greska "+err);});
    Promise.all(vjezbeLista).then(function(b){resolve(b);}).catch(function(err){console.log("vjezbe greska "+err);});
    Promise.all(godineLista).then(function(b){resolve(b);}).catch(function(err){console.log("godine greska "+err);});*/
});   
}
db.sequelize.sync();
//Spirala 3 -Zadatak 1 [0.5b] ---- URADJENO
app.use(express.static("public"));
//Spirala 3 - Zadatak 2* [2.5b] ---- URADJENO ---- Spirala 4 - ISPRAVLJENO DA UPISUJE U BAZU
var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, path.join(__dirname+'/public/zad'))
  },
  filename:function(req, file, callback){
    callback(null, req.body.naziv+'.pdf');
  }
});
var upload = multer({
  storage: storage,
  fileFilter: function(req, file, callback){
    if(path.extname(file.originalname)!=='.pdf' || fs.existsSync(path.join(__dirname+"/public/zad/"+req.body.naziv+".pdf"))){
      req.fileValidatorError = "greska"; 
      return callback(null, false, req.fileValidatorError);
    }
    else
      return callback(null, true);
  }
});
app.post('/addZadatak', upload.single('postavka'), function(req, res, n){
  //console.log("usao u drugi");
  if(req.fileValidatorError == "greska"){
    res.sendFile(__dirname+"/public/greska2.html");
  }
  else{
    //kreira json
    var json ={naziv:req.body.naziv, postavka:"http://localhost:8080/public/zad"+req.body.naziv+'.pdf'};
    fs.writeFile('public/zad/jsoni/' +req.body.naziv+'Zad.json', JSON.stringify(json), function(err,data){
      if (err) throw err;
    }); 
    //treba upisat red u bazu
    db.zadatak.create({naziv:req.body.naziv,postavka:"http://localhost:8080/public/zad/"+req.body.naziv+'.pdf'});
    res.sendFile(__dirname+'/public/addZadatak.html');  
  }
});
//Spirala 3 - Zadatak 3 [1.5b] ---- URADJENO ---- Spirala 4 - ISPRAVLJENO DA CITA IZ BAZE I SALJE URL
app.get('/zadatak', function(req,res){ 
  console.log(req.body)
  db.zadatak.findOne({where:{naziv:req.query.naziv}}).then(podaci =>{
    var post = podaci.postavka;
    post = post.substr(22,post.length);
    res.download(post);
  });
});
/*app.get('/zad/:naziv', function(req,res){ 
  // ako salje link i sa ekstenzijom
  res.download('zad'+req.params.naziv);
});*/
//Spirala 3 - Zadatak 4 [1.25b] ---- URADJENO ---- Spirala 4 - ISPRAVLJENO PISE U BAZU UMJESTO U CSV
app.post('/addGodina',function(req,res){
  //console.log("usao u post /addGodina");
  let tijelo="";
  req.on('data',function(data){
    tijelo=tijelo+data;
  });
  req.on('end',function(){
    let parametri = new url.URLSearchParams(tijelo);
    var nazivgodine = parametri.get('nazivGod');
    var nazivvjezbe = parametri.get('nazivRepVje');
    var nazivspirale = parametri.get('nazivRepSpi');
    function postoji (nazivgodine) {
      return db.godina.count({ where: { nazivGod: nazivgodine } })
        .then(count => {
          if (count != 0) {
            return false;
          }
          return true;
      });
  }
  postoji(nazivgodine).then(isUnique => {
    if (isUnique) {
          db.godina.create({nazivGod:nazivgodine,nazivRepSpi:nazivspirale,nazivRepVje:nazivvjezbe});
        res.sendFile(__dirname+"/public/addGodina.html");  
    }
    else{
      res.sendFile(__dirname+"/public/greska.html");
    }
});
    
  });//kraj req.on
});
//Spirala 3 - Zadatak 5 [0.75b] --- URADJENO ---- Spirala 4 - ISPRAVLJENO DA CITA IZ BAZE UMJESTO IZ CSV
app.get('/godine',function(req,res){
  //cita sve iz baze i salje u json
  db.godina.findAll({ raw: true }).then(function (godine) {
    res.writeHead(200,{'Content-Type':'application/json'});
    res.end(JSON.stringify(godine));
});
 
});
//Spirala 3 - Zadatak 7 [2b] ---- URADJENO ---- Spirala 4 - ISPRAVLJENO DA CITA IZ BAZE I SALJE U ODGOVARAJUCIM FORMATIMA
app.get('/zadaci',function(req,res){
  var niz = [];
  var tekst = req.headers.accept;
  var tip = tekst.split(', ');
  var imaJson=false;
  var imaXml=false;
  var imaCsv=false;
  for(var i =0; i<tip.length;i++){
    // na osnovu postmana, json moze biti samo application, xml moze biti application i text a csv moze biti samo text
    if(tip[i]=='application/json') imaJson =true;
    if(tip[i]=='application/xml' || tip[i]=='text/xml') imaXml=true;
    if(tip[i]=='text/csv') imaCsv=true;
  }
  if(imaJson){     
        // najveci prioritet ima jason
        db.zadatak.findAll({ raw: true }).then(function (godine) {
          res.writeHead(200,{'Content-Type':'application/json'});
          res.end(JSON.stringify(godine));
      });
  }
  else if(imaXml){            
    // xml ima veci prioritet od csv
    db.zadatak.findAll({ raw: true }).then(godine => {
      var xml ='<?xml version="1.0" encoding="UTF-8"?><zadaci>';
      for(var i =0; i<godine.length;i++){
        var naz = godine[i].naziv;
        var url = godine[i].postavka;
      
        xml = xml+'<zadatak><naziv> '+naz+' </naziv><postavka> '+url+' </postavka></zadatak>';
      }
      xml = xml+'</zadatak></zadaci>'; 
      var formattedXml = format(xml);
      res.writeHead(200,{'Content-Type':'application/xml'});
      res.end(formattedXml);
  });
  }
  else if(imaCsv){       
     //trazi samo csv/jedini slucaj kada se salje csv
     db.zadatak.findAll({ raw: true }).then(godine => {
       var izlaz="";
      for(var i =0; i<godine.length;i++){
        var naz = godine[i].naziv;
        var url = godine[i].postavka;
        izlaz=izlaz+ naz+','+url+'\n';
        }
        res.writeHead(200,{'Content-Type':'application/csv'});
        res.end(izlaz);
  });
  }
  else{
    // ukoliko ne posalje nista ispisat json
    db.godina.findAll({ raw: true }).then(function (godine) {
      res.writeHead(200,{'Content-Type':'application/json'});
      res.end(JSON.stringify(godine));
  });
  }
  });


// SPIRALA 4


//Spirala 4 - Zadatak 2a [0.5b]  i 2b [0.5b]- --------------------------- URADJENO
app.post('/addVjezba',(req,res) => {
 let tijelo="";
  req.on('data',function(data){
    tijelo=tijelo+data;
  });
  req.on('end',function(){
    let parametri = new url.URLSearchParams(tijelo);
    var spirala=false;
    if(parametri.get('spirala')=="1") spirala =true;
   if(parametri.get('sVjezbe')==undefined){ 
    //console.log("fNova");
    var naz = parametri.get('naziv');
    var sGodine = parametri.get('sGodina');
    console.log(naz);
    console.log(sGodine);
    var postoji = true;
    db.vjezba.findOne({where:{naziv:naz}}).then(postojiLi =>{
      if(postojiLi==null) postoji = false;
      if(!postoji){
        db.vjezba.create({naziv:naz,spirala:spirala}).then(nesto=>{
          db.godina.findOne({where:{id:sGodine}}).then(god =>{
            db.vjezba.findOne({where:{naziv:naz}}).then(vje => {
            god.addVjezbe([vje]);
            });
          });
        });
        res.sendFile(__dirname+'/public/addVjezba.html'); 
      } 
      else res.sendFile(__dirname+'/public/greska3.html');
    })
    
     
   }
   else{
    //console.log("fPostojeca");
    var sGodine = parametri.get('sGodine'); //id
    var sVjezbe = parametri.get('sVjezbe');
    
    db.godina.findOne({where:{id:sGodine}}).then(god =>{
      db.vjezba.findOne({where:{id:sVjezbe}}).then(function(vje){
        god.addVjezbe([vje]);
      });
    });
    res.sendFile(__dirname+'/public/addVjezba.html'); 
   }
     
  }); //kraj req.on 
});
//Spirala 4 - Zadatak 2c [1b] ------------------------------------ URADJENO KONACNO
app.post('/vjezba/:idVjezbe/zadatak', function(req,res){
//console.log("usao");
let tijelo = "";
req.on('data',function(data){
  tijelo = tijelo +data;
});
req.on('end',function(){
let parametri = new url.URLSearchParams(tijelo);
var zadatak = parametri.get('sZadatak');
db.zadatak.findOne({where:{naziv:zadatak}}).then(zad =>{
  db.vjezba.findOne({where:{id:req.params.idVjezbe}}).then(function(vje){
    zad.addVjezbe([vje]);
  });
});
res.redirect('/addVjezba.html'); 
});
});
//zahtjevi
//vjezbe
app.get('/citajVjezbe',function(req,res){
  db.vjezba.findAll({ raw: true }).then(function (vjezbe) {
    res.writeHead(200,{'Content-Type':'application/json'});
    res.end(JSON.stringify(vjezbe));
});
});
//svi zadaci
app.get('/citajZadatke',function(req,res){
  //console.log("usao u get za sve");
  db.zadatak.findAll({ raw: true }).then(function (zadaci) {
    res.writeHead(200,{'Content-Type':'application/json'});
    res.end(JSON.stringify(zadaci));
});

});
//zauzeti zadaci
app.get('/citajZauzete', function(req,res){
 // console.log("citajzauzete");
  var niz=[];
  db.vjezba.findOne({where:{id:req.query.id}}).then(function(vjezba1){ 
    vjezba1.getZadaci().then(function(zauzetiZadaci){
            if(zauzetiZadaci!=null) {
                for(var i=0; i<zauzetiZadaci.length; i++) {
                    var objekat={naziv:zauzetiZadaci[i].naziv};
                    niz.push(objekat);
                }
            }      
            console.log(JSON.stringify(niz)); 
            res.send(JSON.stringify(niz));
        }); 
    });
    
})

//Spirala 4 - Zadatak 3a [2b] ---------------------------------- URADJENO

//zahtjev za godine
app.get('/citajGodine',function(req,res){
  console.log("get za godine");
  db.godina.findAll({ raw: true }).then(function (godine) {
    res.writeHead(200,{'Content-Type':'application/json'});
    res.end(JSON.stringify(godine));
});
});

app.post('/student',function(req,res){
  //console.log("3a post");
  var god=req.body.godina;
  var listaNovihStudenata=req.body.studenti;
  var dodani=0;
  var azurirani=0;
  db.student.findAll().then(studenti=>{
      db.godina.findOne({where:{id:god}}).then(function(godina){
        var nazivgodine = godina.nazivGod;
          for(var i=0; i<listaNovihStudenata.length; i++) {
              var postoji=false;
              var ime=listaNovihStudenata[i].imePrezime;
              var index=listaNovihStudenata[i].index;
              studenti.forEach(student => {
                  if (index==student.index) {
                     postoji =true;
                     if(godina.id != student.studentGod)
                     godina.setStudenti([student]);
                    azurirani++;
                  }   
              });
              if (!postoji) {
                  db.student.create({imePrezime:ime, index:index, studentGod:godina.id});
                  dodani++;
              }
          }
          var objekat={message:"Dodano je "+dodani+" novih studenata i upisano "+azurirani+" na godinu "+nazivgodine};
          res.end(JSON.stringify(objekat));
      })
  });

});

app.get('/dajRep', function(req,res){
  //console.log("usao u dohvati rep");
  res.send({nazivRepSpi:"Spirala", nazivRepVje:"Vjezba"});
  });
//Spirala 4 - Zadatak 3b [1.5b] --------------------- NIJE URADJENO - TUGI PLAKI SUZI

//OSLUSKIVANJE PORTA 8080
app.listen(8080);



