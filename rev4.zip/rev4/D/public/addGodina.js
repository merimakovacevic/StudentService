function funkcija(){
    var poruka = document.getElementById("poruka");
    var godina = document.getElementById("godina");
    var rep = document.getElementById("rep");
    var spir = document.getElementById("spir");
    var validacija =  new Validacija(poruka);
    validacija.godina(godina);
    validacija.repozitorij(rep, "test");
    validacija.naziv(spir);
    
    }