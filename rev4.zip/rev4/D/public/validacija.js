var Validacija=(function(){
    //lokalne variable idu ovdje
    
    
    var konstruktor=function(divElementPoruke){

        var divPoruke = document.getElementById("poruka");
        var paragraf = document.getElementById("porukica");
        var greske = [true,true,true,true,true,true,true];
        
        function greska(greskice){
            
            var poruka ='Sljedeca polja nisu validna:';
            var brojneispravnih = 0;
            for(var i = 0; i<greskice.length; i++){
                if(greskice[i]==false) brojneispravnih++;
            }
            if(greske[0]==false) poruka=poruka+'ime,';
            if(greske[1]==false) poruka=poruka+'godina,';
            if(greske[2]==false) poruka=poruka+'repozitorij,';
            if(greske[3]==false) poruka=poruka+'index,';
            if(greske[4]==false) poruka=poruka+'naziv,';
            if(greske[5]==false) poruka=poruka+'password,';
            if(greske[6]==false) poruka=poruka+'url,';
        
            var poruka2 = poruka.slice(0, -1) + '!';
            paragraf.innerHTML=poruka2;
            var sveTacno=true;
            for(var i =0;i<greskice.length;i++){
                if(greskice[i]==false) sveTacno=false;
            }
            if(sveTacno) paragraf.innerHTML="";
        }
    return{
    ime:function(inputElement){
        var unesenoIme = inputElement.value;
        var ispravnoIme =/^[A-Z][a-z]*((-|\s)[A-Z][a-z]*)?((-|\s)[A-Z][a-z]*)?((-|\s)[A-Z][a-z]*)?$/g;
        if(unesenoIme.match(ispravnoIme)==null) {
            inputElement.style.backgroundColor='orangered';
            greske[0]=false;
        }
        else {
            inputElement.style.backgroundColor = 'white';
            greske[0]=true;
        }
        greska(greske);
    },
    godina:function(inputElement){ // godina validacija
        var unesenaGodina = inputElement.value;
        var daLiJeIspravan = false;
        if(unesenaGodina.length != 9 || unesenaGodina[0]!="2" || unesenaGodina[5]!="2" || unesenaGodina[1]!="0" || unesenaGodina[6]!="0" || unesenaGodina[4]!="/"){
            daLiJeIspravan = false;
        }
        else{
            var prvaGodina = unesenaGodina[2]+unesenaGodina[3];
            var drugaGodina = unesenaGodina[7]+unesenaGodina[8];
            var prva = parseInt(prvaGodina);
            var druga =parseInt(drugaGodina);
            if(prva+1 == druga) daLiJeIspravan = true;
            else daLiJeIspravan = false;
        }
        if(daLiJeIspravan==false){
            inputElement.style.backgroundColor='orangered';
            greske[1]=false;
        }
        else {
            inputElement.style.backgroundColor = 'white';
                    greske[1]=true;
        }
        greska(greske);
    },
    repozitorij:function(inputElement,regex){
        var uneseniRepo = inputElement.value;
        if(uneseniRepo.match(regex)==null) {
            inputElement.style.backgroundColor='orangered';
            greske[2]=false;
        }
        else {
            inputElement.style.backgroundColor = 'white';
            greske[2]=true;
        }
        greska(greske);
        },
    index:function(inputElement){ //index regex 
        var uneseniIndex = inputElement.value;
        var ispravanIndex = /^((1[4-9])|20)\d\d\d$/g;
        if(uneseniIndex.match(ispravanIndex)==null){
            inputElement.style.backgroundColor='orangered';
            greske[3]=false;
        }
        else {
            inputElement.style.backgroundColor = 'white';
            greske[3]=true;
        }
        greska(greske);
    },
    naziv:function(inputElement){
        var uneseniNaziv = inputElement.value;
        var ispravanNaziv = /^[A-Za-z]{1}[A-Za-z",'!;:\?\\]{1,}[0-9a-z]{1}$/g;
        if(uneseniNaziv.match(ispravanNaziv)==null){
            inputElement.style.backgroundColor='orangered';
            greske[4]=false;
        }
        else {
            inputElement.style.backgroundColor = 'white';
            greske[4]=true;
        }
        greska(greske);
    },
    password:function(inputElement){ // password regex
        
        var uneseniPassword = inputElement.value;
        var ispravanPassword = /^(?=[a-zA-Z0-9#@$?]{8,}$)(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[0-9]).*/g;
        if(uneseniPassword.match(ispravanPassword)==null){
            inputElement.style.backgroundColor='orangered';
            greske[5]=false;
        }
        else {
            inputElement.style.backgroundColor = 'white';
            greske[5]=true;
        }
        greska(greske);
    },
    url:function(inputElement){
        var uneseniURL = inputElement.value;
        var ispravanURL = /^(http|https|ftp|ssh)\:\/\/([a-z0-9][a-z0-9-]*[a-z0-9](\.|))+(\/[a-z0-9][a-z0-9-]*[a-z0-9])*(\?[a-z0-9][a-z0-9-]*[a-z0-9]=[a-z0-9][a-z0-9-]*[a-z0-9]\&[a-z0-9][a-z0-9-]*[a-z0-9]=[a-z0-9][a-z0-9-]*[a-z0-9])*$/g;
        if(uneseniURL.match(ispravanURL)==null){
        inputElement.style.backgroundColor='orangered';
        greske[6]=false;
                }
                else {
                    inputElement.style.backgroundColor = 'white';
                    greske[6]=true;
                }
                greska(greske);
        }
    }   
}
    return konstruktor;
}());