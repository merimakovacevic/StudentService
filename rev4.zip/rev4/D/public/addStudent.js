function funkcija(){
    var poruka = document.getElementById("poruka");
    var imee = document.getElementById("ime");
    var indeks = document.getElementById("index");
    var validacija = new Validacija(poruka);
    validacija.ime(imee);
     validacija.index(indeks);
}