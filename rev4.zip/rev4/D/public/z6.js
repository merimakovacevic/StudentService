var div = document.getElementById("glavniSadrzaj");
var ajax = new GodineAjax(div);
ajax.osvjezi();