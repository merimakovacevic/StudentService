//model godina
const Sequelize = require("sequelize");
module.exports = function(sequelize,DataTypes){
    const Godina = sequelize.define('godina',{
      id:{
        type: Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true,
        field:'id'
      },
      nazivGod:{
        type: Sequelize.STRING,
        unique:true, 
        field:'nazivGod'
      },
      nazivRepSpi:{
        type: Sequelize.STRING,
        field:'nazivRepSpi'
      },
      nazivRepVje:{
        type:Sequelize.STRING,
        field:'nazivRepVje'
      }
    });
    return Godina;
};