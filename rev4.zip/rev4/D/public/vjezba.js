//model vjezba
const Sequelize = require("sequelize");
module.exports = function(sequelize,DataTypes){
    const Vjezba = sequelize.define('vjezba',{
      id:{
        type: Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true,
        field:'id'
      },
      naziv:{
        type: Sequelize.STRING,
        unique:true,
        field:'naziv'
      },
      spirala:{
        type: Sequelize.BOOLEAN,
        field:'spirala'
      }
    });
    return Vjezba;
};