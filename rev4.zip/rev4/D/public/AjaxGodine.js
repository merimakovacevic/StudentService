function AjaxGodine() {
   
    var godineJSON = new XMLHttpRequest();
    var select = document.getElementsByName("sGodina")[0];
    godineJSON.open("GET", "http://localhost:8080/citajGodine",true); 
    godineJSON.setRequestHeader("Content-Type", "application/json");
    godineJSON.send();
    godineJSON.onreadystatechange = function(){
        if (godineJSON.readyState == 4 && godineJSON.status == 200) {
            var godine = JSON.parse(godineJSON.responseText);
            for(var i =0; i<godine.length;i++){
                var godina = godine[i];
                var opcija = document.createElement("option");
                naz = godina.nazivGod;
                opcija.value = godina.id;
                opcija.textContent = naz;
                select.appendChild(opcija);
            }
    
        }
    }
    }
