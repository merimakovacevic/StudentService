var BitBucket  = (function(){
    var konstruktor = function(key,secret){
        return{
            ucitaj:function(nazivRepSpi,nazivRepVje,callback){
                //alert("ucitaaj");
                var student1={imePrezime:"Emre Divit", index:17400};
                var student2 ={imePrezime:"Leyla Aydin", index:17500};
                var niz = [];
                niz.push(student1);
                niz.push(student2);
                callback(niz);
            }
        }
    }
    return konstruktor;
}());