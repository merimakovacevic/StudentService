function funkcija(){
    var poruka = document.getElementById("poruka");
    var vjezba = document.getElementById("field");
    var validacija = new Validacija(poruka);
 validacija.naziv(vjezba);
}
function akcija(){
    var select = document.getElementsByName("sVjezbe")[1].value;
    document.getElementsByName("fPoveziZadatak")[0].action = "/vjezba/"+select+"/zadatak";
}