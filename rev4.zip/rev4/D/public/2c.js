function promjena(){
    var ajax = new AjaxZadaci();
}
//window.onload = promjena;