function funkcija(){
    var poruka = document.getElementById("poruka");
    var zadatak = document.getElementById("field");
    
    var validacija = new Validacija(poruka);
    validacija.naziv(zadatak);
    
}