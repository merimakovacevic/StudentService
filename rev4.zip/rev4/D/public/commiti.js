function funkcija(){
    var poruka = document.getElementById("poruka");
    var url = document.getElementById("url");
    var validacija = new Validacija(poruka);
    validacija.url(url);
}