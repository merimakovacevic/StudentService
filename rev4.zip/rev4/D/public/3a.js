
var lista;

function napraviBitBucket() {
    var kljuc=document.getElementById("key");
    var tajno=document.getElementById("secret");
    var nova= new BitBucket(kljuc,tajno);
    
    function ispisiStudente(s) {
       lista=s;
        //alert("Lista studenata: "+JSON.stringify(s));
    }
    var id=document.getElementsByName('sGodina')[0].value;
    
    var dohvati=new XMLHttpRequest();
    dohvati.open('GET', 'http://localhost:8080/dajRep?id='+id, true);
    dohvati.setRequestHeader("Content-Type", "application/json");
    dohvati.send();
    dohvati.onreadystatechange= function() {
        if (dohvati.readyState==4 && dohvati.status==200) {
            var opcije= JSON.parse(dohvati.responseText);
            nova.ucitaj(opcije.nazivRepSpi, opcije.nazivRepVje, ispisiStudente);
        }
    }
    document.getElementsByName("Dodaj")[0].disabled=false;

    return false;
}

function Ajax() {
    var godina=document.getElementsByName('sGodina')[0].value;
    var listaStudenata=lista;
    console.log(listaStudenata);
    var objekat={godina:godina, studenti:listaStudenata};

    var JSONporuka=new XMLHttpRequest();
    JSONporuka.open("POST", 'http://localhost:8080/student', true);
    JSONporuka.setRequestHeader("Content-Type", "application/json");
    JSONporuka.send(JSON.stringify(objekat));
    JSONporuka.onreadystatechange= function() {
        if (JSONporuka.readyState==4 && JSONporuka.status==200) {
            poruka= JSON.parse(JSONporuka.responseText);
            alert(poruka.message);
        }
    }
}
