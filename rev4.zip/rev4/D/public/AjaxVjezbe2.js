function AjaxVjezbe2() {
    //alert("uso u ajax za popunit vjezbe ");
    var vjezbeJSON = new XMLHttpRequest();
    var select = document.getElementsByName("sVjezbe")[0];
    vjezbeJSON.open("GET", "http://localhost:8080/citajVjezbe",true); 
    vjezbeJSON.setRequestHeader("Content-Type", "application/json");
    vjezbeJSON.send();
    vjezbeJSON.onreadystatechange = function(){
        if (vjezbeJSON.readyState == 4 && vjezbeJSON.status == 200) {
            var vjezbe = JSON.parse(vjezbeJSON.responseText);
            for(var i =0; i<vjezbe.length;i++){
                var vjezba = vjezbe[i];
                var opcija = document.createElement("option");
                naz = vjezba.naziv;
                opcija.value = vjezba.id;
                opcija.textContent = naz;
                select.appendChild(opcija);
            }
    
        }
    }
    }

      
    
    
    