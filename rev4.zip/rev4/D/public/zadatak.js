//model zadatak
const Sequelize = require("sequelize");
module.exports = function(sequelize,DataTypes){
    const Zadatak = sequelize.define('zadatak',{
      id:{
        type: Sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true,
        field:'id'
      },
      naziv:{
        type: Sequelize.STRING,
        field:'naziv'
      },
      postavka:{
        type: Sequelize.STRING,
        field:'postavka'
      }
    });  
    return Zadatak;
};