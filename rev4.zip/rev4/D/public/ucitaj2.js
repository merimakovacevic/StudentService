window.onload=function() {
   AjaxGodine();
}