function AjaxZadaci(){
    //alert("ajax");
    var zadaciJSON = new XMLHttpRequest();
    var vje = document.getElementsByName("sVjezbe")[1].value;
    console.log("vjezba"+vje);
    var select = document.getElementsByName("sZadatak")[0];
    var zauzetiZadaci;
    var sviZadaci;
    zadaciJSON.open("GET", "http://localhost:8080/citajZauzete?id="+vje,true); 
    zadaciJSON.setRequestHeader("Content-Type", "application/json");
    zadaciJSON.send(); 
    zadaciJSON.onreadystatechange = function(){
        
        if (zadaciJSON.readyState == 4 && zadaciJSON.status == 200) {
            zauzetiZadaci = JSON.parse(zadaciJSON.responseText);
            select.length=0;
            var zadaci2JSON = new XMLHttpRequest();
        zadaci2JSON.open("GET", "http://localhost:8080/citajZadatke",true); 
        zadaci2JSON.setRequestHeader("Content-Type", "application/json");
        zadaci2JSON.send(); 
        zadaci2JSON.onreadystatechange = function(){
            
        if (zadaci2JSON.readyState == 4 && zadaci2JSON.status == 200) {
            sviZadaci = JSON.parse(zadaci2JSON.responseText);
            select.length=0;
             for (var i=0; i<sviZadaci.length; i++) {
                 var trenutni=sviZadaci[i].naziv;
                 var ima=false;
                 
                 for(var j=0; j<zauzetiZadaci.length; j++){
                     if (zauzetiZadaci[j].naziv==trenutni) {
                         ima=true; 
                     }
                 }
                 if (!ima) {
                     var element=document.createElement("option");
                     element.textContent= trenutni;
                     element.value=trenutni;
                     select.appendChild(element);
                 }
                 else ima = false;
        }
    }
    }
        }
}
}

