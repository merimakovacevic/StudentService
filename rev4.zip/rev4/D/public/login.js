function funkcija(){
    var poruka = document.getElementById("poruka");
    var password = document.getElementById("password");
    var validacija = new Validacija(poruka);
    validacija.password(password);
}