window.onload=function() {
    AjaxGodine();
    AjaxVjezbe();
    AjaxGodine2();
    AjaxVjezbe2();
}