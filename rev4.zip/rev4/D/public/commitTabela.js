var CommitTabela=(function(){
    //lokalne variable idu ovdje
    var max =1;
    var konstruktor=function(divElement,brojZadataka){
        
        var tabela = document.createElement('table');
        tabela.style.width = '80%';
        tabela.setAttribute('border', '2');
        for (var i = 0; i <= brojZadataka; i++){
            var red = tabela.insertRow();
            if(i == 0){
                red.insertCell().appendChild(document.createTextNode("Zadaci"));
                red.insertCell().appendChild(document.createTextNode("Commiti"));
            }
            else{
                red.insertCell().appendChild(document.createTextNode("Zadatak " + i));
                red.insertCell();
            }
        }
        divElement.appendChild(tabela);
    /*Kreirana tabela sa popunjenim prvim redom i prvom kolonom*/
    return{
    dodajCommit:function(rbZadatka,url){},
    editujCommit:function(rbZadatka,rbCommita,url){},
    obrisiCommit:function(rbZadatka,rbCommita){},
    }
    }
    return konstruktor;
    }());
function kreiraj(){
    var div = document.getElementById("div");
    var br = document.getElementById("brojZadataka").value;
    var tabela = CommitTabela(div,br);
    //tabela.dodajCommit(2,"www.youtube.com");
}
function dodaj(){
    var br = document.getElementById("zadatak").value;
}
    
