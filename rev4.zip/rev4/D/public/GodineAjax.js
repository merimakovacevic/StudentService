// Zadatak 6 [1b]
var GodineAjax = (function(){
    var konstruktor = function(divSadrzaj){
        var ajax=new XMLHttpRequest();
        ajax.open ("GET","http://localhost:8080/godine", true);
        ajax.send();
        ajax.onreadystatechange=function() {
            if (ajax.readyState==4 && ajax.status==200) {
                var niz = JSON.parse(ajax.responseText);
                var string = '';
                for(var i = 0; i<niz.length; i++){
                    var objekat = niz[i];
                    string += '<div class = "godina">';
                    string +='<p class = "tekst">'+objekat.nazivGod+'</p>';
                    string +='<label>'+objekat.nazivRepVje+'</label>';
                    string += '<br>';
                    string +='<label>'+objekat.nazivRepSpi+'</label>';
                    string += '</div>';
                }
                    divSadrzaj.innerHTML += string;
            }
        }
    return {
    osvjezi:function(){
        var ajax=new XMLHttpRequest();
        ajax.open ("GET","http://localhost:8080/godine", true);
        ajax.send();
    }
    }
    }
    return konstruktor;
}());
    
module.exports=GodineAjax;
    