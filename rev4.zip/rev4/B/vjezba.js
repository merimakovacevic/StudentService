const Sequelize = require('sequelize');

module.exports = function(sequelize, DataTypes) {
    const vjezba = sequelize.define("vjezba", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        naziv: { type: Sequelize.STRING, allowNull: false, unique: true },
        spirala: { type: Sequelize.BOOLEAN, allowNull: false }
    });
    
    return vjezba;
};