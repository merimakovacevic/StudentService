const Sequelize = require('sequelize');
const sequelize = new Sequelize('wt2018', 'root', 'root', {host:"127.0.0.1",dialect:"mysql"});
const db = {};

db.sequelize = sequelize;
db.Sequelize = Sequelize;

db.student = sequelize.import(__dirname + '/student.js');
db.godina = sequelize.import(__dirname + '/godina.js');
db.zadatak = sequelize.import(__dirname + '/zadatak.js');
db.vjezba = sequelize.import(__dirname + '/vjezba.js');

//prva veza
db.godina.hasMany(db.student, {as:'studenti', foreignKey:'studentGod'});
//druga veza
db.godinaVjezba = db.vjezba.belongsToMany(db.godina, {as: 'godine', through:'godina_vjezba', foreignKey: 'idvjezba'});
db.godina.belongsToMany(db.vjezba, {as: 'vjezbe', through: 'godina_vjezba', foreignKey: 'idgodina'});

//treca
db.vjezbaZadatak = db.zadatak.belongsToMany(db.vjezba, {as: 'vjezbe', through: 'vjezba_zadatak', foreignKey: 'idzadatak'});
db.vjezba.belongsToMany(db.zadatak, {as: 'zadaci', through: 'vjezba_zadatak', foreignKey: 'idvjezba'});

module.exports=db;
