const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const mysql = require('mysql2');
const Sequelize = require('sequelize');
const app = express();
var path = require("path");


const db = require(__dirname + '/db.js');
db.sequelize.sync({force:false}).then(function(){ 
});


app.set("view engine", "pug");
app.set("views", path.join(__dirname, "public/views"));

//multer se koristi u drugom zadatku
const multer = require('multer');
var storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'public/pdf');
    },
    filename: function(req, file, cb) {
        cb(null, req.body.naziv + ".pdf");
    }
});
const upload = multer({ 
    storage : storage,
    fileFilter : function(req, file , cb) {
        var ext = file.mimetype;
        if(!ext.includes("pdf"))
            return cb(new Error("Dozvoljeni su samo pdf fajlovi"));

        var params = req.body.naziv;
        db.zadatak.findOne({where: {naziv: params}}).then(function(result){ //provjerava se da li je u bazi vec unesen taj zadatak
            if(result != null)
                return cb(new Error("Zadatak sa tim imenom vec postoji"));
            
            cb(null, true);
        }).catch(function(error) { 
            console.log(error); 
            return cb(new Error(error.message))
        });
    }
 }).single("postavka");

//PRVI ZADATAK (treca spirala)
app.use(express.static("public"));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//DRUGI ZADATAK (treca spirala)
app.post("/addZadatak", function(req, res) {
    upload(req, res, function(err) {
        if(err) {
            //error
            res.render('greska', { porukaGreske: err.message, link: "http://localhost:8080/addZadatak.html"  });
        }
        else {
            //ispravno
            var name = req.file.filename.slice(0,-4);
            var encoded = encodeURI(name);
            var link = "http://localhost:8080/pdf/" + encoded + ".pdf";
            
            db.zadatak.create({naziv: name, postavka: link}).then(function(result) {
                console.log("Uspjesno dodan zadatak");
                //res.sendFile(__dirname + "\\public\\addZadatak.html");
                res.send({naziv: name, postavka: link});
            }).catch(function(error) { console.log(error); });
        }
    });
});

//TRECI ZADATAK (treca spirala)
app.get("/zadatak", function(req, res){
    var params = req.query.naziv;
    db.zadatak.findOne({where: {naziv: params}}).then(function(result){ //citanje postavke iz baze
        if(result != null)
            res.redirect(result.postavka);
        else
            res.sendFile(__dirname + "\\public\\greska.html");
    }).catch(function(err) {
        console.log(err);
    });
});

//CETVRTI ZADATAK (treca spirala)
app.post('/addGodina', function(req, res) {
    var params = req.body;
    var godina = params["nazivGod"];
    var repV = params["nazivRepVje"];
    var repS = params["nazivRepSpi"];
    if(godina != undefined && godina != "" && repV != undefined && repS != undefined) {
        db.godina.findOne({where: {naziv: godina}}).then(function(result){
            if(result != null) //vec je upisana godina u bazu
                res.sendFile(__dirname + "\\public\\greska.html");
            else {
                db.godina.create({naziv: godina, nazivRepSpi: repS, nazivRepVje: repV }).then(function(result){
                    console.log("Uspjesno upisana godina!");
                    res.sendFile(__dirname + "\\public\\addGodina.html");
                }).catch(function(error) {
                    console.log(error);
                });
            }
        }).catch(function(error) {
            console.log(error);
        });
    }
    else {
        res.render('greska', { porukaGreske: "Morate popuniti sva polja", link: "http://localhost:8080/addGodina.html"  });
    }
});

//PETI I SESTI ZADATAK (treca spirala)
app.get('/godine', function(req, res) {
    db.godina.findAll().then(function(result){
        if(result != null) {
            var returnValue = [];
            for(var i = 0; i < result.length; i++) {
                var novi = { nazivGod: result[i].naziv, nazivRepVje: result[i].nazivRepVje, nazivRepSpi: result[i].nazivRepSpi };
                returnValue.push(novi);
            }
            res.send(returnValue);
        }
        else
            res.send([]);
    }).catch(function(error) { console.log(error); });
});

//SEDMI ZADATAK (treca spirala)
app.get('/zadaci', function(req, res) {
    var format = req.headers['accept'].toString();
    //ako je accept samo */* tad se vraca json
    
    if(format.includes("application/json") || format == "*/*") {
        // json 
        db.zadatak.findAll().then(function(result){
            if(result != null) {
                var resultJson = [];
                for(var i = 0; i < result.length; i++) {
                    var novi = { naziv: result[i].naziv, postavka: result[i].postavka };
                    resultJson.push(novi);
                }
                res.send(resultJson);
            }
            else {
                res.send([]);
            }
        }).catch(function(error) { console.log(error); });
    }
    else if(format.includes("application/xml") || format.includes("text/xml")){
        // XML
        db.zadatak.findAll().then(function(result){
            var resultXml = '<?xml version="1.0" encoding="UTF-8"?><zadaci>';
            if(result != "") {
                for(var i = 0; i < result.length; i++) {
                    var temp = "<zadatak><naziv>" + result[i].naziv + "</naziv><postavka>" + result[i].postavka + "</postavka></zadatak>"
                    resultXml += temp;
                }
            }
            resultXml += "</zadaci>";
            res.type("application/xml");
            res.set('Content-Type', 'application/xml');
            res.send(resultXml);
        }).catch(function(error) { console.log(error); });
    }
    else if(format.includes("text/csv")) {
        // CSV
        db.zadatak.findAll().then(function(result){
            if(result != null) {
                var resultCsv = "";
                for(var i = 0; i < result.length; i++) {
                    var temp = result[i].naziv + "," + result[i].postavka + "\r"
                    resultCsv += temp;
                }
                res.set('Content-Type', 'text/csv');
                res.send(resultCsv.trimRight());
            }
            else {
                res.set('Content-Type', 'text/csv');
                res.send("");
            }
        }).catch(function(error) { console.log(error); });
    }
});

app.post('/addVjezba', function(req, res){
    var params = req.body;
    var nazivVjezbe = params["nazivVjezbe"];

    if(nazivVjezbe == null) {
        //fPostojeca
        var godina = params["sGodine"];
        var vjezba = params["sVjezbe"];

        db.godina.findOne({where: {id: godina}}).then(function(resultGodina) { //trazi se godina iz baze na osnovu parametra (parametar je id !!)
            if(resultGodina != null) {
                db.vjezba.findOne({where: {id: vjezba}}).then(function(resultVjezba){ //trazi se vjezba iz baze na osnovu parametra (parametar je id !!)
                    if(resultVjezba != null) {
                        resultVjezba.getGodine().then(function(godineVjezbe){ //traze se sve godine sa kojima je navedena vjezba u vezi 
                            var found = false;
                            for(var i = 0; i < godineVjezbe.length; i++)
                                if(resultGodina.id == godineVjezbe[i].id) { //ako je vec postoji veza izmedju vjezbe i godine, ispisuje se greska
                                    found = true;
                                    break;
                                }

                            if(!found) { //ako nije pronadjena veza izmedju godine i vjezbe
                                resultVjezba.addGodine(resultGodina);
                                res.sendFile(__dirname + "\\public\\addVjezba.html");
                            }
                            //else ??? na forumu pise da se ne radi nista ako postoji veza
                                //res.render('greska', { porukaGreske: "Vec postoji veza izmedju godine i vjezbe", link: "http://localhost:8080/addVjezba.html"  });        
                            
                        }).catch(function(error) { console.log(error); });
                    }
                    else //ovo se ne bi trebalo desiti jer se select popunjava iz baze but still..
                        res.render('greska', { porukaGreske: "Ta vjezba nije pronadjena", link: "http://localhost:8080/addVjezba.html"  });
                }).catch(function(error) { console.log(error); });
            }
            else //ovdje u sustini ne bi trebalo doci nikad jer se select popunjava iz baze ali etooo 
                res.render('greska', { porukaGreske: "Ta godina nije pronadjena", link: "http://localhost:8080/addVjezba.html"  });
        }).catch(function(error) { console.log(error); });
    }
    else {
        //fNova
        var godina = params["sGodine"];
        var sp = params["spirala"];
        db.vjezba.findOne({where: {naziv: nazivVjezbe}}).then(function(resultVjezba){ //trazi se unesena vjezba u bazi
            if(resultVjezba == null) {
                db.godina.findOne({where: {id: godina}}).then(function(resGodina){ //trazi se godina u bazi
                    if(resGodina != null) {
                        var checked = false;
                        if(sp != undefined) checked = true;
                        db.vjezba.create({naziv: nazivVjezbe, spirala: checked}).then(function(novaVjezba){ //dodaje se vjezba u bazu
                            novaVjezba.addGodine(resGodina);
                            res.sendFile(__dirname + "\\public\\addVjezba.html");
                        }).catch(function(error) { console.log(error); });
                    }
                    else //ovdje zapravo ne bi trebalo doci jer se select popunjava iz baze, but just in case something goes wrong ...
                        res.render('greska', { porukaGreske: "Ta godina nije pronadjena", link: "http://localhost:8080/addVjezba.html"  });
                }).catch(function(error) { console.log(error); });
            }
            else //ako je vjezba vec upisana, ispisuje se greska
                res.render('greska', { porukaGreske: "Ta vjezba vec postoji", link: "http://localhost:8080/addVjezba.html"  });
        }).catch(function(error) { console.log(error); });
        
    }

});

app.get('/getZadaciVjezbe', function(req, res) { //ovo sluzi za dobijanje svih zadataka koji nemaju vezu sa odredjenom vjezbom
    var vjezba = req.query.vjezba;
    
    if(vjezba != "") {
        db.vjezba.findOne({where: {id: vjezba}}).then(function(resVjezba) { //trazi se vjezba u bazi
            db.zadatak.findAll().then(function(resZadaci){ //dohvacaju se svi zadaci iz baze
                resVjezba.getZadaci().then(function(resZadaciVjezbe) { 
                    var resultNiz = [];
                    for(var i = 0; i < resZadaci.length; i++) { //prolazi kroz sve zadatke
                        var id = resZadaci[i].id;
                        var found = false;
                        for(var j = 0; j < resZadaciVjezbe.length; j++) { //prolazi kroz zadatke odredjene vjezbe
                            if(id == resZadaciVjezbe[j].id) { //ako se id zadatka iz tabele poklapa sa id-em zadatka koji je vezan za vjezbu...
                                found = true;
                                break;
                            }
                        }
                        if(!found) //...onda se on ne dodaje (if se preskoci)
                            resultNiz.push({id: resZadaci[i].id, naziv: resZadaci[i].naziv});
                       
                    }
                    res.send(resultNiz);
                }).catch(function(error) { console.log(error); });
            }).catch(function(error) { console.log(error); });
        }).catch(function(error) { console.log(error); });
    }
});

app.get("/getVjezbe", function(req, res){ //koristi se za popunjavanje selecta
    db.vjezba.findAll().then(function(result){
        var resultNiz = [];
        for(var i = 0; i < result.length; i++) 
            resultNiz.push({id: result[i].id, naziv: result[i].naziv});

        res.send(resultNiz);
    }).catch(function(error) { console.log(error); });
});

app.get("/getGodine", function(req, res) { //koristi se za popunjavanje selecta
    db.godina.findAll().then(function(result) {
        if(result != null)
            res.send(result);
        else res.send([]);
    }).catch(function(error) { console.log(error); });
});

app.post("/vjezba/:idVjezbe/zadatak", function(req, res) {
    var idVjezbe = req.params.idVjezbe;
    var idZadatak = req.body["sZadatak"];
    if(idZadatak != undefined) {
        db.vjezba.findOne({where: {id: idVjezbe}}).then(function(vjezba){ //trazi se vjezba u bazi na osnovu id-a
            db.zadatak.findOne({where: {id: idZadatak}}).then(function(zadatak) { //trazi se zadatak ciji je id poslan kao parametar
                vjezba.addZadaci(zadatak); //dodaje se zadatak na vjezbu
                //obzirom da je u ovoj situaciji moguce dodati samo onaj zadatak koji vec nije vezan sa vjezbom, nisu potrebne dodatne provjere
                res.redirect("http://localhost:8080/addVjezba.html");
            }).catch(function(error) { console.log(error); });
        }).catch(function(error) { console.log(error); });
    }
    else {
        res.render('greska', { porukaGreske: "Nema zadatka za dodati", link: "http://localhost:8080/addVjezba.html"  });
    }
});

//za 3a
app.get("/getSpecificGodina", function(req, res) {
    var idGodine = req.query.id;
    if(idGodine != "") {
        db.godina.findOne({where: {id: idGodine}}).then(function(result){
            if(result != null) 
                res.send(result);
            else 
                res.send("");
        }).catch(function(error) { console.log(error); });
    }
    else
        res.send("");
});

app.post("/student", function(req, res) {
    var content = req.body;
    var idGodina = content.godina;
    var studenti = content.studenti;
    db.godina.findOne({where: {id: idGodina}}).then(function(godina) { //nadjem godinu
        db.student.findAll().then(function(sviStudenti) {
            var nadjeniPromises = [];
            var brokenPromises = [];
            var M = 0;
            for(var i = 0; i < studenti.length; i++) {
                var found = false;
                for(var j = 0; j < sviStudenti.length; j++) {
                    if(studenti[i].index == sviStudenti[j].index) {
                        if(sviStudenti[j].studentGod != godina.id) {
                            M++;
                        }
                        nadjeniPromises.push(godina.addStudenti(sviStudenti[j]));
                        found = true;
                        break;
                    }
                }
                if(!found) {
                    brokenPromises.push(db.student.create({imePrezime: studenti[i].imePrezime, index: studenti[i].index}));
                }
            }

            Promise.all(brokenPromises).then(function(dodaniStudenti){
                var dodajNaGodinu = [];
                dodaniStudenti.forEach(item => {
                    dodajNaGodinu.push(godina.addStudenti(item));
                });
                Promise.all(nadjeniPromises).then(function(result){
                    Promise.all(dodajNaGodinu).then(function(rezultat){
                        var N = dodajNaGodinu.length;
                        //godina.getStudenti().then(function(studentiNaGodini){
                            //var M = studentiNaGodini.length;
                            M += brokenPromises.length;
                            //var M = studenti.length;
                            var msg = "Dodano je " + N + " novih studenata i upisano " + M + " na godinu " + godina.naziv;
                            var odgovor = {message: msg};
                            res.send(odgovor);
                        //});
                    }).catch(function(error) { console.log(error); });
                }).catch(function(error) { console.log(error); });
            }).catch(function(error) { console.log(error); });
        }).catch(function(error) { console.log(error); });

    }).catch(function(error) { console.log(error); });
});

app.listen(8080);