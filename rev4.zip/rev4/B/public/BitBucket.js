var BitBucket = (function() {
    //var token = null;
    var konstruktor = function(key, secret){
        var token = new Promise(function(resolve) {
            var ajax = new XMLHttpRequest();

            ajax.onreadystatechange = function() {
                if(ajax.readyState == 4 && ajax.status == 200) {
                    resolve(new Promise(function(resolve, reject) { resolve(JSON.parse(ajax.response).access_token); }));
                }
            }

            ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+":"+secret));
            ajax.send("grant_type="+encodeURIComponent("client_credentials")); 
        
        });

        return {
            ucitaj: function(nazivRepSpi, nazivRepVje, callback) {
                if(nazivRepSpi == "" || nazivRepVje == "") {
                    callback("Neispravan naziv", null);
                }
                else {
                    
                    token.then(function(dobijeniToken){
                        var ajax = new XMLHttpRequest();
    
                        ajax.onreadystatechange = function() {
                            if(ajax.readyState == 4 && ajax.status == 200) {
                                var content = JSON.parse(ajax.responseText).values;
                                var studenti = [];
                                
                                content.forEach(item => {
                                    var ime = item.owner.username;
                                    var indeks = item.name.slice(item.name.length-5);
                                    var found = false;
                                    for(var i = 0; i < studenti.length; i++) {
                                        if(studenti[i].index == indeks) {
                                            found = true;
                                            break;
                                        }
                                    }
                                    if(!found)
                                        studenti.push({imePrezime: ime, index: indeks});
                                });
    
                                callback(null, studenti);
                            }
                            else if(ajax.readyState == 4)
                                callback(ajax.status, null);
                        }
    
                        var filtering = 'q=name~"' + nazivRepSpi + '"+ OR + name~"' + nazivRepVje + '"';
                        ajax.open("GET","https://api.bitbucket.org/2.0/repositories/?role=member&" + filtering);
                        ajax.setRequestHeader("Authorization", 'Bearer ' + dobijeniToken);
                        ajax.send();


                    }).catch(function(err){
                        //console.log("u catch: " + err);
                        callback(err, null);
                    });
                }
            }
        };

    };

    return konstruktor;
}());