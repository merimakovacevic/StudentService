function validirajPrvu() { // ovo je nepotrebno ?
    var formClass = document.getElementsByClassName("formClass")[0];
    var fPostojeca = formClass.getElementsByTagName("form")[0];

    var selectGodina = fPostojeca.getElementsByTagName("select")[0];
    var divGreske = document.getElementsByClassName("divGreske")[0];
    Validacija(divGreske).godina(selectGodina);
}

function validirajDrugu() { 
    var formClass = document.getElementsByClassName("formClass")[1];
    var fNova = formClass.getElementsByTagName("form")[0];

    var inputNaziv = fNova.getElementsByTagName("input")[0];
    var selectGodina = fNova.getElementsByTagName("select")[0];
    var divGreske = document.getElementsByClassName("divGreske")[1];

    var novo = Validacija(divGreske);
    var validacijaNaziva = novo.naziv(inputNaziv);
    var validacijaGodine = novo.godina(selectGodina);
}

window.onload = function() {
    var forma = document.getElementsByName("fPoveziZadatak")[0];
    document.getElementsByName("sVjezbe")[0].innerHTML = "";
    document.getElementsByName("sVjezbe")[1].innerHTML = "";
    document.getElementsByName("sGodine")[0].innerHTML = "";
    document.getElementsByName("sGodine")[1].innerHTML = "";
    getVjezbe();
    getGodine();
};


function getGodine() {
    var ajax = new XMLHttpRequest();

    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) {
            if(ajax.response != "[]") {
                var content = JSON.parse(ajax.response);

                for(var i = 0; i < content.length; i++) {
                    var option = "<option value=" + content[i].id + ">" + content[i].naziv + "</option>";

                    document.getElementsByName("sGodine")[0].innerHTML += option;
                    document.getElementsByName("sGodine")[1].innerHTML += option;
                }
            }
        }
    };

    ajax.open("GET", "http://localhost:8080/getGodine", true);
    ajax.send();
}

function getVjezbe() {
    var ajax = new XMLHttpRequest();

    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) {
            if(ajax.response != "[]") {
                var content = JSON.parse(ajax.response);

                for(var i = 0; i < content.length; i++) {
                    var option = "<option value=" + content[i].id + ">" + content[i].naziv + "</option>";
                    document.getElementsByName("sVjezbe")[0].innerHTML += option;
                    document.getElementsByName("sVjezbe")[1].innerHTML += option;
                }
                document.getElementsByName("sVjezbe")[1].onchange();
            }
        }
    };

    ajax.open("GET", "http://localhost:8080/getVjezbe", true);
    ajax.send();
}

function updateZadaci() {
    var ajax = new XMLHttpRequest();
    var forma = document.getElementsByName("fPoveziZadatak")[0];
    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) {
            
            forma.getElementsByTagName("select")[1].innerHTML = "";
            var content = JSON.parse(ajax.response);

            for(var i = 0; i < content.length; i++) {
                var option = document.createElement("option");
                option.textContent = content[i].naziv;
                option.value = content[i].id;
                forma.getElementsByTagName("select")[1].appendChild(option);
            }
        }
    }
    
    var vjezba = forma.getElementsByTagName("select")[0].value;
    
    ajax.open('GET', 'http://localhost:8080/getZadaciVjezbe?vjezba=' + vjezba, true);
    ajax.send();
}

function submitFormu() {
    var value = document.getElementsByName("sVjezbe")[1].value;
    var path = "http://localhost:8080/vjezba/" + value + "/zadatak";
    document.getElementsByName("fPoveziZadatak")[0].action = path;
}