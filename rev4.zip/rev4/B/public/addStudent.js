var key = "";
var secret = "";
var bbucket = undefined;
var ucitano = undefined;
window.onload = function() { 
    getGodine();
};

function getGodine() {
    var ajax = new XMLHttpRequest();

    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) {
            if(ajax.responseText != "[]") {
                var content = JSON.parse(ajax.responseText);
                document.getElementsByName("sGodina")[0].innerHTML = "";
                for(var i = 0; i < content.length; i++) {
                    var option = "<option value=" + content[i].id + ">" + content[i].naziv + "</option>";
                    document.getElementsByName("sGodina")[0].innerHTML += option;
                }
            }
        }
    }

    ajax.open("GET", "http://localhost:8080/getGodine");
    ajax.send();
}


function ucitaj() {
    var newKey = document.getElementsByName("key")[0].value;
    var newSecret =  document.getElementsByName("secret")[0].value;
    if((newKey != key || newSecret != secret) && newKey != "" && newSecret != "") {
        key = newKey;
        secret = newSecret;
        bbucket = new BitBucket(key, secret);
    }

    if(bbucket != undefined) {
        var ajax = new XMLHttpRequest();

        ajax.onreadystatechange = function() {
            if(ajax.readyState == 4 && ajax.status == 200) {
                if(ajax.responseText != "") {
                    var result = JSON.parse(ajax.responseText);
                    var nazivRepSpi = result.nazivRepSpi;
                    var nazivRepVje = result.nazivRepVje;
                    var callback = function(greska, lista) {
                        if(greska == null) {
                            ucitano = lista;
                        }
                        else console.log(greska);
                    };

                    var f = async function() {
                        var promis = new Promise((resolve, reject) => {
                            bbucket.ucitaj(nazivRepSpi, nazivRepVje, callback);
                            //bbucket.ucitaj("wtv2018", "wt18", callback);
                            setTimeout(() => resolve("finish"), 3000);
                        });

                        var result = await promis;
                        if(result == "finish") {
                            if(ucitano != undefined) {
                                document.getElementsByTagName("input")[2].disabled = false;
                            }
                            else console.log("tu je ucitano: " + ucitano); 
                        }
                    }

                    f();
                }
            }
        }

        var idGodine = document.getElementsByName("sGodina")[0].value;
        ajax.open("GET", "http://localhost:8080/getSpecificGodina?id=" + idGodine);
        ajax.send();
    }
}

function postStudent() {
    var ajax = new XMLHttpRequest();

    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) {
            //post dobro prosao ? 
            var content = JSON.parse(ajax.response);
            alert(content.message);
        }
    }
    
    ajax.open("POST", "http://localhost:8080/student");
    ajax.setRequestHeader('Content-Type', 'application/json');
    var id = document.getElementsByName("sGodina")[0].value;
    var request = { godina: id, studenti: ucitano };
    ajax.send(JSON.stringify(request));
}



function validirajPrvu() {
   var formClass = document.getElementsByClassName("formClass")[0];
    var fPojedinacni = formClass.getElementsByTagName("form")[0];
   
    var selectGodina = fPojedinacni.getElementsByTagName("select")[0];
    var inputIme = fPojedinacni.getElementsByTagName("input")[0];
    var inputIndex = fPojedinacni.getElementsByTagName("input")[1];
    
    var divGreske = document.getElementsByClassName("divGreske")[0];

    var novo = Validacija(divGreske);

    var validacijaGodine = novo.godina(selectGodina);
    var validacijaImena = novo.ime(inputIme);
    var validacijaIndexa = novo.index(inputIndex);
}

//ovo je zapravo nepotrebno jer select nije vrsta input field-a?
function validirajDrugu() {
    var formClass = document.getElementsByClassName("formClass")[1];
    var fMasovni = formClass.getElementsByTagName("form")[0];

    var selectGodina = fMasovni.getElementsByTagName("select")[0];
    var divGreske = document.getElementsByClassName("divGreske")[1];
    Validacija(divGreske).godina(selectGodina);
}

