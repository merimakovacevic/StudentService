function validiraj() {
    var forma = document.getElementById("login").getElementsByTagName("form")[0];
    var divGreske = document.getElementById("divGreske");
    var inputPassword = forma.getElementsByTagName("input")[1];

    var novo = Validacija(divGreske);
    novo.password(inputPassword);
}