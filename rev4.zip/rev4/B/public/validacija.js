var Validacija = ( function() {
   
    var konstruktor=function(divElementPoruke) {

        var ispisiPoruku = function(greska, idElementa) {
            var paragraf = divElementPoruke.getElementsByTagName("p")[0];

            if(paragraf.innerHTML.endsWith(":"))
                paragraf.innerHTML += greska + "!";
            else if(paragraf.innerHTML.endsWith(":!")) { //ovo se desi u slucaju da je prvo bila greska, pa ispravljena, pa opet pogrijeseno na istom mjestu
                paragraf.innerHTML = paragraf.innerHTML.slice(0, -1);
                paragraf.innerHTML += greska + "!";
            }
            else if(paragraf.innerHTML.endsWith("!") && !paragraf.innerHTML.includes(greska)) {
                paragraf.innerHTML = paragraf.innerHTML.slice(0, -1);
                paragraf.innerHTML += "," + greska + "!";
            }

            paragraf.style.visibility = "visible";
        }

        var obrisiPoruku = function(poruka) {
            var paragraf = divElementPoruke.getElementsByTagName("p")[0];
            
            var dio = paragraf.innerHTML.slice(28, -1).split(',');
            for(var i = 0; i < dio.length; i++) {
                if(dio[i] == poruka) {
                    dio.splice(i, 1);
                    break;
                }
            }

            dio.join(',');
            paragraf.innerHTML = "Sljedeća polja nisu validna:" + dio + "!";

            if(dio.length == 0) 
                paragraf.style.visibility = "hidden";
        }

        var obojiElement = function(element, correct) {
            if(correct)
                element.style.backgroundColor = "white";
            else 
                element.style.backgroundColor = "orangered";
        }

        return {
            ime: function(inputElement) { 
                var value = inputElement.value.split(/[\s-]+/);

                var brojRijeci = 0;
                for(var i = 0; i < value.length; i++)
                    if(value[i] != "") brojRijeci++;
                   
                //je li vise od 4 rijeci (potrebno je brojati kroz petlju jer je validno i: "Rijec- Rijec")
                if(brojRijeci > 4) { 
                    ispisiPoruku("ime"); 
                    obojiElement(inputElement, false);
                    return -1; 
                }  
                
                for(var i = 0; i < value.length; i++) { 
                    if(value[i] != "") {
                        //je li sve rijeci pocinju velikim slovom
                        if(value[i].charAt(0) < 'A' || value[i].charAt(0) > 'Z') { 
                            ispisiPoruku("ime"); 
                            obojiElement(inputElement, false);
                            return -1; 
                        } 
                        
                        //je li svaka rijec ima min 2 slova
                        if(value[i].length < 2) { 
                            ispisiPoruku("ime"); 
                            obojiElement(inputElement, false);
                            return -1; 
                        } 

                        //za apostrofe
                        for(var j = 0; j < value[i].length; j++) {
                            if(j != value[i].length - 1)
                                if(value[i][j] == "'" && value[i][j+1] == "'") { 
                                    ispisiPoruku("ime"); 
                                    obojiElement(inputElement, false);
                                    return -1; 
                                } 
                        }
                    }
                }
                

                obrisiPoruku("ime");
                obojiElement(inputElement, true);
                return 0;
            },

            godina: function(inputElement) {
                var value = inputElement.value;

                if(value.length != 9) { 
                    ispisiPoruku("godina"); 
                    obojiElement(inputElement, false);
                    return -1; 
                }

                var prveCifre = value.substring(0, 2) + value.substring(5, 7);
                if(prveCifre != "2020") { 
                    ispisiPoruku("godina"); 
                    obojiElement(inputElement,false);
                    return -1; 
                }

                var AB = parseInt(value.substring(2, 4), 10);
                var CD = parseInt(value.substring(7, 9), 10);
                if(AB + 1 != CD) { 
                    ispisiPoruku("godina"); 
                    obojiElement(inputElement, false);
                    return -1; 
                }
                
                if(value.charAt(4) != '/') { 
                    ispisiPoruku("godina"); 
                    obojiElement(inputElement,false);
                    return -1; 
                }

                obrisiPoruku("godina"); 
                obojiElement(inputElement, true);
                return 0;
            },

            repozitorij:function (inputElement, regex) {
                var value = inputElement.value;
                
                var rg = new RegExp(regex);

                if(!rg.test(value)) { 
                    ispisiPoruku("repozitorij " + inputElement.name); 
                    obojiElement(inputElement, false);
                    return -1; 
                } 

                obrisiPoruku("repozitorij " + inputElement.name);
                obojiElement(inputElement, true);
                return 0;
            },

            index: function(inputElement) {
                var value = inputElement.value;
                
                if((value + "").length != 5) { 
                    ispisiPoruku("index"); 
                    obojiElement(inputElement, false);
                    return -1; 
                } 

                var prveDvije = parseInt(value.substring(0, 2), 10);
                if(prveDvije < 14 || prveDvije > 20) { 
                    ispisiPoruku("index"); 
                    obojiElement(inputElement, false);
                    return -1; 
                } 

                obrisiPoruku("index");
                obojiElement(inputElement, true);
                return 0;
            },

            naziv: function(inputElement) {
                var value = inputElement.value;

                if(value == "" || value.length < 3) { 
                    ispisiPoruku("naziv"); 
                    obojiElement(inputElement, false);
                    return -1; 
                } 
                    //ako ne pocinje slovom
                var prvoSlovo = value.charAt(0);
                if(!((prvoSlovo >= 'a' && prvoSlovo <= 'z') || (prvoSlovo >= 'A' && prvoSlovo <= 'Z'))) { 
                    ispisiPoruku("naziv"); 
                    obojiElement(inputElement, false);
                    return -1; 
                } 

                var zadnjeSlovo = value.charAt(value.length-1);
                if(!((zadnjeSlovo >= '0' && zadnjeSlovo <= '9') || (zadnjeSlovo >= 'a' && zadnjeSlovo <= 'z'))) { 
                    ispisiPoruku("naziv"); 
                    obojiElement(inputElement, false);
                    return -1; 
                } 
                
                var approvedChars =  ["\\", "/", "-", '"', "'", "!", "?", ":", ";", ","];
                for(var i = 97; i < 123; i++) approvedChars.push(String.fromCharCode(i));
                for(var i = 65; i < 91; i++) approvedChars.push(String.fromCharCode(i));
                for(var i = 0; i < 10; i++) approvedChars.push(i);

                for(var i = 0; i < value.length; i++) {
                    var correct = false;
                    for(var j = 0; j < approvedChars.length; j++) {
                        if(value[i] == approvedChars[j]) {
                            correct = true;
                            break;
                        }
                    }
                    if(!correct) { 
                        ispisiPoruku("naziv"); 
                        obojiElement(inputElement, false);
                        return -1; 
                    } 
                }

                obrisiPoruku("naziv");
                obojiElement(inputElement, true);
                return 0;
            },

            password: function(inputElement) {
                var value = inputElement.value;

                if(value.length < 8) { 
                    ispisiPoruku("password"); 
                    obojiElement(inputElement, false);
                    return -1; 
                } 

                var velikaSlova = [];
                for(var i = 65; i < 91; i++) velikaSlova.push(String.fromCharCode(i));

                var malaSlova = [];
                for(var i = 97; i < 123; i++) malaSlova.push(String.fromCharCode(i));

                var brojevi = [];
                for(var i = 0; i < 10; i++) brojevi.push(i);


                var velikaSlovaCount = 0;
                var malaSlovaCount = 0;
                var brojeviCount = 0;
                
                for(var i = 0; i < value.length; i++) {
                    var nestoCetvrto = true;

                    for(var j = 0; j < velikaSlova.length; j++) if(value[i] == velikaSlova[j]) { nestoCetvrto = false; velikaSlovaCount++; break; }
                    for(var j = 0; j < malaSlova.length; j++) if(value[i] == malaSlova[j]) { nestoCetvrto = false; malaSlovaCount++; break; }
                    for(var j = 0; j < brojevi.length; j++) if(value[i] == brojevi[j]) { nestoCetvrto = false; brojeviCount++; break; }
                    
                    if(nestoCetvrto) {
                        ispisiPoruku("password"); 
                        obojiElement(inputElement, false);
                        return -1; 
                    }
                }

                var correct = false;
                if(velikaSlovaCount > 0 && malaSlovaCount > 0) correct = true;
                if(velikaSlovaCount > 0 && brojeviCount > 0) correct = true;
                if(malaSlovaCount > 0 && brojeviCount > 0) {
                    console.log("mala: " + malaSlovaCount + "  brojevi: " + brojeviCount);
                    correct = true;
                }

                if(!correct) { 
                    ispisiPoruku("password"); 
                    obojiElement(inputElement, false);
                    return -1; 
                }

                obrisiPoruku("password");
                obojiElement(inputElement, true);
                return 0;
            },

            url: function(inputElement) {   

                //^((http|https|ftp|ssh):\/\/){1}((?!\.)(?!-)([a-z0-9-]+)(?<!-)(?<!\.)){1}(\.((?!\.)(?!-)([a-z0-9-]+)(?<!-)(?<!\.)))*(\/(?!-)([a-z0-9-]+)(?<!-))*(\?((?!-)([a-z0-9-]+)(?<!-)=(?!-)([a-z0-9-]+)(?<!-)&?)*)?$
                var value = inputElement.value;
              
                var regex = new RegExp('^((http|https|ftp|ssh):\/\/){1}((?!\\.)(?!-)([a-z0-9-]+)(?<!-)(?<!\\.)){1}(\\.((?!\\.)(?!-)([a-z0-9-]+)(?<!-)(?<!\\.)))*(\/(?!-)([a-z0-9-]+)(?<!-))*(\/(?!-)([a-z0-9-]+)(?<!-))*(\\?((?!-)([a-z0-9-]+)(?<!-)=(?!-)([a-z0-9-]+)(?<!-)&?)*)?$');
                
                if(!regex.test(value)) {
                    ispisiPoruku("url"); 
                    obojiElement(inputElement, false);
                    return -1; 
                }

                obrisiPoruku("url");
                obojiElement(inputElement, true);
                return 0;
            }
        }
    }
    return konstruktor;
}());