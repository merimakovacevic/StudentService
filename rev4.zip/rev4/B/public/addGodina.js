window.onload = function(){
    refresh();
}

function refresh() {
    var divSadrzaj = document.getElementById("glavniSadrzaj");
    var ga = GodineAjax(divSadrzaj);
    ga.osvjezi();
}

function validiraj() {
    var divSide = document.getElementById("side");
    var forma = divSide.getElementsByTagName("form")[0];

    var inputGodina = forma.getElementsByTagName("input")[0];
    var inputRVjezba = forma.getElementsByTagName("input")[1];
    var inputRSpirala = forma.getElementsByTagName("input")[2];

    var divGreska = document.getElementById("divGreske");

    var novo = Validacija(divGreska);

    var validacijaGodine = novo.godina(inputGodina);
    var validacijaRVjezbe = novo.repozitorij(inputRVjezba, '[a-zA-Z]+');
    var validacijaRSpirale = novo.repozitorij(inputRSpirala, '[a-zA-Z]+');
}
