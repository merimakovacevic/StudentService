const Sequelize = require('sequelize');

module.exports = function(sequelize, DataTypes) {
    const student = sequelize.define("student", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        imePrezime: {
        type: Sequelize.STRING,
        allowNull: false
        },
        index: { 
            type: Sequelize.STRING, 
            unique: true 
        }
    });

    return student;
};