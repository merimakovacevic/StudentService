const Sequelize = require('sequelize');

module.exports = function(sequelize, DataTypes) {
    const godina = sequelize.define("godina", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },  
        naziv: { type: Sequelize.STRING, allowNull: false, unique: true },
        nazivRepSpi: { type: Sequelize.STRING, allowNull: false },
        nazivRepVje: { type: Sequelize.STRING, allowNull: false }
    });
    
    return godina;
};