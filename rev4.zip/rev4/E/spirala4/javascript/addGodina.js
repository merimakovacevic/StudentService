function addGodinaValidacija(divId,inputGodinaId,inputRepVjezbeId, inputRepSpiraleId){

	var porukaValidacijeDiv = document.getElementById(divId);
	var inputGodina = document.getElementById(inputGodinaId);
	var inputRepVjezbe = document.getElementById(inputRepVjezbeId);
	var inputRepSpirale = document.getElementById(inputRepSpiraleId);

	var regexZaRepozitorij = /\d{4}/g;

	var validacija = new Validacija(porukaValidacijeDiv);
	validacija.godina(inputGodina);
	validacija.repozitorij(inputRepVjezbe,regexZaRepozitorij);
	validacija.repozitorij(inputRepSpirale,regexZaRepozitorij);

}