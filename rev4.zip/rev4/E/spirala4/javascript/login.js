function loginValidacija(div, username, password){

	var porukaValidacije = document.getElementById(div);
	var username = document.getElementById(username);
	var password = document.getElementById(password);

	var validacija = new Validacija(porukaValidacije);
	validacija.naziv(username);
	validacija.password(password);
}