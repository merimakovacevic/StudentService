function addZadatakValidacija(divId,nazivId){

	var porukaValidacijeDiv = document.getElementById(divId);
	var nazivInput = document.getElementById(nazivId);

	var validacija = new Validacija(porukaValidacijeDiv);
	validacija.naziv(nazivInput);
}