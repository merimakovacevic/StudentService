var CommitTabela=(function(){
        
        //lokalne variable idu ovdje
        var body = document.getElementById("body");    
        var tab = document.createElement("table");
        tab.setAttribute("id", "commiti");
        var tbdy = document.createElement('tbody');
        var max=2;// najveca trenutna duzina reda
        var konstruktor=function(divElement,brojZadataka){
        var tableDiv = document.getElementById(divElement.id);
        brojZadataka++;
        console.log(brojZadataka);
                for(var i=0;i<brojZadataka;i++){
                    var tr = document.createElement("tr");
            
                    for(var j=0;j<2;j++){
                        if(i==0 && j>1 ) continue;
                        var td = document.createElement("td");
                        
                        if(i==0 && j==0){
                            td.appendChild(document.createTextNode("Naziv zadatka"));
                        }
                        if(i==0 && j==1){
                           
                            td.appendChild(document.createTextNode("Commiti"));
                        }
                       
                        
        
                        if(i>0 && j==0){
                            td.appendChild(document.createTextNode("Zadatak" + " " + i));
                        }
                       
                        tr.appendChild(td);
                    }
                    tbdy.appendChild(tr);
                }
                tab.appendChild(tbdy);
                body.appendChild(tab);
        
            tableDiv.appendChild(tab);
            

        return{
        dodajCommit:function(rbZadatka,url){
            
            var y=tab.rows[+rbZadatka+1].cells.length; //duzina reda u koji dodajem kolonu

            if(elementIsEmpty(tab.rows[+rbZadatka+1].cells[y-1])==false){ 
                // provjeravam je li zadnja kolona prazna
                tab.rows[0].cells[1].colSpan=y;
                var z=tab.rows[+rbZadatka+1].cells[y-1].firstChild.innerHTML.toString();
                console.log(z);
                var n = +z +1;
                var x=tab.rows[+rbZadatka+1].insertCell(-1);
                
                y=tab.rows[+rbZadatka+1].cells.length;
                
                //var tekst=(y-1).toString();
                x.appendChild(document.createTextNode(n.toString()));
            
                x.innerHTML = n.toString().link(url.toString());
                for( var i=1; i<tab.rows.length; i++){
                    if(i==+rbZadatka+1) continue; // ako dodje do reda gdje dodajemo neka nastavi 
                    var red=tab.rows[i];
                    var duzina = red.cells.length;
                    if(elementIsEmpty(red.cells[duzina-1])==false){
                       
                    var x=red.insertCell(-1);
                
                    
                } 
                else{
                    red.cells[duzina-1].colSpan= y-duzina+1;
                }
                
            }
        

            }
            else{
                
                for(var i=0; i<tab.rows.length; i++){
                    if(tab.rows[i].cells.length > max) max=tab.rows[i].cells.length;
                }
                y=tab.rows[+rbZadatka+1].cells.length;
                
                var x= tab.rows[+rbZadatka+1].cells[y-1];
                x.colSpan=1;
                var pocetna = "1";

                if(y ==2) {
                    x.appendChild(document.createTextNode(pocetna));
                x.innerHTML = pocetna.link(url.toString());
                if(y < max) {
                var z = tab.rows[+rbZadatka+1].insertCell(-1);
                z.colSpan=max-tab.rows[+rbZadatka+1].cells.length+1;
                }
                return;
                }
                var tekst = tab.rows[+rbZadatka+1].cells[y-2].firstChild.innerHTML.toString();
                var com = +tekst +1;
                
                x.appendChild(document.createTextNode(com.toString()));
                x.innerHTML = com.toString().link(url.toString());
                if(y!=max){
                var z = tab.rows[+rbZadatka+1].insertCell(-1);
                z.colSpan=max-tab.rows[+rbZadatka+1].cells.length+1;
                }
            
            }
            
        
        },
        editujCommit:function(rbZadatka,rbCommita,url){
            var brojacprazno=0;
            for (var i=1 ; i<tab.rows[rbZadatka].cells.length; i++){
                if(elementIsEmpty(tab.rows[rbZadatka].cells[i])==true) brojacprazno+=1;
            }
            if(brojacprazno == tab.rows[rbZadatka].cells.length - 1) return -1;
        if( rbZadatka < 1 || rbZadatka > tab.rows.length-1) return -1; // provjerava da li su poslane validne vrijednosti 
            var brojac1=0;
        for(var i=1 ; i < tab.rows[rbZadatka].cells.length ; i++){
            if(elementIsEmpty(tab.rows[rbZadatka].cells[i])==true) break;
            else if(tab.rows[rbZadatka].cells[i].firstChild.innerHTML.toString()  == rbCommita) {
                brojac1++; // provjerava je li poslan validan commit
            
            }
        }
        if(brojac1==0) return -1;
            var celija = tab.rows[rbZadatka].cells[rbCommita];
            var tekst=(rbCommita).toString();
                celija.appendChild(document.createTextNode(tekst));
                celija.innerHTML = tekst.link(url.toString());

        },
        obrisiCommit:function(rbZadatka,rbCommita){ 
          if( rbZadatka < 0 || rbZadatka > tab.rows.length-1) return -1; // provjerava da li su poslane validne vrijednosti
        var brojacprazno=0;
       
            for (var i=0; i<tab.rows[+rbZadatka+1].cells.length; i++){
                if(elementIsEmpty(tab.rows[+rbZadatka+1].cells[i])==true) brojacprazno+=1; //broji prazne celije
            }
            if(brojacprazno == tab.rows[+rbZadatka+1].cells.length - 1) return -1;
        
        
      
        // nalaženje reda sa maximalnom duzinom
        var pomocnaduzina;
        for( var i = 0; i<tab.rows.length; i++ ){
            pomocnaduzina = tab.rows[i].cells.length;
            if(elementIsEmpty(tab.rows[i].cells[pomocnaduzina-1])) pomocnaduzina--;
                    if( pomocnaduzina > max) {
                max = pomocnaduzina;
                
            }
        }
        var brojimax=0;
        //provjerava da li ima vise redova sa max velicinom 
        for( var i=0; i<tab.rows.length; i++){
            pomocnaduzina = tab.rows[i].cells.length;
            if(elementIsEmpty(tab.rows[i].cells[pomocnaduzina-1])) pomocnaduzina--;
            console.log(i.toString()+":"+tab.rows[i].cells.length);
            if(pomocnaduzina== max) brojimax += 1;

        }
    
        console.log(brojimax);
        var duzina = tab.rows[+rbZadatka+1].cells.length;
        var provjericeliju;
        for( var j = 0; j<tab.rows[+rbZadatka+1].cells.length ; j++){
            if(elementIsEmpty(tab.rows[+rbZadatka+1].cells[j])==true) break;
            if( j==duzina-1){
                provjericeliju = true; // da li brise predzadnju celiju
                
            }
            
        if(j == +rbCommita+1) {
            tab.rows[+rbZadatka+1].deleteCell(j);
            }
            
        }
        
        var novaduzina = tab.rows[+rbZadatka+1].cells.length;
    
        if(duzina < max) 
            {
                
            tab.rows[+rbZadatka+1].cells[novaduzina-1].colSpan =max-novaduzina+1;
            }
        
            
            else if(duzina == max && brojimax > 1 && novaduzina < max){
            
            var x= tab.rows[+rbZadatka+1].insertCell(-1);
            x.colSpan = max-novaduzina+1;
            }
            var jednako=0; 
            for( var k=0; k<tab.rows.length; k++){
                
                if(k == +rbZadatka+1) continue;
                if(tab.rows[k].cells.length > novaduzina) jednako += 1;
                
            }
            
            if(duzina == max && jednako !=0 ){
                for (var i =0 ; i<tab.rows.length ; i++){
                    if(i==+rbZadatka+1) continue;
                    
                    
                    if(tab.rows[i].cells.length > novaduzina && elementIsEmpty(tab.rows[i].cells[tab.rows[i].cells.length -1]) == true){
                    tab.rows[i].deleteCell(tab.rows[i].cells.length - 1);
                    }
                }
            }
        
        if(duzina == max && brojimax > 0) max = novaduzina;
           
        }
      
     
        }
        }
        return konstruktor;
        }());

        function elementIsEmpty(element){
            return(/^(\s|&nbsp;)*$/).test(element.innerHTML);
        }

        