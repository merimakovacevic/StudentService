var Validacija = (function(){

    var paragraf = document.createElement("p");
    paragraf.id = "pId";
    
    var konstruktor = function(divElementPoruke){

    if(!divElementPoruke.contains(paragraf)){
        divElementPoruke.appendChild(paragraf);
    }

    if(document.getElementById("porukaId") != null){

        paragraf.removeChild(document.getElementById("porukaId"));
    }

    var porukaValidacije = "";

    return{

        ime:function(inputElement){

            var regex = /[A-Z]([A-Z]|[a-z]|('(\s|[a-z]|[A-Z])|-))+((\s|-)([A-Z]([A-Z]|[a-z]|('(\s|[a-z]|[A-Z])|-))+)){1,3}/g;

            var inputIme = inputElement.value;
            var ispravanIzraz = regex.source;
            var Regex = new RegExp(ispravanIzraz);

            var brojac = 1;

            for(var i=0; i<inputIme.length; i++){
                if(inputIme[i] == " " || inputIme[i] == "-") brojac++;
            }

            if(Regex.test(inputElement.value) && brojac<5) return;

            if(porukaValidacije == ""){

                porukaValidacije = "Sljedeća polja nisu validna: ime!";
                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }

            else{ 
                var obrisati = document.getElementById("porukaId");
                paragraf.removeChild(obrisati);

                porukaValidacije = porukaValidacije.replace(/!$/,",");
                porukaValidacije += "ime!";

                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }

        },

        godina:function(inputElement){

            var regex = /\d{4}\/\d{4}/;
            var inputGodina = inputElement.value;
            var regexValidator = inputGodina.match(regex);
            var ispravanIzraz = regex.source;

            var Regex = new RegExp(ispravanIzraz);

            if(Regex.test(inputElement.value)){

                var prvaGodina = parseInt(inputGodina.substring(2,4));
                var drugaGodina = parseInt(inputGodina.substring(7,9));

                if(drugaGodina-prvaGodina == 1) return;
            } 

            /*if(regexValidator == inputGodina){

                
            } */

            if(porukaValidacije == ""){
                porukaValidacije = "Sljedeća polja nisu validna: godina!";
                //porukaValidacije = "Sljedeća polja nisu validna: repozitorij!";
                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }

            else{
                var obrisati = document.getElementById("porukaId");
                paragraf.removeChild(obrisati);

                porukaValidacije = porukaValidacije.replace(/!$/,",");
                porukaValidacije += "godina!";

                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }
            
            
        },

        repozitorij:function(inputElement,regex){

            var ispravanIzraz = regex.source;
            var Regex = new RegExp(ispravanIzraz);
            //var regexValidator = inputElement.value.match(regex);

            //if(regexValidator == inputElement.value) return;

            if(Regex.test(inputElement.value)) return;


            if(porukaValidacije == ""){

                porukaValidacije = "Sljedeća polja nisu validna: repozitorij!";
                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }

            else{

                var obrisati = document.getElementById("porukaId");
                paragraf.removeChild(obrisati);

                porukaValidacije = porukaValidacije.replace(/!$/,",");
                porukaValidacije += "repozitorij!";

                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);


            }
        },

        index:function(inputElement){

            var regex = new RegExp("((1[4-9])|20)\\d{3}");

            if(regex.test(inputElement.value)) return;

            if(porukaValidacije == ""){

                porukaValidacije = "Sljedeća polja nisu validna: index!";
                //porukaValidacije = "Sljedeća polja nisu validna: repozitorij!";
                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }

            else{
                var obrisati = document.getElementById("porukaId");
                paragraf.removeChild(obrisati);

                porukaValidacije = porukaValidacije.replace(/!$/,",");
                porukaValidacije += "index!";

                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }
        },

        naziv:function(inputElement){

            var slovo = "([A-Z]|[a-z])";
            var broj = "([0-9])";
            var znakovi = "(\\\\|\/|-|\"|'|!|\\\?|:|;|,)";
            var biloSta = "("+znakovi+"|"+slovo+"|"+broj+ ")";
            var maloSlovo = "([a-z])";

            var ispravanIzraz = "^"+ slovo + biloSta + biloSta+"*" + "(" + broj+ "|"  + maloSlovo + ")$";
            var regex = new RegExp(ispravanIzraz);

            if(regex.test(inputElement.value)) return;

            if(porukaValidacije == ""){

                porukaValidacije = "Sljedeća polja nisu validna: naziv!";
                //porukaValidacije = "Sljedeća polja nisu validna: repozitorij!";
                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }

            else{
                var obrisati = document.getElementById("porukaId");
                paragraf.removeChild(obrisati);

                porukaValidacije = porukaValidacije.replace(/!$/,",");
                porukaValidacije += "naziv!";

                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }
        },

        password:function(inputElement){

            var maloSlovo = "([a-z])";
            var velikoSlovo = "([A-Z])";
            var broj = "([0-9])";
            var biloSta = "(" + maloSlovo + "|" + velikoSlovo + "|" + broj + ")";

            var maloIVeliko =  "(" +"(" + biloSta+"*" + maloSlovo + biloSta+"*" + velikoSlovo + biloSta+"*" + ")"
                               + "|" +"(" + biloSta+"*" + velikoSlovo + biloSta+"*" + maloSlovo + biloSta+"*" + ")"  +")";

            var maloIBroj =  "(" +"(" + biloSta+"*" + maloSlovo + biloSta+"*" + broj + biloSta+"*" + ")"
                               + "|" +"(" + biloSta+"*" + broj + biloSta+"*" + maloSlovo + biloSta+"*" + ")"  +")";

            var velikoIBroj =  "(" +"(" + biloSta+"*" + velikoSlovo + biloSta+"*" + broj + biloSta+"*" + ")"
                               + "|" +"(" + biloSta+"*" + broj + biloSta+"*" + velikoSlovo + biloSta+"*" + ")"  +")";

            var ispravanIzraz = maloIVeliko + "|" + maloIBroj + "|" + velikoIBroj;
            var regex = new RegExp(ispravanIzraz);

            if(inputElement.value.length >= 8 && regex.test(inputElement.value)) return;

            if(porukaValidacije == ""){

                porukaValidacije = "Sljedeća polja nisu validna: password!";
                //porukaValidacije = "Sljedeća polja nisu validna: repozitorij!";
                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }

            else{
                var obrisati = document.getElementById("porukaId");
                paragraf.removeChild(obrisati);

                porukaValidacije = porukaValidacije.replace(/!$/,",");
                porukaValidacije += "password!";

                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }
        },

        url:function(inputElement){

            var maloSlovo = "([a-z])";
            var broj = "([0-9])";
            var crtica = "-";
            var rijec = "(" + maloSlovo + "|" + broj + ")" + "(" + maloSlovo + "|" + broj + "|" + crtica +")*" + "(" + maloSlovo + "|" + broj + ")";

            var host = "(" + rijec + "(" + "." + rijec + ")*" + ")";
            var protokol = "(http|https|ftp|ssh)";
            var putanja = "(" + "\/" + rijec + ")*";
            var parametri = "(\\\?" + rijec + "=" + rijec + "&" + rijec + "=" + rijec + ")";


            var ispravanIzraz = "^(" + protokol + ":\/\/" + host + putanja + parametri + "{0,1}" + ")$";

            var regex = new RegExp(ispravanIzraz);
            if(regex.test(inputElement.value)) return;

            if(porukaValidacije == ""){

                porukaValidacije = "Sljedeća polja nisu validna: url!";
                //porukaValidacije = "Sljedeća polja nisu validna: repozitorij!";
                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }

            else{
                var obrisati = document.getElementById("porukaId");
                paragraf.removeChild(obrisati);

                porukaValidacije = porukaValidacije.replace(/!$/,",");
                porukaValidacije += "url!";

                var poruka = document.createElement("p");
                poruka.id = "porukaId";
                poruka.innerHTML = porukaValidacije;
                paragraf.appendChild(poruka);
            }

        }
    }
}

return konstruktor;

}());



