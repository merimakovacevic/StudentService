function addStudentValidacija(divId,imeId,indexId){

	var porukaValidacijeDiv = document.getElementById(divId);
	var imeInput = document.getElementById(imeId);
	var indexInput = document.getElementById(indexId);

	var validacija = new Validacija(porukaValidacijeDiv);
	validacija.ime(imeInput);
	validacija.index(indexInput);
}