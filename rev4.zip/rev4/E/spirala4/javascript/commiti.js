var tabela;
function nova(){
    var mojDiv= document.getElementById("tabela");
    var brojZadataka = document.getElementById("brZadataka");
    tabela = new CommitTabela(mojDiv,brojZadataka.value);
}
function dodaj(){
    var div = document.getElementById("dodaj");
    var rbZadatka = document.getElementById("zadatak");
    tabela.dodajCommit(rbZadatka.value-1, url.value);
}
function obrisi(){
    var rbZadatka = document.getElementById("zadatak");
    var rbCommita = document.getElementById("commit");
    tabela.obrisiCommit(rbZadatka.value-1, rbCommita.value-1);
}
function edituj(){
    var div = document.getElementById("dodaj");
    var rbZadatka = document.getElementById("zadatak");
    var rbCommita = document.getElementById("commit");
    var url = document.getElementById("url");
    tabela.editujCommit(rbZadatka.value-1, rbCommita.value-1,url.value);
}


         