const express = require('express');
const multer = require('multer');
const bodyParser = require('body-parser');
const fs = require("fs");
const db = require('./modeli/db.js');

db.sequelize.sync().then(function(){
   console.log("Uspjesno povezano");
}).catch(function(){
    console.log("Nije uspjesno povezano");
 });


const app = express();
//Postavke za pdf
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        cb(null, req.body.naziv + '.pdf')
    }
});
app.use(express.static('uploads'));
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.listen(8080);


app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});



var upload = multer({
    storage: storage,
    fileFilter: function (req, file, cb) {
        req.fileValidationError = '';
        if (file.mimetype != 'application/pdf' || file.originalname.indexOf('.pdf') < 0) {
            req.fileValidationError = 'Nije pdf';
            return cb(null, false, new Error('Nije pdf'));
        }
        else if (req.body.naziv.length < 1) {
            req.fileValidationError = 'Naziv nije validan';
            return cb(null, false, new Error('Naziv nije validan'));
        }
        return db.zadatak.find({ where: { naziv: req.body.naziv } }).then(function (zad) {
            if (zad != null) {
                req.fileValidationError = 'Ima vec';
                return cb(null, false, new Error('Naziv nije validan'));
            }
            else
                req.fileValidationError = 'sve ok';
            return cb(null, true);
        });
    }
}).single('postavka');

//Zadatak 2
app.post('/addZadatak', function (req, res) {
    upload(req, res, function (err) {
        let formData = req.body;
        if (req.fileValidationError == 'Naziv nije validan' || formData.naziv.length < 1) {
            var html = "<button><a href='http://localhost:8080/addZadatak.html'>Vrati se na prehodnu stranicu</a></button>        <div id='poruka'>Naziv nije validan!</div>";
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        }
        if (req.fileValidationError == 'Ima vec') {
            var html = "<button><a href='http://localhost:8080/addZadatak.html'>Vrati se na prehodnu stranicu</a></button>        <div id='poruka'>JSON fajl sa nazivom " + formData.naziv + " postoji!</div>";
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        }
        if (req.fileValidationError == 'Nije pdf' || req.fileValidationError != 'sve ok') {
            var html = "<button><a href='http://localhost:8080/addZadatak.html'>Vrati se na prehodnu stranicu</a></button>        <div id='poruka'>Fajl nije tipa pdf!</div>";
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        }
        var noviJson = '{"naziv":"' + formData.naziv + '","postavka":"http://localhost:8080/' + encodeURI(formData.naziv) + '.pdf"}';
        db.zadatak.create({ naziv: formData.naziv, postavka: 'http://localhost:8080/' + encodeURI(formData.naziv) + '.pdf' }).then(function () {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(noviJson);
        }).catch(function (err) {
            var html = "<button><a href='http://localhost:8080/addZadatak.html'>Vrati se na prehodnu stranicu</a></button>        <div id='poruka'>Dogodila se greska!</div>";
            res.setHeader('Content-type', 'text/html');
            fs.writeFileSync("./public/greska.html", html);
            res.sendFile('greska.html', { root: __dirname + "/public/" });
        });
    });
});
//Zadatak3
app.get('/zadatak', function (req, res) {
    db.zadatak.findOne({ where: { naziv: req.query.naziv } }).then(function (zadatak) {
        if (zadatak == null) {
            var html = "<div id='poruka'>Nema tog zadatka!</div>";
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        }
        var path = "./uploads/" + req.query.naziv + ".pdf";
        var data = fs.readFileSync(path);
        res.setHeader('Content-type', 'application/pdf');
        res.send(data);
    }).catch(function (err) {
        var html = "<div id='poruka'>Desila se greska!</div>";
        fs.writeFileSync("./public/greska.html", html);
        res.setHeader('Content-type', 'text/html');
        res.sendFile('greska.html', { root: __dirname + "/public/" });
        return;
    });
});

//Zadatak 4
app.post('/addGodina', function (req, res) {
    if (req.body.nazivGod.length == 0 || req.body.nazivRepVje.length == 0 || req.body.nazivRepSpi.length == 0) {
        var html = "<button><a href='http://localhost:8080/addGodina.html'>Vrati se na prehodnu stranicu</a></button>        <div id='poruka'>NIje validan naziv!</div>";
        res.setHeader('Content-type', 'text/html');
        fs.writeFileSync("./public/greska.html", html);
        res.sendFile('greska.html', { root: __dirname + "/public/" });
        return;
    }
    db.godina.create({ nazivGod: req.body.nazivGod, nazivRepSpi: req.body.nazivRepSpi, nazivRepVje: req.body.nazivRepVje }).then(function () {
        res.setHeader('Content-Type', 'text/html');
        res.sendFile('addGodina.html', { root: __dirname + "/public/" });
    }).catch(function (err) {
        var html = "<button><a href='http://localhost:8080/addGodina.html'>Vrati se na prehodnu stranicu</a></button>        <div id='poruka'>Postoji vec godina sa tim nazivom!</div>";
        res.setHeader('Content-type', 'text/html');
        fs.writeFileSync("./public/greska.html", html);
        res.sendFile('greska.html', { root: __dirname + "/public/" });
    });
});

//Zadatak 5
app.get('/godine', function (req, res) {
    db.godina.findAll({ attributes: ['nazivGod', 'nazivRepVje', 'nazivRepSpi'] }).then(function (niz) {
        res.setHeader('Content-type', 'application/json');
        res.send(JSON.stringify(niz));
    }).catch(function (err) {
        var html = "<div id='poruka'>Desila se greska!</div>";
        fs.writeFileSync("./public/greska.html", html);
        res.setHeader('Content-type', 'text/html');
        res.sendFile('greska.html', { root: __dirname + "/public/" });
        return;
    });
});

//Zadatak 7
app.get("/zadaci", function (req, res) {
    var csv = "";
    var xml = '<?xml version="1.0" encoding="UTF-8"?>    <zadaci>';
    db.zadatak.findAll({ attributes: ['naziv', 'postavka'] }).then(function (niz) {
        var headers = req.headers.accept;
        if (niz == null) {
            if (req.headers.accept.includes("application/json")) {
                res.setHeader('Content-Type', 'application/json');
                res.end("[]");
            }
            else if (req.headers.accept.includes("application/xml")) {
                res.setHeader('Content-Type', 'application/xml');
                res.end('<?xml version="1.0" encoding="UTF-8"?>    <zadaci></zadaci>');
            }
            else if (req.headers.accept.includes("text/csv")) {
                res.setHeader('Content-Type', 'text/csv');
                res.end("");
            }
            else {
                //error
                var html = " <div id='poruka'>Nije validan Content type</div>";
                fs.writeFileSync("./public/greska.html");
                fs.writeFileSync("./public/greska.html", html);
                res.sendFile('greska.html', { root: __dirname + "/public/" });
            }
            return;
        }
        if (headers.includes("application/json")) {
            res.setHeader('Content-Type', 'application/json');
            res.send(JSON.stringify(niz));
        }
        else if (headers.includes("application/xml")) {
            niz.forEach(object => {
                xml += "<zadatak> <naziv> " + object.naziv + " </naziv> <postavka> " + object.postavka + " </postavka> </zadatak>"
            });
            xml += "</zadaci>";
            res.setHeader('Content-Type', 'application/xml');
            res.end(xml);
        }
        else if (headers.includes("text/csv")) {
            niz.forEach(object => {
                csv += object.naziv + "," + object.postavka + '\n';
            });
            res.setHeader('Content-Type', 'text/csv');
            res.end(csv);
        }
        else {
            var html = " <div id='poruka'>Nije validan Content type</div>";
            fs.writeFileSync("./public/greska.html");
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-Type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        }
    }).catch(function (err) {
        var html = "<div id='poruka'>Desila se greska!</div>";
        fs.writeFileSync("./public/greska.html", html);
        res.setHeader('Content-type', 'text/html');
        res.sendFile('greska.html', { root: __dirname + "/public/" });
        return;
    });
});

//ZAdatak2 Spirala 4addVjezba
app.get('/vjezbe', function (req, res) {
    db.vjezba.findAll({ attributes: ['id', 'naziv', 'spirala'] }).then(function (niz) {
        res.setHeader('Content-type', 'application/json');
        res.send(JSON.stringify(niz));
    }).catch(function (err) {
        var html = "<div id='poruka'>Desila se greska!</div>";
        fs.writeFileSync("./public/greska.html", html);
        res.setHeader('Content-type', 'text/html');
        res.sendFile('greska.html', { root: __dirname + "/public/" });
        return;
    });
});
//APi koji vraca sve godine sa id-em
app.get('/sveGodine', function (req, res) {
    db.godina.findAll({ attributes: ['id', 'nazivGod', 'nazivRepVje', 'nazivRepSpi'] }).then(function (niz) {
        res.setHeader('Content-type', 'application/json');
        res.send(JSON.stringify(niz));
    }).catch(function(err){
        var html = "<div id='poruka'>Desila se greska!</div>";
        fs.writeFileSync("./public/greska.html", html);
        res.setHeader('Content-type', 'text/html');
        res.sendFile('greska.html', { root: __dirname + "/public/" });
        return;
    });
});
//Zadatak 2.c
app.post('/vjezba/:idVjezbe/zadatak', function (req, res) {
    var idVjezbe = req.params.idVjezbe;
    var idZadatka = req.body.sZadatak;
    db.zadatak.findOne({ where: { id: idZadatka } }).then(function (k) {
        if (k == null) {
            var html = " <div id='poruka'>Nije validno1</div>";
            fs.writeFileSync("./public/greska.html");
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-Type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        }
        db.vjezba.findOne({ where: { id: idVjezbe } }).then(function (a) {
            if (a == null) {
                var html = " <div id='poruka'>Nije validno</div>";
                fs.writeFileSync("./public/greska.html");
                fs.writeFileSync("./public/greska.html", html);
                res.setHeader('Content-Type', 'text/html');
                res.sendFile('greska.html', { root: __dirname + "/public/" });
                return;
            }
            k.getVjezbe().then(function (pom2) {
                pom2.push(a);
                k.setVjezbe(pom2);
                
                res.setHeader('Content-Type', 'text/html');
                res.redirect('../../addVjezba.html');
            });


        }).catch(function(err){
            var html = "<div id='poruka'>Desila se greska!</div>";
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        });
    }).catch(function(err){
        var html = "<div id='poruka'>Desila se greska!</div>";
        fs.writeFileSync("./public/greska.html", html);
        res.setHeader('Content-type', 'text/html');
        res.sendFile('greska.html', { root: __dirname + "/public/" });
        return;
    });

});
//Dodati api za izdvajanaje mogucih zadatak za vjezbu sa idem idVjezbe
app.get('/zadaciOdabrani/:idVjezbe', function (req, res) {
    db.zadatak.findAll({ attributes: ['id', 'naziv', 'postavka'] }).then(function (s) {
        var sviZadaci = [];
        for (var j = 0; j < s.length; j++)
            sviZadaci.push({ id: s[j].id, naziv: s[j].naziv, postavka: s[j].postavka });
        var idVjezbe = req.params.idVjezbe;
        db.vjezba.find({ where: { id: idVjezbe } }, { attributes: ['id', 'naziv', 'spirala'] }).then(function (s) {
            s.getZadaci().then(function (pom2) {
                var pom = [];
                var i = 0;
                if (pom2.length == 0 || pom2.length == undefined)
                    res.end(JSON.stringify(sviZadaci));
                pom2.forEach(el => {
                    i++;
                    var ele = { id: el.id, naziv: el.naziv, postavka: el.postavka };
                    pom.push(ele);
                    for (var j = 0; j < sviZadaci.length; j++)
                        if (sviZadaci[j].id == el.id)
                            sviZadaci.splice(j, 1);
                    if (i >= pom2.length)
                        res.end(JSON.stringify(sviZadaci));
                });

            });

        }).catch(function(err){
            var html = "<div id='poruka'>Desila se greska!</div>";
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        });
    }).catch(function(err){
        var html = "<div id='poruka'>Desila se greska!</div>";
        fs.writeFileSync("./public/greska.html", html);
        res.setHeader('Content-type', 'text/html');
        res.sendFile('greska.html', { root: __dirname + "/public/" });
        return;
    });
});
//Zadatak 2a i 2b
app.post('/addVjezba', function (req, res) {

    if (req.body.naziv && req.body.spirala) {
        var naziv = req.body.naziv;
        var spirala = req.body.spirala;
        var sGodine = req.body.sGodine;
        if (spirala == null) spirala = false;
        else spirala = true;
        db.vjezba.create({ naziv: naziv, spirala: spirala }).then(function (k) {
            db.godina.findOne({ where: { id: sGodine } }).then(function (a) {
                if (a == null) {
                        var html = "<div id='poruka'>Desila se greska!</div>";
                        fs.writeFileSync("./public/greska.html", html);
                        res.setHeader('Content-type', 'text/html');
                        res.sendFile('greska.html', { root: __dirname + "/public/" });
                        return;
                 
                }
                k.getGodine().then(function (sve) {
                    sve.push(a);
                    k.setGodine(sve);
                    res.setHeader('Content-Type', 'text/html');
                    res.sendFile('addVjezba.html', { root: __dirname + "/public/" });

                });

            }).catch(function(err){
                var html = "<div id='poruka'>Desila se greska!</div>";
                fs.writeFileSync("./public/greska.html", html);
                res.setHeader('Content-type', 'text/html');
                res.sendFile('greska.html', { root: __dirname + "/public/" });
                return;
            });
        }).catch(function(err){
            var html = "<div id='poruka'>Desila se greska!</div>";
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        });
    }
    else if (req.body.sVjezbe) {
        var sGodine = req.body.sGodine;
        var sVjezbe = req.body.sVjezbe;
        db.vjezba.findOne({ where: { id: sVjezbe } }).then(function (k) {
            if (k == null) {
                var html = " <div id='poruka'>Nije validno1</div>";
                fs.writeFileSync("./public/greska.html");
                fs.writeFileSync("./public/greska.html", html);
                res.setHeader('Content-Type', 'text/html');
                res.sendFile('greska.html', { root: __dirname + "/public/" });
                return;
            }
            db.godina.findOne({ where: { id: sGodine } }).then(function (a) {
                if (a == null) {
                    var html = " <div id='poruka'>Nije validno</div>";
                    fs.writeFileSync("./public/greska.html");
                    fs.writeFileSync("./public/greska.html", html);
                    res.setHeader('Content-Type', 'text/html');
                    res.sendFile('greska.html', { root: __dirname + "/public/" });
                    return;
                }
                k.getGodine().then(function (sve) {
                    sve.push(a);
                    k.setGodine(sve);
                    res.setHeader('Content-Type', 'text/html');
                    res.sendFile('addVjezba.html', { root: __dirname + "/public/" });

                });
            }).catch(function(err){
                var html = "<div id='poruka'>Desila se greska!</div>";
                fs.writeFileSync("./public/greska.html", html);
                res.setHeader('Content-type', 'text/html');
                res.sendFile('greska.html', { root: __dirname + "/public/" });
                return;
            });
        }).catch(function(err){
            var html = "<div id='poruka'>Desila se greska!</div>";
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        });
    }

});
//Zadatak 3
app.post('/student', function (req, res) {
    var ret = { message: "vraceno je bla" };
    var studenti = req.body.studenti;
    var idGodine = req.body.godina;
    var up = [];
    var N = 0;
    var M = 0;
    var prom = [];


    studenti.forEach(el => {
        up.push(db.student.find({ where: { index: el.index } }).then(function (s) {
            if (s == null) {
                N++;
                s = { index: el.index, imePrezime: el.imePrezime };
                db.student.create({ index: el.index, imePrezime: el.imePrezime, studentGod: idGodine });
            }
            else s.update({
                studentGod: idGodine
            });
            return new Promise(function (resolve, reject) { resolve(s); });

        }));
    });
    Promise.all(up).then(function (knjige) {
        prom.push(db.godina.find({ where: { id: idGodine } }).then(function (godina1) {
            return godina1.getStudenti().then(function (g) {
                M = g.length;
                ret.message = "Dodano je " + N + " novih studenata i upisano " + studenti.length + " na godinu " + godina1.nazivGod;
                return new Promise(function (resolve, reject) { resolve(godina1); });
            });
        }).catch(function(err){
            var html = "<div id='poruka'>Desila se greska!</div>";
            fs.writeFileSync("./public/greska.html", html);
            res.setHeader('Content-type', 'text/html');
            res.sendFile('greska.html', { root: __dirname + "/public/" });
            return;
        }));
        Promise.all(prom).then(function (k) {
            res.setHeader('Content-type', 'application/json');
            res.send(ret);
        });
    });
});
