var GodineAjax = (function(){
var konstruktor = function(divSadrzaj){
    var http = new XMLHttpRequest();
    const url = 'http://localhost:8080/godine';
    http.onreadystatechange= function () {
        if(http.readyState === 4 && http.status == 200) {
            var data =JSON.parse(http.response); 
            var html = "<ul>";
            for(var i = 0; i < data.length; i++){
                html+= "<li><div class='godina'>"+data[i].nazivGod + "<br><br>";
                html+="Naziv repozitorija vjezbe:"+data[i].nazivRepVje+"<br><br> Naziv repozitorija spirale:";
                html+=data[i].nazivRepSpi+"<br><br></div></li>";
            }
            html+="</ul>";
            divSadrzaj.innerHTML = html;
        }
      };
    
    http.open("GET",url,true);
    http.setRequestHeader("Content-Type","application/json");
    http.send();
        return {
            osvjezi:function(){
                var http = new XMLHttpRequest();
                http.onreadystatechange= function () {
                    if(http.readyState === 4 && http.status == 200) {
                        var data =JSON.parse(http.response); 
                        var html = "<ul>";
                        for(var i = 0; i < data.length; i++){
                            html+= "<li><div class='godina'>"+data[i].nazivGod + "<br><br>";
                            html+="Naziv repozitorija vjezbe:"+data[i].nazivRepVje+"<br><br> Naziv repozitorija spirale:";
                            html+=data[i].nazivRepSpi+"<br><br></div></li>";
                        }
                        html+="</ul>";
                        divSadrzaj.innerHTML = html;
                    }
                  };
                http.open("GET",url,true);
	            http.setRequestHeader("Content-Type","application/json");
                http.send();
            }
        }
    }
    return konstruktor;
}());

var GodineAjax = new GodineAjax(document.getElementById("divSadrzaj"));


