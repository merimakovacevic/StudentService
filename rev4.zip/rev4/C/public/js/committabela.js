var CommitTabela = (function () {
    var i = 1, tabela;
    var brojaci = [];
    //Funkcija koja nakon svake promjene u tabeli "popravlja" tabelu
    //dodavajuci colspan ili novu kolonu
    var popraviTabelu = function(){
        var max = 0;
        for (var i = 0; i < tabela.rows.length; i++){
            if (tabela.rows[i].cells.length > max &&  tabela.rows[i].cells[tabela.rows[i].cells.length - 1].innerHTML != "") max = tabela.rows[i].cells.length - 1;
        }
        tabela.rows[0].cells[1].colSpan = max;
        for (var i = 1; i < tabela.rows.length; i++) {
            if (tabela.rows[i].cells.length <= max  && tabela.rows[i].cells[tabela.rows[i].cells.length - 1].innerHTML != "") {
                tabela.rows[i].insertCell(tabela.rows[i].cells.length);
                tabela.rows[i].cells[tabela.rows[i].cells.length - 1].innerHTML = "";
            }
            if(tabela.rows[i].cells.length > 2 && max  < tabela.rows[i].cells.length-1 &&  tabela.rows[i].cells[tabela.rows[i].cells.length - 1].innerHTML == "")
                tabela.rows[i].deleteCell(tabela.rows[i].cells.length - 1);
        }
        for (var i = 1; i < tabela.rows.length; i++) {
            let len = tabela.rows[i].cells.length;
            if (len < max + 1 && tabela.rows[i].cells[len - 1].innerHTML == "") {
                tabela.rows[i].cells[len - 1].colSpan = max;
            }
        }
    };
    var konstruktor = function (divElement, brojZadataka) {
        divElement.innerHTML = ("<table id='commiti'> </table>");
        tabela = document.getElementById("commiti");
        var header = tabela.createTHead();
        var row = header.insertRow(0);
        var cell = row.insertCell(0);
        cell.innerHTML = "Naziv zadatka";
        cell = row.insertCell(1);
        cell.innerHTML = "Commiti";
        //Brojac commita na 0
        for(var i = 0; i < brojZadataka; i++) {
             brojaci.push(0);
        }
        for (i = 1; i <= brojZadataka; i++) {
            row = tabela.insertRow(i);
            cell = row.insertCell(0);
            cell.innerHTML = "<a href ='https://docs.google.com/document/d/1ZjkBwWG_gsRokjp7oGwDpFm40qXM1tB9AwcV5_Qv8W8/edit'> Zadatak " + i +"</a>";
            cell = row.insertCell(1);
            cell.innerHTML = "";
        }
        return {
            dodajCommit: function (rbZadatka, url) {
                if (rbZadatka < 0 || rbZadatka + 1 >= tabela.rows.length)
                    return -1;
                brojaci[rbZadatka]++;
                var row = tabela.rows[rbZadatka + 1];
                if (tabela.rows[rbZadatka + 1].cells.length == 2 && row.cells[1].innerHTML == "" || row.cells[row.cells.length - 1].innerHTML == "") {
                    row.cells[row.cells.length - 1].innerHTML = "<a href='" + url + "'> " + brojaci[rbZadatka] + "</a>";
                    row.cells[row.cells.length - 1].colSpan = 0;
                }
                else if (row.cells[row.cells.length - 1].innerHTML.length == 0) {
                    row.cells[row.cells.length - 1].innerHTML = "<a href='" + url + "'> " + brojaci[rbZadatka] + "</a>";
                    row.cells[row.cells.length - 1].colSpan = 0;
                }
                else {
                    cell = row.insertCell(tabela.rows[rbZadatka + 1].cells.length);
                    cell.innerHTML = "<a href='" + url + "'> " + brojaci[rbZadatka] + "</a>";
                }
                popraviTabelu();
            },
            editujCommit: function (rbZadatka, rbCommita, url) {
                if (rbZadatka < 0 || rbZadatka >= tabela.rows.length || rbCommita < 0 || rbCommita +1>= tabela.rows[rbZadatka + 1].cells.length)
                    return -1;
                var cell = tabela.rows[rbZadatka + 1].cells[rbCommita+1];
                var s = cell.innerHTML;
                s = s.substring(s.indexOf("> ") + 1);
                s = s.substring(0, s.indexOf("</"));
                cell.innerHTML = "<a href='" + url + "'> " + s + "</a>";
            },
            obrisiCommit: function (rbZadatka, rbCommita) {
                if (rbZadatka < 0 || rbZadatka >= tabela.rows.length || rbCommita < 0 || rbCommita + 1>= tabela.rows[rbZadatka + 1].cells.length)
                    return -1;
                tabela.rows[rbZadatka + 1].deleteCell(rbCommita+1);
                popraviTabelu();
            }
        }
    }
    return konstruktor;
}());

