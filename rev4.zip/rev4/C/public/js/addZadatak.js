function validirajNoviZadatak(){
    var mojDiv=document.getElementById("poruka");
    var inputNazivVjezbe=document.getElementById("nazivZadatka");
    var validacija = new Validacija(mojDiv);
    validacija.naziv(inputNazivVjezbe);
}