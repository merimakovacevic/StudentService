var ZadaciAjax = (function(){
    var konstruktor = function(callbackFn){
        const http = new XMLHttpRequest();
        const url = 'http://localhost:8080/zadaci';
        var zapoceoZahtjev = 0;
        http.timeout = 2000; // dvije sekunde

        http.ontimeout = function (e) {
            http.abort();
            zapoceoZahtjev--;
        };
    
        http.onreadystatechange= function () {
            if(http.readyState === 4 && http.status == 200) {
                zapoceoZahtjev --;       
                callbackFn(http.response);
            }
          };
        return {
            dajXML:function(){
                if(zapoceoZahtjev>0){
                    callbackFn('{"greska":"Već ste uputili zahtjev"}');
                    return;
                }
                zapoceoZahtjev ++;
            
                http.open("GET",url,true);

                http.setRequestHeader("Accept","application/xml");
                http.send();
            },
            dajCSV:function(){
                if(zapoceoZahtjev>0){
                    callbackFn('{"greska":"Već ste uputili zahtjev"}');
                    return;
                }
                zapoceoZahtjev ++;
                http.open("GET",url,true);

                http.setRequestHeader("Accept","text/csv");
                http.send();
            },
            dajJSON:function(){
                if(zapoceoZahtjev>0){
                    callbackFn('{"greska":"Već ste uputili zahtjev"}');
                    return;
                }
                zapoceoZahtjev ++;
                http.open("GET",url,true);

                http.setRequestHeader("Accept","application/json");
                http.send();
            }
        }
    }
    return konstruktor;
}());
function F(param){
    console.log(param);
}
