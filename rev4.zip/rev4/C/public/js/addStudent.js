function validirajPojedinacni(){
    var mojDiv=document.getElementById("poruka");
    var inputIndex=document.getElementById("index");
    var inputIme=document.getElementById("ime");
    var validacija = new Validacija(mojDiv);
    validacija.index(inputIndex);
    validacija.ime(inputIme)
}
document.getElementById("dodaj").addEventListener('click', dodaj);

const http = new XMLHttpRequest();
let dropdown = document.getElementById('sGodina');
dropdown.length = 0;
dropdown.selectedIndex = 0;

const url = 'http://localhost:8080/sveGodine';
var godine =[];
http.open('GET', url, true);
http.onreadystatechange = function () {
    if (http.readyState === 4 && http.status == 200) {
        const data = JSON.parse(http.responseText);
        godine=data;
        var option;
        if(data.length==undefined){
            option = document.createElement('option');
            option.text = data.nazivGod;
            option.value = data.id;
            dropdown.add(option);
        }
        for (let i = 0; i < data.length; i++) {
            option = document.createElement('option');
            option.text = data[i].nazivGod;
            option.value = data[i].id;
            dropdown.add(option);
        }
    }
};
http.send();
var bbucket = undefined;
var objZaPost = {};

function ucitaj(){
    if(bbucket==undefined ){
        var secret = document.getElementById("secret").value;
        var key = document.getElementById("key").value;
        if(key.length==0 || secret.length==0){
            alert("Nije validan key ili secret");
            return;
        }
        bbucket = new BitBucket(key,secret);
    }
    var godina= godine[document.getElementById('sGodina').selectedIndex]; 
    bbucket.ucitaj(godina.nazivRepSpi,godina.nazivRepVje,function(greska,studenti){
        if(greska!=null){
            bbucket = undefined;
            alert(greska);
            return;
        }
        document.getElementById("dodaj").disabled = false;
        objZaPost.godina=godina.id;
        objZaPost.studenti = studenti;        
    });  
    return false;
}
const httpDodaj = new XMLHttpRequest();
const urlDodaj = 'http://localhost:8080/student';
function dodaj(){
    const httpDodaj = new XMLHttpRequest();
    httpDodaj.onreadystatechange = function () {
        if (httpDodaj.readyState === 4 && httpDodaj.status == 200) {
            const data = JSON.parse(httpDodaj.responseText);
            alert(data.message);
        }
    };
    httpDodaj.open('POST', urlDodaj,true);
    httpDodaj.setRequestHeader("Content-Type","application/json");
    httpDodaj.send(JSON.stringify(objZaPost));
}