function validirajStudent(){
    var mojDiv=document.getElementById("poruka");
    var inputIme=document.getElementById("imeStudenta");
    var validacija = new Validacija(mojDiv);
    validacija.ime(inputIme);
}