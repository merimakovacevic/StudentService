function validirajNovaVjezba() {
    var mojDiv = document.getElementById("poruka");
    var inputNazivVjezbe = document.getElementById("nazivVjezbe");
    var validacija = new Validacija(mojDiv);
    validacija.naziv(inputNazivVjezbe);
}
const http = new XMLHttpRequest();
const http2 = new XMLHttpRequest();
const httpZad = new XMLHttpRequest();
var zadaciVjezbe;
var vjezbe;
let dropdown3 = document.getElementById('sGodineN');
dropdown3.length = 0;
dropdown3.selectedIndex = 0;
let dropdown = document.getElementById('sGodine');
dropdown.length = 0;
dropdown.selectedIndex = 0;
let dropdown2 = document.getElementById('sVjezbe');
dropdown2.length = 0;
dropdown2.selectedIndex = 0;
let dropdown4 = document.getElementById('sVjezbeZad');
dropdown4.length = 0;
dropdown4.selectedIndex = 0;

const url = 'http://localhost:8080/sveGodine';
const url2 = 'http://localhost:8080/vjezbe';
const urlZad = 'http://localhost:8080/zadaciOdabrani';

http.open('GET', url, true);
http.onreadystatechange = function () {
    if (http.readyState === 4 && http.status == 200) {
        const data = JSON.parse(http.responseText);
        const data2 = JSON.parse(http.responseText);

        var option;
        var option2;
        if(data.length==undefined){
            option = document.createElement('option');
            option.text = data.nazivGod;
            option.value = data.id;
            dropdown.add(option);
            dropdown3.add(option);

        }
        for (let i = 0; i < data.length; i++) {
            option = document.createElement('option');
            option.text = data[i].nazivGod;
            option.value = data[i].id;

            dropdown.add(option);
            option2 = document.createElement('option');
            option2.text = data2[i].nazivGod;
            option2.value = data2[i].id;
            dropdown3.add(option2);

        }
    }
};

http.send();


http2.open('GET', url2, true);
http2.onreadystatechange = function () {
    if (http2.readyState === 4 && http2.status == 200) {
        
        const data = JSON.parse(http2.responseText);
        const data2 = JSON.parse(http2.responseText);

        let option2;
        let option;
        vjezbe = data;
        if(data.length==undefined){
            option = document.createElement('option');
            option.text = data.naziv;
            option.value = data.id;
         

            dropdown2.add(option);
            dropdown4.add(option);
            httpZad.open('GET', urlZad+"/"+document.getElementById("sVjezbeZad").value, true);
            httpZad.send();
            return;
        }

        for (let i = 0; i < data.length; i++) {
            option = document.createElement('option');
            option.text = data[i].naziv;
            option.value = data[i].id;
            dropdown4.add(option);
            option2 = document.createElement('option');
            option2.text = data2[i].naziv;
            option2.value = data2[i].id;
            dropdown2.add(option2);

        }
        httpZad.open('GET', urlZad+"/"+document.getElementById("sVjezbeZad").value, true);

        httpZad.send();

    }
};

let dropdownZad = document.getElementById('sZadatak');
dropdownZad.length = 0;
dropdownZad.selectedIndex = 0;
httpZad.onreadystatechange = function () {
    if (httpZad.readyState === 4 && httpZad.status == 200) {
        const data = JSON.parse(httpZad.responseText);
        let option;
        zadaciVjezbe=data;
        if(data.length==undefined){
            option = document.createElement('option');
            option.text = data.naziv;
            option.value = data.id;
            dropdownZad.add(option);
        }
        for (let i = 0; i < data.length; i++) {
            option = document.createElement('option');
            option.text = data[i].naziv;
            option.value = data[i].id;
            dropdownZad.add(option);
            console.log(dropdownZad);


        }
    }
};

http2.send();
function poveziZadatakVjezbu(){
    
    var idZad, idVje;

    /*urediti*/ 
    if(zadaciVjezbe==undefined || vjezbe==undefined)
        return;
    if(zadaciVjezbe.length==undefined)
        idZad = zadaciVjezbe.id
    else
    idZad = zadaciVjezbe[dropdownZad.selectedIndex].id;
    if(vjezbe.length == undefined)
        idVje = vjezbe.id;
    else
    idVje = vjezbe[dropdown4.selectedIndex].id;
    document.getElementById("fPoveziZadatak").action =  "http://localhost:8080/vjezba/"+idVje+"/zadatak";
    window.location.reload();   
    return true;
   
}
function promjenaVjezbe(){
    var x = document.getElementById("sVjezbeZad").value;
    dropdownZad.length = 0;
    dropdownZad.selectedIndex = 0;
    httpZad.open('GET', urlZad+"/"+x, true);
    httpZad.send();
}