function validirajLogin(){
    var mojDiv=document.getElementById("poruka");
    var inputPassword=document.getElementById("password");
    var validacija = new Validacija(mojDiv);
    validacija.password(inputPassword);
}