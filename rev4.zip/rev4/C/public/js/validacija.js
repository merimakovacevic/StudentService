
var Validacija = (function () {
    var div;
    var popuniDiv = (function (div, poruka, input) {
        input.style.backgroundColor = "orangered";
        if (div.innerHTML.length == 0) {
            div.innerHTML = "Sljedeca polja nisu validna: " + poruka + "!";
            return;
        }
        div.innerHTML = div.innerHTML.replace("!", "," + poruka + "!");

    })
    var isprazniDiv = (function (div, poruka, input) {
        if(div.innerHTML!=div.innerHTML.replace("," + poruka, ""))
            div.innerHTML=div.innerHTML.replace("," + poruka, "");
        else    div.innerHTML=div.innerHTML.replace(" "+poruka, "");
        input.style.backgroundColor = "";
        if (div.innerHTML.length == 30) {
            div.innerHTML = "";
            return;
        }
    })
    var konstruktor = function (divElementPoruke) {
        div = divElementPoruke;
        div.innerHTML = '';
        return {
            ime: function (inputElement) {
                var s = inputElement.value;
                var regex = /^[A-Z]([A-Za-z]\'?)+(((\s)|(\-))[A-Z]([A-Za-z]\'?)+)?(((\s)|(\-))[A-Z]([A-Za-z]\'?)+)?(((\s)|(\-))[A-Z]([A-Za-z]\'?)+)?$/;
                if (!regex.test(s)) {
                    popuniDiv(div, "ime", inputElement);
                    return;
                }
                isprazniDiv(div, "ime", inputElement);
            },
            godina: function (inputElement) {
                var s = inputElement.value;
                var regex = /(20\d\d\/20\d\d)/;
                var res = s.split("/");
                if (s.length != 9 || !regex.test(s) || res[1] - res[0] != 1) {
                    popuniDiv(div, "godina", inputElement);
                    return;
                }
                isprazniDiv(div, "godina", inputElement);

            },
            repozitorij: function (inputElement, regex) {
                if (!regex.test(inputElement.value)){
                    popuniDiv(div, "repozitorij", inputElement);
                    return;
                }
                isprazniDiv(div, "repozitorij", inputElement);
            },
            index: function (inputElement) {
                var x = parseInt(inputElement.value, 10);
                if (x < 14000 || x >= 21000 || inputElement.value.length != 5) {
                    popuniDiv(div, "index", inputElement);
                    return;
                }
                isprazniDiv(div, "index", inputElement);
            },
            naziv: function (inputElement) {
                var regex = /^[A-Za-z]([A-Za-z0-9]*[\/\"\'!?;:,-]*)*[A-Za-z0-9]$/;
                var s = inputElement.value;
                if (s.length < 3 || !regex.test(s)) {
                    popuniDiv(div, "naziv", inputElement);
                    return;
                }
                isprazniDiv(div, "naziv", inputElement);
            },
            password: function (inputElement) {

                var s = inputElement.value;
                var bv = 0, bm = 0, bb = 0;
                if (s.length < 8) {
                    popuniDiv(div, "password", inputElement);
                    return;
                }
                for (let i = 0; i < s.length; i++) {
                    if (s[i] >= "A" && s[i] <= "Z") bv++;
                    else if (s[i] >= "a" && s[i] <= "z") bm++;
                    else if (s[i] >= "0" && s[i] <= "9") bb++;
                    else {
                        popuniDiv(div, "password", inputElement);
                        return;
                    }
                }
                if (bb < 2 || bm < 2 || bv < 2) {
                    popuniDiv(div, "password", inputElement);
                    return;
                }
                isprazniDiv(div, "password", inputElement);

            },
            url: function (inputElement) {

                var regex = /^((http)|(https)|(ftp)|(ssh))\:\/\/(([a-z0-9](\-[a-z0-9])*)(\.(([a-z0-9](\-[a-z0-9])*)))?)+(\/([a-z0-9](\-[a-z0-9])*)+)*(\?([a-z0-9](\-[a-z0-9])*)+\=([a-z0-9](\-[a-z0-9])*)+)*(\&([a-z0-9](\-[a-z0-9])*)+\=([a-z0-9](\-[a-z0-9])*)+)*$/;
                var result = regex.test(inputElement.value);
                if (!result) {
                    popuniDiv(div, "url", inputElement);
                    return false;
                }
                isprazniDiv(div, "url", inputElement);
                return true;
            }
        }
    }
    return konstruktor;
}());
