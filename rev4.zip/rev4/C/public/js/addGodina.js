function validirajGodinu(){
    var mojDiv=document.getElementById("poruka");
    var inputVjezba=document.getElementById("nazivVjezbe");
    var inputGod=document.getElementById("nazivGodine");
    var inputSpirala=document.getElementById("nazivSpirale");
    //Proizvoljni regex za repozitorij
    var regexRepozitorij= /^[A-Za-z0-9]{3,}$/;
    var validacija = new Validacija(mojDiv);
    validacija.godina(inputGod);
    validacija.repozitorij(inputVjezba,regexRepozitorij);
    validacija.naziv(inputSpirala);
}