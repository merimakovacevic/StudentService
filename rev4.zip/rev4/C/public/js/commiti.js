var tabela;
function kreiraj(){
    var brojZadataka= document.getElementById("brZadataka").value;
    var mojDiv=document.getElementById("tabela");
    tabela= new CommitTabela(mojDiv,brojZadataka);
    document.getElementById("dodaj").style.visibility="visible";
    document.getElementById("obrisi").style.visibility="visible";
    document.getElementById("edituj").style.visibility="visible";

}
function dodaj(){
    var divPoruke=document.getElementById("porukaDodaj");
    var validacija=new Validacija(divPoruke);
    var brojZadatka=document.getElementById("brZadatka").value;
    var url=document.getElementById("urlCommita").value;
    if(validacija.url(document.getElementById("urlCommita")) == false) //Ako nije validan url
        return;
    tabela.dodajCommit(parseInt(brojZadatka,10),url);
}
function obrisi(){
    let brojZadatka=parseInt( document.getElementById("brZadatkaObrisi").value,10);
    let brojCommita= parseInt(document.getElementById("brCommita").value,10);
    tabela.obrisiCommit(brojZadatka,brojCommita);
}
function edituj(){
    let brojZadatka=parseInt( document.getElementById("brZadatkaEdit").value,10);
    let brojCommita= parseInt(document.getElementById("brCommitaEdit").value,10);
    let url=document.getElementById("urlCommitaEdit").value;
    let divPoruke=document.getElementById("porukaEdit");
    let validacija=new Validacija(divPoruke);
    if(validacija.url(document.getElementById("urlCommitaEdit")) == false) //Ako nije validan url
        return;    
    tabela.editujCommit(brojZadatka,brojCommita,url);
}