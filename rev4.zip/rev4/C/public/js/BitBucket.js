
var BitBucket = (function () {
    var key, secret;
    var promise;
    var token;
    var konstruktor = function (_key, _secret) {
        key = _key;
        secret = _secret;
        promise = new Promise(function(resolve,reject){
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function () {
                if (ajax.readyState == 4 && ajax.status==200) {
                    token = JSON.parse(ajax.responseText).access_token;
                    resolve(JSON.stringify(ajax.responseText));

                }
                else if(                    ajax.readyState == 4                    ){
                   token=null;
                   reject(token);
                }
            };
            ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", false);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key+":"+secret));
            ajax.send("grant_type=" + encodeURIComponent("client_credentials"));
          
        });
       
        return {
            ucitaj: function (nazivRepSpi, nazivRepVje, callback) {
                promise.then(function(x){
                    if (token == null) {
                        callback("Nema tokena!",null);
                        return;
                    }
                    var ajax2 = new XMLHttpRequest();
                    ajax2.onreadystatechange = function () {
                        if (ajax2.readyState == 4 && ajax2.status == 200) {
                            var studenti = [];
                            var data = JSON.parse(ajax2.responseText);
                            var data = data.values;
                            if(data == null){
                                callback("Nije moguce dohvatiti listu studenata",null);
                            }
                            data.forEach(el => {
                                if(el.name.startsWith(nazivRepSpi.toLowerCase()) ||el.name.startsWith(nazivRepVje.toLowerCase()))
                                    {
    
                                var naziv;
                                if (el.name.length <= 5)
                                    naziv = el.name;
                                else
                                    naziv = el.name.substr(el.name.length - 5);
                                var stud = { imePrezime: el.owner.display_name, index: naziv };
                                var log = 0;
                                studenti.forEach(s => {
                                    if (s.index.toLowerCase() === stud.index.toLowerCase())
                                        log = 1;
                                });
                                if (log == 0)
                                    studenti.push(stud);
                            }
                            });
                            
                            callback(null,(studenti));
    
                        }
                        else if(ajax2.readyState==4){
                            callback(ajax2.responseText,null);
                        }
                    }
                    ajax2.open("GET", 'https://api.bitbucket.org/2.0/repositories?role=member&q=name+%7E+%22' + encodeURI(nazivRepSpi) + '%22+OR+name+%7E+%22' + encodeURI(nazivRepVje) + '%22');
                    ajax2.setRequestHeader("Authorization", 'Bearer ' + token);
                    ajax2.send();
                }).catch(e => {  
                     callback("Nema tokena!",null);
                  
                });
            }
        }
    };
    return konstruktor;
}());
