
function ucitaj(divElementPoruke, godina, inputElementRep1, inputElementRep2)
{
	var mojDiv = document.getElementById(divElementPoruke);
	var validacija = new Validacija(mojDiv);
	var godina = document.getElementById(godina);
	var rep1 = document.getElementById(inputElementRep1);
	var rep2 = document.getElementById(inputElementRep2);
	validacija.godina(godina);
	var rgx1 = /^[A-Za-z]{1}[-A-Za-z0-9\/\\"'!?:;,]+([0-9]|[a-z])+$/;
	validacija.repozitorij(rep1, rgx1);
	validacija.repozitorij(rep2, rgx1);

	// var http = new XMLHttpRequest();
	// var url = 'http://localhost:8080/addGodina';
	// var params = 'godina=' + godina + '&vjezba=' + vjezba+ '&spirala=' + spirala;
	// http.open('POST', url, true);

	// //Send the proper header information along with the request
	// http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

	// http.onreadystatechange = function() {//Call a function when the state changes.
	//     if(http.readyState == 4 && http.status == 200) {
	//         alert(http.responseText);
	//     }
	// }
	// http.send(params);

        
      
}

