var express = require("express");
var app     = express();
var path    = require("path");
var multer  = require('multer')
let converter = require('json-2-csv');
const bodyParser = require('body-parser');
var fs  = require('fs')
const csv = require('csv-parser');
var js2xmlparser = require("js2xmlparser");
var accepts = require('accepts')

//ZADATAK 1

app.use(express.static(__dirname + '/css'));
app.use(express.static(__dirname + '/html'));
app.use(express.static(__dirname + '/js'));
app.use(express.static(__dirname + '/jsons'));
app.use(express.static(__dirname + '/uploads'));


app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json()); // let's make JSON work too!

app.get('/addGodina',function(req,res){
	res.sendFile(path.join(__dirname,'html','addGodina.html'));
});
app.get('/addZadatak',function(req,res){
	res.sendFile(path.join(__dirname,'html','addZadatak.html'));
});
app.get('/addStudent',function(req,res){
	res.sendFile(path.join(__dirname,'html','addStudent.html'));
});
app.get('/addVjezba',function(req,res){
	res.sendFile(path.join(__dirname,'html','addVjezba.html'));
});
app.get('/commiti',function(req,res){
	res.sendFile(path.join(__dirname,'html','commiti.html'));
});
app.get('/login',function(req,res){
	res.sendFile(path.join(__dirname,'html','login.html'));
});
app.get('/studenti',function(req,res){
	res.sendFile(path.join(__dirname,'html','studenti.html'));
});


//ZADATAK 2


const multerConfig = {

	storage: multer.diskStorage({
	 	destination: function(req, file, next){
	   		next(null, __dirname + '/uploads');
	   	},   
	    
	    filename: function(req, file, next){
	        naziv = req.body.naziv;
	        const ext = file.mimetype.split('/')[1];
	        next(null, req.body.naziv+'.'+ext);
	    }
	}),

	fileFilter: function (req, file, cb) {
		req.errorWithFile = false;
		const ext = file.mimetype.split('/')[1];;
		if (ext !== "pdf") {
			req.errorWithFile = true;
			cb(null, false);
		}
		else{
			cb(null, true);
		}
	}
    
 };


app.post('/addZadatak', multer(multerConfig).single('postavka'), function(req,res, next){
  	let niz = {  
	    naziv: req.body.naziv,
	    postavka: '/'+req.body.naziv + '.pdf'
	};

	let data = JSON.stringify(niz, null, 2); 

	if (req.errorWithFile || fs.existsSync(path.join(__dirname, 'jsons', req.body.naziv + 'Zad.json'))) {
		res.send('<h1>Greska....</h1><a href="http://localhost:8080/addZadatak.html">Idi nazad</a>');
	}
	else{
		fs.writeFile('./jsons/'+ req.body.naziv + 'Zad.json', data, (err) => {  
	    if (err) throw err;
	    res.send('Uspjesno');
	});

	}
	
});


//ZADATAK 3	

//PROVJERIT STA AKO ZADATAK NE POSTOJI
app.get('/zadatak',function(req,res){
	console.log(req.query)
	var naziv = req.query.naziv;
	res.sendFile(path.join(__dirname+'/uploads/'+naziv+'.pdf'));

});


//ZADATAK 4

const readFile = function(path) {
    var fileContent;

    return new Promise(function(resolve) {
        fileContent = fs.readFileSync(path, {encoding: 'utf8'});
        resolve(fileContent);
    });
}


//KOD OVOG ZADATKA JOS PROVJERAVAT DA LI GODINA POSTOJI U GODINE.CSV
app.post('/addGodina', function(req, res){
	var godina = req.body.naziv;
	var vjezba = req.body.rvjezbe;
	var spirala = req.body.rspiral;
	var csvWriter = require('csv-write-stream') 
	
	const json2csv = require('json2csv').parse;

    let novaLinija = "\n" + godina+","+vjezba+ ","+spirala; 

	var fs = require('fs');	

	if (fs.existsSync(path.join(__dirname,'godine.csv'))){
		writer = csvWriter({sendHeaders: false});
		fs.readFile(path.join(__dirname,'godine.csv'), 'utf8', function (err, data) {
		  var dataArray = data.split(/\r?\n/);  //Be careful if you are in a \r\n world...
		  // Your array contains ['ID', 'D11', ... ]
		  var a=0;
		  for(var i=0; i<3; i++)
		  	if(dataArray[0][i] == godina)
		  		a = 1;
		  if(a=1){
	   			
	   			return res.send('<h1>Greska....</h1><a href="http://localhost:8080/addGodina.html">Idi nazad</a>')
	   		}
	   		else{
	   
			  writer.pipe(fs.createWriteStream(path.join(__dirname, 'godine.csv'), {flags: 'a'}));
			  writer.write({
			    nazivGod:godina,
			    nazivRepVje:vjezba,
			    nazivRepSpi:spirala,
			  });
			  writer.end();
			  res.send('Uspjeh');
	   		}
   		})  
	}
	else
	{
		console.log("Uso sam u else");
		writer = csvWriter({ headers: ["nazivGod", "nazivRepVje", "nazivRepSpi"]});
		writer.pipe(fs.createWriteStream(path.join(__dirname, 'godine.csv'), {flags: 'a'}));
		writer.write({
			nazivGod:godina,
			nazivRepVje:vjezba,
			nazivRepSpi:spirala,
		});
		writer.end();
		res.send('Uspjeh');
	}
		

   		
    
});


//ZADATAK 5

app.get('/godine',function(req,res){

	var fs = require('fs');
	fs.stat('godine.csv', (err, stats) => {
    	if (err) res.send("Greska pri pristupanju fajlu. Mozda fajl ne postoji");
    	else{
			console.log("usao");
			const csvFilePath=path.join(__dirname,'godine.csv');
			const csv=require('csvtojson')
			csv()
			.on('header',(header)=>{
			    header=> ['nazivGod', 'nazivRepVje', 'nazivRepSpi']
			})
			.fromFile(csvFilePath)
			.then((jsonObj)=>{
			    res.send(jsonObj);
			    
			})
		}
		    
  	});
	
});


//ZADATAK 7

// KOD OVOG ZADATKA JOS PRIORITET DA SE URADI	
var accepts = require('accepts')

app.get('/zadaci',function(req,res){

	fs.readdir('./jsons', (err, files) => {
	  const niz = [];
	  var accept = accepts(req);
	  files.forEach(file => {
	  const data = require(path.join(__dirname,'jsons', file));
	    	niz.push(data);
	  });

	switch (accept.type(['json', 'xml', 'csv'])) {
    case 'xml':
	  res.type('application/xml');
	  res.send(js2xmlparser.parse("zadaci", niz.map(item => ({zadatak: item}))));
    break

    case 'json':      
	  res.type('application/json');
	  res.send(niz);
	break

	case 'csv':
		res.type('text/csv');
		const Json2csvParser = require('json2csv').Parser;
		const json2csvParser = new Json2csvParser({ hasCSVColumnTitle: false });

		try {
			var csv = json2csvParser.parse(niz);
		  	res.send(csv);
		} catch (err) {
		  console.error(err);
		}

    break
  }
})
	 
});
 
app.listen(8080,function(){
    console.log("Working on port 8080");
});

