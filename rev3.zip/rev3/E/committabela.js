var CommitTabela = (function () {

    var divElement;
    var tabelaID = "tabela";
    var brojZad;

    var kontruktor = function (divElement, brojZadataka) {
        var colspan;
        brojZad = brojZadataka;
        var container = divElement;
        container.innerHTML = "<table id='tabela' border=2 width=30%><tr><th>Zadatak</th><th id='komit'>Commiti</th></tr></table>";
        var tabela = document.getElementById('tabela');
        for (i = 1; i <= brojZadataka; i++) {
            var x = document.getElementById('tabela').insertRow(i);
            var y = x.insertCell(0);
            y.innerHTML = "Zadatak" + i;
        }
        return {
             dodajCommit: function (rbZadatka, url) {
                if (rbZadatka > brojZad) {
                    return -1;
                }
                else {
                    var tabela = document.getElementById('tabela');

                    var brojRedova = tabela.rows.length;
                    //console.log(brojRedova);
                    //ako je zadnja celija prazna u nju da upise link i nista drugo
                    for(i=1;i<tabela.rows[rbZadatka].cells.length;i++)
                    {
    
                        if(tabela.rows[rbZadatka].cells[i].innerHTML=="")
                        {
                            //var xmlString = tabela.rows[rbZadatka].cells[i].innerHTML;
                            //doc = new DOMParser().parseFromString(xmlString, "text/html");
                            
                            //console.log(doc.firstChild.getAttribute("value"));
                            tabela.rows[rbZadatka].cells[i].innerHTML="<a href='" + url + "'>" + i + "</a>";
                            return;
                        }
                    }
                   
                    //ovdje doda u svakom redu ćeliju i upise gdje treba
                    
                        for (i = 1; i < brojRedova; i++) {
                            var red = tabela.rows[i];
                            var celija = tabela.rows[i].insertCell(-1);
                            celija.innerHTML = "";
                            var brojKolona = red.cells.length;

                            if (i == rbZadatka) {
                                 celija.innerHTML = '<a href="' + url + '">' + (red.cells.length-1) + '</a>';    
                                
                            }

                        }
                    

                }
            }
            ,editujCommit: function(rbZadatka,rbCommita,url)
            {
                if(rbZadatka>brojZad || rbZadatka<=0)
                {
                    return -1;
                }
                var red=document.getElementById('tabela');
                if(red.rows[rbZadatka].cells.length<=rbCommita || rbCommita<=0)
                {
                    return -1;
                }
                red.rows[rbZadatka].cells[rbCommita].innerHTML='<a href="' + url + '">' + (rbCommita) + '</a>';
            }
            ,obrisiCommit:function(rbZadatka,rbCommita)
            {
                if(rbZadatka>brojZad || rbZadatka<=0)
                {
                    return -1;
                }
                var red=document.getElementById('tabela');
                if(red.rows[rbZadatka].cells.length<=rbCommita || rbCommita<=0)
                {
                    return -1;
                }
                var maxBrojComita=0;
                for(i=0;i<brojZad;i++)
                {
                   var noviRed=document.getElementById('tabela').rows[rbZadatka];
                   if(noviRed.cells.length>maxBrojComita)
                   {
                       maxBrojComita=noviRed.cells.length;
                   }

                }
                red.rows[rbZadatka].cells[rbCommita].innerHTML="";
                if(rbCommita!=maxBrojComita)
                {
                    for(i=rbCommita;i<red.rows[rbZadatka].cells.length-1;i++)
                    {
                        var pomocna=red.rows[rbZadatka].cells[rbCommita].innerHTML;
                        red.rows[rbZadatka].cells[rbCommita].innerHTML=red.rows[rbZadatka].cells[rbCommita+1].innerHTML;
                        red.rows[rbZadatka].cells[rbCommita+1].innerHTML=pomocna;
                    }
                }
                
                var obrisatiKolonu=true;
                for(i=1;i<red.rows.length; i++)
                {
                    console.log(red.rows[i].cells[red.rows[i].cells.length-1].innerHTML);
                    if(red.rows[i].cells[red.rows[i].cells.length-1].innerHTML!="")
                    {
                        obrisatiKolonu=false;
                    }
                }
                console.log(obrisatiKolonu);
                if(obrisatiKolonu)
                {
                    for(i=1;i<red.rows.length; i++)
                    {
                        red.rows[i].deleteCell(red.rows[i].cells.length-1);
                    } 
                }
            }
        }
    }
    return kontruktor;
}());


var tabela;
var red = 0;
function dodajCommitDugme() {
    tabela.dodajCommit(red + 1, 'https://www.etf.ba/');
    red++;
    red = red % 4;
}
function kreirajTabelu() {
    var divic=document.getElementById('divic');
    tabela = new CommitTabela(divic, 4);

}
function edit()
{
    //tabela.editujCommit(2,3,'https://www.google.com/');
    tabela.obrisiCommit(2,2);
}
