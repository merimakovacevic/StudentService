var ZadaciAjax = (function(){
    var isProcessing = false
    var greska = {
        greska : "Već ste uputili zahtjev"
    }
    var konstruktor = function(callbackFn){

    return {
    dajXML:function(){
        var ajax = new XMLHttpRequest();
        ajax.open("GET", '/zadaci', true);
        ajax.setRequestHeader("Accept", "application/xml");

        ajax.timeout = 2000
        ajax.ontimeout = function () {
            ajax.abort()
            isProcessing = false
            console.log("PREKID")
        }

        ajax.onreadystatechange=function(){
            isProcessing = false
            if(ajax.readyState==4 && ajax.status==200) {
                callbackFn(ajax.responseText)
            }
        }
        if (isProcessing == false) {
            isProcessing = true
            ajax.send();
        } else {
            callbackFn(greska)
        }
    },
    dajCSV:function(){
        var ajax = new XMLHttpRequest();
        ajax.open("GET", '/zadaci', true);
        ajax.setRequestHeader("Accept", "text/csv");

        ajax.timeout = 2000
        ajax.ontimeout = function () {
            ajax.abort()
            isProcessing = false
            console.log("PREKID")
        }

        ajax.onreadystatechange=function(){
            isProcessing = false
            if(ajax.readyState==4 && ajax.status==200) {
                callbackFn(ajax.responseText)
            }
        }

        if (isProcessing == false) {
            isProcessing = true
            ajax.send();
        } else {
            callbackFn(greska)
        }
    },
    dajJSON:function(){
        var ajax = new XMLHttpRequest();
        ajax.open("GET", '/zadaci', true);
        ajax.setRequestHeader("Accept", "application/json");

        ajax.timeout = 2000
        ajax.ontimeout = function () {
            ajax.abort()
            isProcessing = false
            console.log("PREKID")
        }

        ajax.onreadystatechange=function(){
            isProcessing = false
            if(ajax.readyState==4 && ajax.status==200) {
                callbackFn(ajax.responseText)
            }
        }

        if (isProcessing == false) {
            isProcessing = true
            ajax.send();
        } else {
            callbackFn(greska)
        }
    }
    }
    }
    return konstruktor;
}());

var daj = ZadaciAjax(function(result) {
    console.log(result)
})

function podaj() {
    daj.dajXML()
    daj.dajCSV()
}