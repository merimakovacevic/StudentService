
function ispisiPoruku()
{
    var form=document.getElementById("fNova");
    var myInput=document.getElementById("poruka");
    var inputNaziv=document.getElementById("vjezba");
    var validacija=new Validacija(myInput);
    validacija.naziv(inputNaziv);
}