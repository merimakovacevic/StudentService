function ispisiPoruku()
{
    var form=document.getElementById("login");
    var myInput=document.getElementById("poruka");
    var inputPass=document.getElementById("password");
    var validacija=new Validacija(myInput);
    validacija.password(inputPass);
    /*var poruka="Sljedeća polja nisu validna: ";
    
    if(!validacija.password(inputPass.value)) 
    {
        poruka+="Password";
        validacija.div.innerHTML=poruka;
    }
    */

    
}
