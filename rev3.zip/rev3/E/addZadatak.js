
function ispisiPoruku()
{
    var form=document.getElementById("glavniSadrzaj");
    var myInput=document.getElementById("poruka");
    var inputNaziv=document.getElementById("naziv");
    var validacija=new Validacija(myInput);
    validacija.naziv(inputNaziv);
}