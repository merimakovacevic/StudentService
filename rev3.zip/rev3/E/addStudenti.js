function ispisiPoruku()
{
    var form=document.getElementsByName("fPojedinacni");
    var myInput=document.getElementById("poruka");
    var inputGodina=document.getElementById("ime");
    var inputDva=document.getElementById("indeks");

    var validacija=new Validacija(myInput);
    //var val=new Validacija(myInput);

    //val.ime(inputGodina);
    validacija.index(inputDva);
}