const express= require('express');
const bodyParser = require('body-parser');
const fs=require('fs');
const csv = require("csvtojson");
const app=express();
const parse = require('csv-parse');
const multer = require('multer');
const converter = new csv({})
const js2xmlparser = require("js2xmlparser");
const convert = require('xml-js');
var builder = require('xmlbuilder');
const json2csv = require('json2csv');

var path = require('path')

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    cb(null, req.body.naziv + ".pdf")
  }
})

var upload = multer({ storage: storage });

app.use(express.static('./'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.get('/', function(req,res){
    res.sendFile(__dirname + '/index.html');
});

app.get('/godine', function(req, res){
    var file = __dirname + "/" + 'godine.csv';
    csv().fromFile(file).then(function(result){
        return res.send(result);
    });
});

app.get('/zadaci', function(req,res){
    const path = './'
    var zadaci = []
    fs.readdir(path, function(err, items) {
        for (var i=0; i<items.length; i++) {
            if (items[i].includes("Zad.json")) {
                let file = __dirname + "/" + items[i]
                let rawdata = fs.readFileSync(file);  
                let zadatak = JSON.parse(rawdata);
                zadaci.push(zadatak)
            }
        }

        if (req.accepts('json')) {
            return res.send(zadaci)
        } else if (req.accepts('xml')) {
            var xml = '<?xml version="1.0" encoding="UTF-8"?>'
            xml += "<zadaci>"
            
            zadaci.forEach(function(item, index) {
                xml += "<zadatak>"
                xml += "<naziv>"
                xml += item["naziv"]
                xml += "</naziv>"

                xml += "<postavka>"
                xml += item["postavka"]
                xml += "</postavka>"
                xml += "</zadatak>"
            })

            xml += "</zadaci>"

            res.set('Content-Type', 'application/xml');
            return res.send(xml)
        } else if (req.accepts('csv')){
            var csv = ""
            zadaci.forEach(function(item, index) {
                csv += item["naziv"] + ", "
                csv += item["postavka"] + "\n"
            })
            res.set('Content-Type', 'text/csv');
            return res.send(csv);
        }
    });
});

app.post('/addZadatak', upload.single('postavka'), function(req,res){
    if(req.file.mimetype!='application/pdf'){
        return res.sendFile(__dirname+ '/greska.html')
    }

    if (fs.existsSync(__dirname + "/" + req.body.naziv + "Zad.json")) {
        return res.sendFile(__dirname+ '/greska.html')
    }

    let host = "http://localhost:8080/zadatak?naziv="
    var data = JSON.stringify({naziv: req.body.naziv, postavka: host + req.body.naziv});
    
    fs.writeFileSync(req.body.naziv+"Zad.json", data);
    res.sendFile(__dirname+'/addZadatak.html');
});

app.get("/zadatak", function(req,res){
    var filePath=__dirname+'/uploads/'+req.query.naziv+'.pdf';
    res.contentType("application/pdf");
    res.sendfile(filePath)
});



app.post("/addGodina", function(req,res){
    var newLine="\r\n";
    var csvData=[];
    fs.createReadStream("godine.csv")
        .pipe(parse({delimiter: ':'}))
        .on('data', function(csvrow) {
            csvData.push(csvrow);        
        })
        .on('end',function() {
            csvData.forEach(row=>{
                if(row[0] == (req.body.nazivGod+','+req.body.nazivRepVje+','+req.body.nazivRepSpi)){
                    res.sendFile(__dirname+'/greska.html')
                }
            });
                var fields=['nazivGod', 'nazivRepVje', 'nazivRepSpi'];
                var data = [req.body.nazivGod, req.body.nazivRepVje, req.body.nazivRepSpi];
                
                fs.stat('godine.csv', function (err, stat) {
                    data=(data+newLine);
                        fs.appendFile('godine.csv', data, function (err) {
                            if (err) throw err;
                        });
                    if (err == null) {
                        
                    }
                    else {
                        fields= (fields + newLine);
                        data = (data + newLine);
                        fs.writeFile('godine.csv', fields + data, function (err, stat) {
                            if (err) throw err;
                        });
                    }
                });
                return res.sendFile(__dirname+'/addGodina.html');

        });
});


app.listen(8080);