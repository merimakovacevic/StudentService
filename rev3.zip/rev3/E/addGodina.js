function ispisiPoruku()
{
    var form=document.getElementById("side");
    var myInput=document.getElementById("poruka");
    var inputGodina=document.getElementById("godina");
    
    var validacija=new Validacija(myInput);
    

    validacija.godina(inputGodina);
   
}