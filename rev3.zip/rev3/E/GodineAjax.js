var GodineAjax = (function(){
    var div
    var konstruktor = function(divSadrzaj){
        div = divSadrzaj
        var ajax = new XMLHttpRequest();
            ajax.open("GET", '/godine', true);
            ajax.setRequestHeader("Accept", "application/json");

            ajax.onreadystatechange=function(){
                if(ajax.readyState==4 && ajax.status==200) {
                    var data = ajax.responseText
                    console.log(data)
                }   
            }
        
            ajax.send();
    return {
        osvjezi:function(){
            console.log("tu sam")
            var ajax = new XMLHttpRequest();
            ajax.open("GET", '/godine', true);
            ajax.setRequestHeader("Accept", "application/json");

            ajax.onreadystatechange=function(){
                if(ajax.readyState==4 && ajax.status==200) {
                    var data = ajax.responseText
                    console.log(data)
                }   
            }
        
            ajax.send();
        }
    }
    }
    
    return konstruktor;
    }());