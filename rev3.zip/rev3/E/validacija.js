var Validacija=(function (){
    var div;

    var konstruktor=function(divElementPoruke)
    {
        var porukica="Sljedeća polja nisu validna: ";
        div=divElementPoruke;
        return{
            ime:function(inputElement){
                var sablon=new RegExp(/^([A-ZŠĐŽĆČ]{1,1}[a-zA-Z-'ŠĐŽĆČšđžćč]{2,})(( [A-ZŠĐŽĆČ]{1,1}[a-zA-Z-'ŠĐŽĆČšđžćč]{2,})+)?$/);
                if(sablon.test(inputElement.value)) {
                    div.innerHTML="";
                    return true;
                }
               else{
                div.innerHTML=porukica+"ime " 
                return false;
               }
            },
            godina:function(inputElement){
                var god=new RegExp(/^20[0-9]{2}\/20[0-9]{2}$/);
                if(god.test(inputElement.value))
                {
                    var pom=inputElement.value;
                    var novi1=pom.substring(0,4);
                    var novi2=pom.substring(5,9);
                    
                    if(parseInt(novi1)+1==parseInt(novi2)){
                        div.innerHTML="";
                        return true;
                    }
                    else{
                        div.innerHTML=porukica+"godina ";
                        return false;
                    }
                }
                else{
                    div.innerHTML=porukica+"godina ";
                    return false;
                }
               
             },

            repozitorij:function(inputElement,regex){
                if(regex.test(inputElement.value))
                {
                    div.innerHTML="";
                    return true;
                }
               else{
                div.innerHTML=porukica+"repozitori " 
                return false;
               } 
            },

            index:function(inputElement){
                var indeks=new RegExp(/^1[4-9][0-9]{3}$|^20[0-9]{3}$/);
                if(indeks.test(inputElement.value)) 
                {
                    div.innerHTML="";
                    return true;
                }
               else{
                div.innerHTML=porukica+"indeks " 
                return false;
               }
                
            },

            naziv:function(inputElement){
                var naz=new RegExp(/^[a-zA-Z][a-zA-Z0-9\\\/\-\"\'\!\?\:\;\,]+[0-9a-z]$/);
                if(naz.test(inputElement.value))
                {
                    div.innerHTML="";
                    return true;
                }
                else{
                    div.innerHTML=porukica+"naziv "
                }
                return false;
            },

            password:function(inputElement){
                
                var sifra = new RegExp(/^(?=.*[a-z])(?=.*[A-Z])([a-zA-Z0-9]{8,})|(?=.*[0-9])(?=.*[a-z])([0-9a-zA-Z]{8,})|(?=.*[A-Z])(?=.*[0-9])([0-9A-Za-z]{8,})/);
                if(sifra.test(inputElement.value))
                {
                   div.innerHTML="";
                    return true; 
                } 
                else 
                {
                    div.innerHTML=porukica+"password ";
                    return false;
                }   
            },

            url:function(inputElement){
            },
            div
        }

    }
    return konstruktor;

}());


