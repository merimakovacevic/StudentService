function ispisiPoruku()
{
    var form=document.getElementById("imena");
    var myInput=document.getElementById("poruka");
    var inputIme=document.getElementById("imeStudenta");
    var validacija=new Validacija(myInput);
    validacija.ime(inputIme);
}