var Validacija = (function() {

    var greske = [];
    var elementiSaGreskama = [];

    var provjeriPassword = function(pw) {
        var regex = /^[A-Za-z0-9]{8,}$/;
        if (!regex.test(pw)) 
            return false;
        var pwRegex = [/\d/, /[A-Z]/, /[a-z]/];
        var broj = 0;
        for (var i = 0; i < pwRegex.length; i++) {
            if ((pw.match(pwRegex[i]) || []).length > 0) broj++;
        }
        return broj >= 2;
    }

    var azurirajGreske = function(div) {
        div.innerHTML = (greske.length > 0) ? 'Sljedeća polja nisu validna: ' + greske.join(',') + '!' : '';
    }

    var dodajUGreske = function(inputElement, divElementPoruke) {
        if (!greske.includes(inputElement.name)) {
            greske.push(inputElement.name);
            elementiSaGreskama.push(inputElement);
            inputElement.setAttribute('style', 'background-color: orangered');
            inputElement.style.backgroundColor = 'orangrered !important';  
            azurirajGreske(divElementPoruke);
        }
    }
    
    var izbaciIzGresaka = function(inputElement, divElementPoruke) {
        var indexOfInputName = greske.indexOf(inputElement.name);
        if (indexOfInputName > -1) {
            greske.splice(indexOfInputName, 1);
            elementiSaGreskama.splice(indexOfInputName, 1);
            inputElement.removeAttribute('style');
            azurirajGreske(divElementPoruke);
        }
    }

    var konstruktor = function(divElementPoruke) {
        return {
            ime: function(inputElement) {
                var ime = inputElement.value;
                var regex = /^([A-Z]('|\w){1,}[" "-]){0,3}[A-Z]('|\w){1,}?$/;
                regex.test(ime) && !ime.match(/''/) ? izbaciIzGresaka(inputElement, divElementPoruke) : dodajUGreske(inputElement, divElementPoruke);
            },
            godina: function(inputElement) {
                var godinaInput = inputElement.value;
                var regex = /(20\d{2}\/20\d{2})\b/;
                if (regex.test(godinaInput)) {
                    var godine = godinaInput.split('/').map(godina => parseInt(godina));
                    godine[0] + 1 === godine[1] ? izbaciIzGresaka(inputElement, divElementPoruke) : dodajUGreske(inputElement, divElementPoruke); 
                } 
                else 
                    dodajUGreske(inputElement, divElementPoruke);
            },
            repozitorij: function(inputElement, regex) {
                !regex.test(inputElement.value) ? dodajUGreske(inputElement, divElementPoruke) : izbaciIzGresaka(inputElement, divElementPoruke);
            },
            index: function(inputElement) {
                var indexInput = inputElement.value;
                var regex = /\d{5}\b/;
                if (regex.test(indexInput)) {
                    var prveDvijeCifre = Math.floor(parseInt(indexInput) / 1000);
                    prveDvijeCifre >= 14 && prveDvijeCifre <= 20 ? izbaciIzGresaka(inputElement, divElementPoruke) : dodajUGreske(inputElement, divElementPoruke);
                } 
                else 
                    dodajUGreske(inputElement, divElementPoruke);
            },
            naziv: function(inputElement) {
                var nazivPattern = /^[A-Za-z]{1,}[A-Za-z0-9\/\-\'"!?:;,]+[a-z0-9]+$/;
                var regex = new RegExp(nazivPattern);
                !regex.test(inputElement.value) ? dodajUGreske(inputElement, divElementPoruke) : izbaciIzGresaka(inputElement, divElementPoruke);
            },
            password: function(inputElement) {
                !provjeriPassword(inputElement.value) ? dodajUGreske(inputElement, divElementPoruke) : izbaciIzGresaka(inputElement, divElementPoruke);
            },
            url: function(inputElement) {
                var urlPattern = /^(http|https|ftp|ssh):\/\/\w+(\.\w+)*(\/\w+)*(\?\w+=\w+)*(&\w+=\w+)*$/;
                var regex = new RegExp(urlPattern);
                !regex.test(inputElement.value) ? dodajUGreske(inputElement, divElementPoruke) : izbaciIzGresaka(inputElement, divElementPoruke);
            }
        }
    }
    return konstruktor;
}());