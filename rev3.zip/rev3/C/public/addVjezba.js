document.getElementsByName('fPostojeca')[0].addEventListener('submit', (e) => {
    e.preventDefault();
});

document.getElementsByName('fNova')[0].addEventListener('submit', (e) => {
    e.preventDefault();
    var validacija = Validacija(document.getElementById('porukeNova'));
    validacija.naziv(document.getElementsByName('naziv')[0]);
});
