var GodineAjax = (function () {
    var ajax;
    var fun = (ajax, divSadrzaj) => {
        if (ajax.readyState == 4 && ajax.status == 200) {
            //add content to div
            var jsonArrayString = ajax.responseText;
            var jsonArray = JSON.parse(jsonArrayString);
            for (var row in jsonArray) {
                var content = document.createElement('div');
                content.setAttribute('class', 'godina');
                var jsonObject = jsonArray[row];
                var nazivGod = document.createElement('h5');
                nazivGod.innerHTML = jsonObject['nazivGod'];
                var nazivRepVje = document.createElement('p');
                nazivRepVje.innerHTML = 'Naziv repozitorija vježbe: ' + jsonObject['nazivRepVje'];
                var nazivRepSpi = document.createElement('p');
                nazivRepSpi.innerHTML = 'Naziv repozitorija spirale: ' + jsonObject['nazivRepSpi'];
                content.appendChild(nazivGod);
                content.appendChild(nazivRepVje);
                content.appendChild(nazivRepSpi);
                document.getElementById(divSadrzaj).appendChild(content);
            }
        }
        if (ajax.readyState == 4 && ajax.status == 404) {

        }
    };
    var sendRequest = (ajax) => {
        ajax.open('GET', 'http://localhost:8080/godine', true);
        ajax.send();
    }
    var konstruktor = function (divSadrzaj) {
        ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            fun(ajax, divSadrzaj);
        }
        sendRequest(ajax);
        return {
            osvjezi: function () {
                ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function () {
                    fun(ajax, divSadrzaj);
                }
                sendRequest(ajax);
            }
        }
    }
    return konstruktor;
}());