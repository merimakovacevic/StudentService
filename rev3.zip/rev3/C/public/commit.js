var cont = document.getElementById('container');
//var ct = new CommitTabela(cont, 5);

function dodaj() {
    ct.dodajCommit(Number(document.getElementById('dodajBroj').value), 
        document.getElementById('dodajUrl').value);
}

function edituj() {
    if(ct.editujCommit(Number(document.getElementById('editujZad').value), 
        Number(document.getElementById('editujCommit').value), 
            document.getElementById('editujUrl').value) === -1)
                document.getElementById('poruka').style.display = 'block';
    else
        document.getElementById('poruka').style.display = 'none';
}

function obrisi() {
    if(ct.obrisiCommit(Number(document.getElementById('obrisiZad').value), 
        Number(document.getElementById('obrisiCommit').value)) === -1)
            document.getElementById('poruka').style.display = 'block';
    else    
    document.getElementById('poruka').style.display = 'none';
}

function kreiraj(numberOfRows) {
    var table = document.getElementsByTagName('table')[0];
    if(table != null) 
        table.parentNode.removeChild(table);
    ct = new CommitTabela(cont, numberOfRows);
    document.getElementsByTagName('table')[0].scrollIntoView();
}



