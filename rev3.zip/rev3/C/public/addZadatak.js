document.getElementById('novi-zadatak').addEventListener('submit', (e) => {
    //e.preventDefault();
    console.log('aa')
    var validacija = Validacija(document.getElementById('poruke'));
    validacija.naziv(document.getElementsByName('naziv')[0]);
});




