document.getElementById('unosGodine').addEventListener('submit', (e) => {
    //e.preventDefault();
    var validacija = Validacija(document.getElementById('poruke'));
    validacija.godina(document.getElementsByName('naziv')[0]);
    validacija.repozitorij(document.getElementsByName('rvjezbe')[0], /./);
    validacija.repozitorij(document.getElementsByName('rspiral')[0], /./);
});

function loadData(divSadrzaj) {
    var ga = new GodineAjax(divSadrzaj);
}