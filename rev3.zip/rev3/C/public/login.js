function check() {
    var validacija = Validacija(document.getElementById('poruke'));
    validacija.password(document.getElementsByName('password')[0]);
}