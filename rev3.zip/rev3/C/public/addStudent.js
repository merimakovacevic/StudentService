document.getElementsByClassName('form')[0].addEventListener('submit', (e) => {
    e.preventDefault();
    var validacija = Validacija(document.getElementById('porukePojedinacni'));
    validacija.ime(document.getElementsByName('ime')[0]);
    validacija.index(document.getElementsByName('index')[0]);
});

document.getElementsByClassName('form')[1].addEventListener('submit', (e) => {
    e.preventDefault(); 
});