var CommitTabela = (function () {
    var brCommita;

    function provjeriOpseg(table, rbZadatka, rbCommita) {
        if (rbZadatka + 2 > table.rows.length)
            return -1;
        if (rbCommita + 2 > table.rows[rbZadatka + 1].children.length ||
            table.rows[rbZadatka + 1].children[rbCommita + 1].children.length === 0)
            return -1;
    }

    var konstruktor = function (divElement, brojZadataka) {
        brCommita = Array.apply(null, Array(brojZadataka)).map(Number.prototype.valueOf, 0);

        var tbl = document.createElement('table');
        tbl.setAttribute('id', 'committabela');
        var tbdy = document.createElement('tbody');
        var naslovi = document.createElement('tr');
        var nazivi = document.createElement('th');
        var commiti = document.createElement('th');
        nazivi.innerHTML = 'Zadaci';
        commiti.innerHTML = 'Commiti';
        naslovi.appendChild(nazivi);
        naslovi.appendChild(commiti);
        tbdy.appendChild(naslovi);
        for (var i = 0; i < brojZadataka; i++) {
            var redzadatak = document.createElement('tr');
            var nazivzadatka = document.createElement('td');
            var ostalicommiti = document.createElement('td');
            nazivzadatka.innerHTML = 'Zadatak ' + String(i + 1);
            redzadatak.appendChild(nazivzadatka);
            redzadatak.appendChild(ostalicommiti);
            tbdy.appendChild(redzadatak);
        }
        tbl.appendChild(tbdy);
        divElement.appendChild(tbl);

        return {
            dodajCommit: function (rbZadatka, url) {
                var x = document.getElementById('committabela');
                var red = x.rows[rbZadatka + 1];
                var colNum = red.children.length;
                var novilink = document.createElement('a');
                novilink.setAttribute('href', url);
                brCommita[rbZadatka]++;
                var novacelija;

                if (red.lastElementChild.children.length > 0) {
                    novacelija = red.insertCell(colNum);
                    for (var i = 0; i <= brojZadataka; i++) {
                        var red = x.rows[i];
                        var zadnjaKolonaURedu = red.lastElementChild;

                        if (i === rbZadatka + 1)
                            continue;
                        if (zadnjaKolonaURedu.children.length > 0) {
                            zadnjaKolonaURedu.setAttribute('colspan', 1);
                            red.insertCell(colNum);
                        }
                        else {
                            var colSpan = zadnjaKolonaURedu.getAttribute('colspan')
                            colSpan == null ? colSpan = 2 : colSpan = Number(colSpan) + 1;
                            zadnjaKolonaURedu.setAttribute('colspan', colSpan);
                        }
                    }
                }
                else {
                    var colSpan = red.lastElementChild.getAttribute('colspan');
                    if (colSpan === null || colSpan === '1')
                        novacelija = red.lastElementChild;
                    else {
                        novacelija = red.insertCell(colNum - 1);
                        red.lastElementChild.setAttribute('colspan', colSpan - 1);
                    }
                }
                novilink.innerHTML = brCommita[rbZadatka];
                novacelija.appendChild(novilink);
            },
            editujCommit: function (rbZadatka, rbCommita, url) {
                var x = document.getElementById('committabela');
                if(provjeriOpseg(x, rbZadatka, rbCommita) === -1)
                    return -1;
                x.rows[rbZadatka + 1].children[rbCommita + 1].children[0].setAttribute('href', url);
            },
            obrisiCommit: function (rbZadatka, rbCommita) {
                var x = document.getElementById('committabela');
                if(provjeriOpseg(x, rbZadatka, rbCommita) === -1)
                    return -1;
                x.rows[rbZadatka + 1].deleteCell(rbCommita + 1);

                var maxbrCommita = 0;
                for (var i = 1; i <= brojZadataka; i++) {
                    if (x.rows[i].children.length - 1 > maxbrCommita) {
                        maxbrCommita = x.rows[i].children.length - 1;
                        if (x.rows[i].lastElementChild.children.length === 0)
                            maxbrCommita--;
                    }
                }

                if (x.rows[rbZadatka + 1].children.length === 1) {
                    x.rows[rbZadatka + 1].insertCell();
                    return;
                }
                for (var i = 0; i <= brojZadataka; i++) {
                    var red = x.rows[i];
                    var brojCommitaURedu = red.children.length - 1; //-1 zbog broja zadatka
                    var zadnjaKolonaURedu = red.lastElementChild;

                    if (i === 0)
                        red.lastElementChild.setAttribute('colspan', maxbrCommita);
                    else if (brojCommitaURedu === maxbrCommita && zadnjaKolonaURedu.children.length > 0)
                        continue;
                    else if (zadnjaKolonaURedu.children.length === 0) {
                        var komiti = brojCommitaURedu;
                        if (zadnjaKolonaURedu.children.length === 0)
                            komiti--;
                        zadnjaKolonaURedu.setAttribute('colspan', maxbrCommita - komiti);
                        if (zadnjaKolonaURedu.getAttribute('colspan') === '0')
                            red.deleteCell(brojCommitaURedu);
                    }
                    else if (i === rbZadatka + 1 && brojCommitaURedu < maxbrCommita)
                        red.insertCell();

                }
                if (x.rows[0].lastElementChild.getAttribute('colspan') === '0') {
                    for (var i = 1; i <= brojZadataka; i++) {
                        x.rows[i].insertCell();
                    }
                }

            }
        }
    }
    return konstruktor;
}());
