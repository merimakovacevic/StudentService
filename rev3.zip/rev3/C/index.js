const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const url = require('url');
const xml2js = require('xml2js');

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        cb(null, req.body.naziv + '.pdf');
    }
})

var upload = multer({ storage: storage })

const app = express();
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');

app.get('/login.html', function (req, res) {
    res.sendFile('/login.html', function (err) {
        err ? next(err) : console.log('Sent: ', 'login.html');
    })
});

app.get('/addStudent.html', function (req, res) {
    res.sendFile('/addStudent.html', function (err) {
        err ? next(err) : console.log('Sent: ', 'addStudent.html');
    })
});

app.get('/addGodina.html', function (req, res) {
    res.sendFile('/addGodina.html', function (err) {
        err ? next(err) : console.log('Sent: ', 'addGodina.html');
    })
});

app.get('/addVjezba.html', function (req, res) {
    res.sendFile('/addVjezba.html', function (err) {
        err ? next(err) : console.log('Sent: ', 'addVjezba.html');
    })
});

app.get('/addZadatak.html', function (req, res) {
    res.sendFile('/addZadatak.html', function (err) {
        err ? next(err) : console.log('Sent: ', 'addZadatak.html');
    })
});

app.get('/commiti.html', function (req, res) {
    res.sendFile('/commiti.html', function (err) {
        err ? next(err) : console.log('Sent: ', 'commiti.html');
    })
});

app.get('/studenti.html', function (req, res) {
    res.sendFile('/studenti.html', function (err) {
        err ? next(err) : console.log('Sent: ', 'studenti.html');
    })
});

app.get('/zadaci.html', function (req, res) {
    res.sendFile('/zadaci.html', function (err) {
        err ? next(err) : console.log('Sent: ', 'zadaci.html');
    })
});

app.post('/addGodina', function (req, res) {
    var values = req.body;
    //read data from godine.csv and check if year already exists
    var fileData = fs.readFileSync('godine.csv');
    var arrayOfFileData = fileData.toString().split('\n');
    for (var row in arrayOfFileData) {
        var rowData = arrayOfFileData[row].split(',');
        if (values['nazivGod'] === rowData[0]) {
            var fileName = path.join(__dirname + '/public/greska.ejs');
            res.render(fileName, { errMsg: 'Year ' + values['nazivGod'] + ' already exists' });
            return;
        }
    }
    //year doesn't exist, add data to godine.csv
    var newData = values['nazivGod'] + ', ' + values['nazivRepVje'] + ', '
        + values['nazivRepSpi'] + '\n';
    fs.appendFile('godine.csv', newData, function (err) {
        if (err)
            throw err;
        console.log('Data added successfully');
        var fileName = path.join(__dirname + '/public/addGodina.html');
        res.sendFile(fileName);
    });
});

app.get('/godine', function (req, res) {
    //read data from godine.csv and return as a JSON array
    var fileData = fs.readFileSync('godine.csv');
    var arrayOfFileData = fileData.toString().split('\n');
    var jsonArray = [];
    for (var row in arrayOfFileData) {
        var rowData = arrayOfFileData[row].split(',');
        if (rowData.toString().length === 0)
            continue;
        var obj = {
            'nazivGod': rowData[0],
            'nazivRepVje': rowData[1],
            'nazivRepSpi': rowData[2]
        }
        jsonArray.push(obj);
    }
    res.contentType('application/json');
    res.send(JSON.stringify(jsonArray));
});

app.post('/addZadatak', upload.single('postavka'), function (req, res) {
    //if file type is not pdf, show error html page
    if (req.file.mimetype != 'application/pdf') {
        var fileName = path.join(__dirname + '/public/greska.ejs');
        res.render(fileName, { errMsg: 'File type not allowed' });
        return;
    }
    //if file already exists, show error html page
    var newJsonFileName = req.body.naziv + 'Zad.json';
    fs.readdir(path.join(__dirname + '/zadaci'), function (err, items) {
        if (items.includes(newJsonFileName)) {
            var fileName = path.join(__dirname + '/public/greska.ejs');
            res.render(fileName, { errMsg: 'File already exists' });
            return;
        }
        //create file nazivZad.json, naziv is from req.body['naziv']
        //naziv.pdf is name of uploaded file
        //json: {naziv: NAZIV, postavka: LINK_ZA_DOWNLOAD}
        var obj = {
            'naziv': req.body.naziv,
            'postavka': req.file.filename
        }
        var newJsonFilePath = path.join(__dirname + '/zadaci/' + newJsonFileName);
        fs.writeFile(newJsonFilePath, JSON.stringify(obj), function (err) {
            if (err)
                throw err;
            console.log('Completed');
        });
        res.json(obj);
    });

});

app.get('/zadatak', function (req, res) {
    var urlParts = url.parse(req.url, true);
    var query = urlParts.query['naziv'] + '.pdf';
    var querySearchPath = path.join(__dirname + '/zadaci');
    //search for query in /zadaci
    fs.readdir(querySearchPath, function (err, items) {
        for (var i in items) { //read all json files in /zadaci
            var jsonFileText = fs.readFileSync(`${querySearchPath}/${items[i].toString()}`);
            if (query == JSON.parse(jsonFileText)['postavka']) {
                var data = fs.readFileSync(`./uploads/${query}`);
                res.contentType("application/pdf");
                res.send(data);
                return;
            }
        }
        var fileName = path.join(__dirname + '/public/greska.ejs');
        res.render(fileName, { errMsg: 'File not found' });
        return;
    });
});

app.get('/uploads/:zadatak', function (req, res) {
    let pdfFileName = req.params.zadatak;
    fs.readdir('./uploads', (err, items) => {
        if (items.includes(pdfFileName)) {
            res.contentType('application/pdf');
            res.download(`./uploads/${pdfFileName}`);
            return;
        }
    });
});

app.get('/zadaci', function (req, res) {
    var headers = req.headers.accept.split(',');
    //read all jsons from /zadaci into array
    var jsonArray = [];
    fs.readdir('./zadaci', function (err, items) {
        items.forEach((element) => {
            var jsonFile = fs.readFileSync(`./zadaci/${element}`);
            jsonArray.push(JSON.parse(jsonFile));
        });
        headers.forEach((header) => {
            if (header == 'application/json') {
                res.contentType('application/json');
                res.send(JSON.stringify(jsonArray));
                return;
            }
        });
        headers.forEach((header) => {
            if (header == 'application/xml' || header == 'text/xml') {
                var newJsonArray = {
                    'zadaci': []
                }
                jsonArray.forEach((element) => {
                    newJsonArray['zadaci'].push({ 'zadatak': element });
                });
                var builder = new xml2js.Builder();
                var xml = builder.buildObject(newJsonArray);
                res.contentType('application/xml');
                res.send(xml);
                return;
            }
        });
        headers.forEach((header) => {
            if (header == 'text/csv') {
                var zadaciCsv = '';
                jsonArray.forEach((element) => {
                    zadaciCsv += element.naziv + ',' + element.postavka + '\n';
                });
                res.contentType('text/csv');
                res.send(zadaciCsv);
                return;
            }
        });
    });
});

app.listen(8080);